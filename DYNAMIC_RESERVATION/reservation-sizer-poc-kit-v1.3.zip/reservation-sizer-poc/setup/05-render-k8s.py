#!/usr/bin/env python3
"""
Step 5 - render the Kubernetes manifests from config/sizer.env + config/policy.json.

  python3 setup/05-render-k8s.py [--env config/sizer.env] [--policy config/policy.json] [--out k8s/rendered]

Writes serviceaccount.yaml, configmap-policy.yaml, cronjob.yaml, networkpolicy.yaml. Commit them
to your Config Sync repo (namespace path for $NAMESPACE). Fails on any unset ${VAR}.
"""

import argparse
import json
import os
import re
import shlex
import sys

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_env(path):
    env = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            parts = shlex.split(v, comments=True)
            env[k.strip()] = parts[0] if parts else ""
    return env


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default=os.path.join(KIT, "config", "sizer.env"))
    ap.add_argument("--policy", default=os.path.join(KIT, "config", "policy.json"))
    ap.add_argument("--out", default=os.path.join(KIT, "k8s", "rendered"))
    a = ap.parse_args()

    env = load_env(a.env)
    env["GSA_EMAIL"] = f"{env.get('GSA_NAME', '')}@{env.get('PROJECT_ID', '')}.iam.gserviceaccount.com"
    env["LOG_RESOURCE"] = (f"projects/{env.get('PROJECT_ID')}/locations/{env.get('LOG_LOCATION')}/"
                           f"buckets/{env.get('LOG_BUCKET')}/views/{env.get('LOG_VIEW')}")
    for optional in ("GITHUB_TOKEN_SECRET", "GITHUB_APP_ID", "GITHUB_APP_INSTALLATION_ID", "GITHUB_APP_SECRET"):
        env.setdefault(optional, "")      # PAT mode leaves the App values empty, and the other way round
    if env.get("GITHUB_TOKEN_SECRET") and (env.get("GITHUB_APP_ID") or env.get("GITHUB_APP_SECRET")):
        sys.exit(f"ERROR: set GITHUB_TOKEN_SECRET (PAT mode) OR the GITHUB_APP_* values in {a.env}, not both")
    env.setdefault("GITHUB_APP_SECRET_PROJECT", "")
    if not env.get("GITHUB_APP_SECRET_PROJECT"):
        env["GITHUB_APP_SECRET_PROJECT"] = env.get("PROJECT_ID", "")
    if env.get("EGRESS_PROXY_CIDR"):
        env["PROXY_RULE"] = (f"    - to:                          # egress proxy (GitHub)\n"
                             f"        - ipBlock: {{ cidr: {env['EGRESS_PROXY_CIDR']} }}\n"
                             f"      ports:\n"
                             f"        - {{ protocol: TCP, port: {int(env.get('EGRESS_PROXY_PORT') or 3128)} }}")
    else:
        env["PROXY_RULE"] = "    # no egress proxy configured (EGRESS_PROXY_CIDR empty) - GitHub unreachable unless allowed elsewhere"

    required = ["PROJECT_ID", "CLUSTER_NAME", "CLUSTER_LOCATION", "ENV_NAME", "SYSTEM_POOL", "NAMESPACE",
                "KSA_NAME", "GSA_NAME", "IMAGE", "SCHEDULE", "GOOGLE_APIS_CIDR"]
    missing = [k for k in required if not env.get(k)]
    if missing:
        sys.exit(f"ERROR: set in {a.env}: {', '.join(missing)}")

    with open(a.policy) as f:
        policy = json.load(f)
    if any("<" in p for p in policy.get("pools", [])):
        sys.exit(f"ERROR: replace the placeholder pool names in {a.policy}")

    os.makedirs(a.out, exist_ok=True)
    tdir = os.path.join(KIT, "k8s", "templates")
    for name in sorted(os.listdir(tdir)):
        text = open(os.path.join(tdir, name)).read()
        unset = sorted({v for v in re.findall(r"\$\{([A-Z_]+)\}", text) if v not in env})
        if unset:
            sys.exit(f"ERROR: {name}: variables not defined in {a.env}: {unset}")
        out = re.sub(r"\$\{([A-Z_]+)\}", lambda m: env[m.group(1)], text)
        with open(os.path.join(a.out, name), "w") as f:
            f.write(out)
        print(f"wrote {os.path.join(a.out, name)}")

    cm = ("apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: sizer-policy\n"
          f"  namespace: {env['NAMESPACE']}\n  labels:\n    app.kubernetes.io/name: reservation-sizer\n"
          "data:\n  policy.json: |\n" + "".join(f"    {line}\n" for line in json.dumps(policy, indent=2).splitlines()))
    with open(os.path.join(a.out, "configmap-policy.yaml"), "w") as f:
        f.write(cm)
    print(f"wrote {os.path.join(a.out, 'configmap-policy.yaml')} (mode={policy.get('mode')})")


if __name__ == "__main__":
    main()
