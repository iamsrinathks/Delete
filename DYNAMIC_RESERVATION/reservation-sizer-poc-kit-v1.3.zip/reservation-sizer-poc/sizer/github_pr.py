"""
github_pr.py - minimal GitHub client used by reservation_sizer.py to raise ONE PR per file.

Two ways to authenticate:
  * GitHub.from_token(): a personal access token (PAT). Use a FINE-GRAINED token: one repository,
    Contents + Pull requests read/write, no Workflows, with an expiry date. Its scope is fixed when
    it is made in GitHub - nothing can narrow it at run time. Stdlib only.
  * GitHub.from_app(): a GitHub App; the installation token is DOWN-SCOPED at run time to the one
    repo, contents:write + pull_requests:write only. Needs PyJWT[crypto].
Works with github.com and GitHub Enterprise Server (pass --github-api https://<ghe-host>/api/v3).
Honours HTTPS_PROXY / NO_PROXY and an optional corporate CA bundle (added to the public roots,
never replacing them). TLS verification is always on. The token is never logged.

Behaviour:
  * fixed branch reservation-sizer/<env>-<cluster>; when the proposed file changes, the branch is
    reset to the base branch and the file committed once on top. When nothing changed (same file,
    branch still one commit on top of the current base) nothing is pushed: no CI re-run, and an
    existing approval keeps meaning what it approved
  * opens a PR or updates the existing open one
  * dry-run mode -> draft PR, "[DRY RUN]" title, do-not-merge label (falls back to non-draft if
    drafts are unsupported; the CI guard still fails it on the title or label)
  * an open bot PR whose dry-run/live state differs from the requested mode is closed with a
    comment and a new PR is opened (a dry-run PR never silently becomes the live one)
  * close_bot_pr(): closes the open bot PR with a comment (used when it no longer matches the
    recommendation)
If your team already has a PR raiser, ignore this module and feed it sizer-out/proposed.tfvars.json
and sizer-out/pr_body.md.
"""

import base64
import json
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

TOKEN_PERMISSIONS = {"contents": "write", "pull_requests": "write"}
DRY_RUN_PREFIX = "[DRY RUN] "
DO_NOT_MERGE = "do-not-merge"


class GitHubError(Exception):
    pass


def ssl_context(ca_bundle=None):
    """Public/system roots ALWAYS, plus the corporate bundle when given (cafile= alone would
    trust ONLY the bundle)."""
    ctx = ssl.create_default_context()
    if ca_bundle:
        ctx.load_verify_locations(cafile=ca_bundle)
    return ctx


def warn(message):
    print(json.dumps({"severity": "WARNING", "component": "reservation-sizer", "message": message}),
          file=sys.stderr)


def is_dry_run_pr(pr):
    labels = {(lb or {}).get("name") for lb in pr.get("labels", []) or []}
    return bool(pr.get("draft")) or (pr.get("title") or "").startswith(DRY_RUN_PREFIX) or DO_NOT_MERGE in labels


def parse_expiry(raw):
    """GitHub-Authentication-Token-Expiration header -> epoch seconds, or None if not understood.
    Seen as '2026-12-31 00:00:00 UTC' and '2026-12-31 00:00:00 -0800'; ISO 8601 also accepted."""
    raw = (raw or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S %z", "%Y-%m-%d %H:%M:%S UTC", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            dt = datetime.strptime(raw, fmt)
        except ValueError:
            continue
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return int((dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).timestamp())
    except ValueError:
        return None


class GitHub:
    def __init__(self, api, token, ca_bundle=None):
        self.api, self.token = api.rstrip("/"), token
        self.opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl_context(ca_bundle)))
        self.auth_kind, self.last_headers, self._token_headers = "app", {}, {}

    @classmethod
    def from_token(cls, api, token, repo, ca_bundle=None):
        """Personal access token mode. Fails at once if the token cannot read the repository."""
        token = (token or "").strip()
        if not token:
            raise GitHubError("GitHub token is empty")
        if any(c.isspace() for c in token):
            raise GitHubError("GitHub token contains whitespace - check the secret value")
        gh = cls(api, token, ca_bundle)
        gh.auth_kind = "pat"
        gh._call("GET", f"/repos/{repo}")              # proves access to the one repository
        gh._token_headers = dict(gh.last_headers)
        return gh

    def token_info(self):
        """PAT mode: what GitHub says about the token. classic = ghp_ prefix (fine-grained = github_pat_)."""
        h = self._token_headers
        raw = h.get("github-authentication-token-expiration")
        scopes = h.get("x-oauth-scopes")
        return {"kind": self.auth_kind,
                "classic": bool(self.token) and self.token.startswith("ghp_"),
                "scopes": None if scopes is None else [s.strip() for s in scopes.split(",") if s.strip()],
                "raw_expires": raw, "expires": parse_expiry(raw) if raw else None}

    @classmethod
    def from_app(cls, api, app_id, installation_id, private_key_pem, repo=None, ca_bundle=None):
        if not (app_id and installation_id and private_key_pem):
            raise GitHubError("GitHub App id, installation id and private key are all required")
        import jwt  # PyJWT
        now = int(time.time())
        app_jwt = jwt.encode({"iat": now - 60, "exp": now + 540, "iss": str(app_id)}, private_key_pem, algorithm="RS256")
        body = {"permissions": TOKEN_PERMISSIONS}
        if repo:
            body["repositories"] = [repo.split("/", 1)[-1]]
        tmp = cls(api, None, ca_bundle)
        d = tmp._call("POST", f"/app/installations/{installation_id}/access_tokens", body, auth=f"Bearer {app_jwt}")
        return cls(api, d["token"], ca_bundle)

    def _call(self, method, path, body=None, auth=None, ok404=False):
        url = path if path.startswith("http") else self.api + path
        hdrs = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "reservation-sizer"}
        if auth or self.token:
            hdrs["Authorization"] = auth or f"Bearer {self.token}"
        data = json.dumps(body).encode() if body is not None else None
        if data:
            hdrs["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        try:
            with self.opener.open(req, timeout=60) as r:
                self.last_headers = {k.lower(): v for k, v in r.headers.items()}
                raw = r.read()
                return json.loads(raw.decode()) if raw else {}
        except urllib.error.HTTPError as e:
            if ok404 and e.code == 404:
                return None
            raise GitHubError(f"GitHub {method} {path.split('?')[0]} -> HTTP {e.code}: "
                              f"{e.read().decode(errors='replace')[:400]}")

    def default_branch(self, repo):
        return self._call("GET", f"/repos/{repo}")["default_branch"]

    def get_file(self, repo, path, ref):
        q = urllib.parse.urlencode({"ref": ref})
        d = self._call("GET", f"/repos/{repo}/contents/{urllib.parse.quote(path)}?{q}")
        return base64.b64decode(d["content"]).decode(), d["sha"]

    def open_pr(self, repo, branch):
        owner = repo.split("/")[0]
        q = urllib.parse.urlencode({"head": f"{owner}:{branch}", "state": "open"})
        prs = self._call("GET", f"/repos/{repo}/pulls?{q}") or []
        return prs[0] if prs else None

    def close_pr(self, repo, pr, comment):
        try:  # the comment explains why; closing is what matters
            self._call("POST", f"/repos/{repo}/issues/{pr['number']}/comments", {"body": comment})
        except GitHubError as e:
            warn(f"could not comment on PR #{pr['number']}: {e}")
        self._call("PATCH", f"/repos/{repo}/pulls/{pr['number']}", {"state": "closed"})
        return pr.get("html_url", "")

    def close_bot_pr(self, repo, branch, comment):
        """Close the open PR from the bot branch, if any. Returns its URL, or None."""
        pr = self.open_pr(repo, branch)
        return self.close_pr(repo, pr, comment) if pr else None

    def _branch_is_current(self, repo, branch, ref_sha, base_sha, path, content):
        """True if the branch is exactly one commit on top of base_sha and already holds content."""
        commit = self._call("GET", f"/repos/{repo}/git/commits/{ref_sha}")
        parents = [p.get("sha") for p in commit.get("parents", []) or []]
        if parents != [base_sha]:
            return False
        current, _ = self.get_file(repo, path, branch)
        return current == content

    def raise_pr(self, repo, base, path, content, body, branch, title, draft, labels):
        base = base or self.default_branch(repo)
        base_sha = self._call("GET", f"/repos/{repo}/git/ref/heads/{urllib.parse.quote(base)}")["object"]["sha"]
        pr = self.open_pr(repo, branch)
        if pr and is_dry_run_pr(pr) != bool(draft):
            self.close_pr(repo, pr, "Closed by reservation-sizer: mode changed to "
                          f"{'dry-run' if draft else 'live'} - a new PR replaces this one.")
            pr = None
        ref = self._call("GET", f"/repos/{repo}/git/ref/heads/{urllib.parse.quote(branch)}", ok404=True)
        unchanged = (ref is not None and pr is not None
                     and self._branch_is_current(repo, branch, ref["object"]["sha"], base_sha, path, content))
        if not unchanged:
            if ref is None:
                self._call("POST", f"/repos/{repo}/git/refs", {"ref": f"refs/heads/{branch}", "sha": base_sha})
            else:  # reset the bot branch so the PR always holds exactly one fresh change on top of base
                self._call("PATCH", f"/repos/{repo}/git/refs/heads/{urllib.parse.quote(branch)}",
                           {"sha": base_sha, "force": True})
            _, file_sha = self.get_file(repo, path, branch)
            self._call("PUT", f"/repos/{repo}/contents/{urllib.parse.quote(path)}", {
                "message": title, "content": base64.b64encode(content.encode()).decode(),
                "sha": file_sha, "branch": branch})
        if pr:
            self._call("PATCH", f"/repos/{repo}/pulls/{pr['number']}", {"title": title, "body": body})
        else:
            try:
                pr = self._call("POST", f"/repos/{repo}/pulls",
                                {"title": title, "head": branch, "base": base, "body": body, "draft": draft})
            except GitHubError as e:
                if not draft or "draft" not in str(e).lower():
                    raise
                warn("draft PRs not supported - opening a normal PR; the CI guard fails it on the "
                     "[DRY RUN] title / do-not-merge label")
                pr = self._call("POST", f"/repos/{repo}/pulls",
                                {"title": title, "head": branch, "base": base, "body": body})
        if labels:
            try:
                self._call("POST", f"/repos/{repo}/issues/{pr['number']}/labels", {"labels": labels})
            except GitHubError as e:  # labels are informational; the CI guard is the real control
                warn(f"could not add labels: {e}")
        return pr.get("html_url", "")
