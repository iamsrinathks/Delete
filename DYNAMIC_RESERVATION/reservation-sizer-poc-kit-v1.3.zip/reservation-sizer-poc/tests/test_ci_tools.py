"""Tests for the CI guards and the HCL->JSON converter. Run:  python3 -m unittest discover -s tests -v"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECK = os.path.join(KIT, "ci", "check_reservation_change.py")
PLAN = os.path.join(KIT, "ci", "check_tf_plan.py")
HCL = os.path.join(KIT, "terraform", "hcl_map_to_json.py")
GUARD_YML = os.path.join(KIT, "ci", "reservation-sizer-guard.yml")
RENDER = os.path.join(KIT, "setup", "05-render-k8s.py")

BASE = {"node_pool_reservations": {
    "k-a": {"enabled": True, "name": "res-a", "zone": "r1-a", "machine_type": "m-8", "instance_count": 14},
    "k-b": {"enabled": True, "name": "res-b", "zone": "r1-b", "machine_type": "m-8", "instance_count": 13}}}


def dump(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f)


def write(path, text):
    with open(path, "w") as f:
        f.write(text)


def read_text(path):
    with open(path) as f:
        return f.read()


def load(path):
    with open(path) as f:
        return json.load(f)


def run(*args):
    p = subprocess.run([sys.executable, *args], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


class ChangeCheck(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def check(self, head, changed=None, extra=()):
        b, h = os.path.join(self.d, "b.json"), os.path.join(self.d, "h.json")
        dump(BASE, b)
        dump(head, h)
        args = [CHECK, "--base", b, "--head", h, "--max-step", "3", *extra]
        if changed is not None:
            c = os.path.join(self.d, "changed.txt")
            write(c, "\n".join(changed) + "\n")
            args += ["--changed-files", c, "--allowed-path", "ws/node_pool_reservations.auto.tfvars.json"]
        return run(*args)

    def head(self, **counts):
        h = json.loads(json.dumps(BASE))
        for k, v in counts.items():
            h["node_pool_reservations"][k.replace("_", "-")]["instance_count"] = v
        return h

    def test_valid_increase(self):
        code, out = self.check(self.head(k_a=16), ["ws/node_pool_reservations.auto.tfvars.json"])
        self.assertEqual(code, 0, out)

    def test_decrease_rejected(self):
        code, out = self.check(self.head(k_a=12))
        self.assertEqual(code, 1)
        self.assertIn("decrease", out)

    def test_step_too_big(self):
        code, out = self.check(self.head(k_a=18))
        self.assertEqual(code, 1)
        self.assertIn("exceeds max step", out)

    def test_other_field_changed(self):
        h = self.head(k_a=15)
        h["node_pool_reservations"]["k-a"]["machine_type"] = "m-16"
        code, out = self.check(h)
        self.assertEqual(code, 1)
        self.assertIn("machine_type", out)

    def test_key_added(self):
        h = self.head(k_a=15)
        h["node_pool_reservations"]["k-c"] = dict(BASE["node_pool_reservations"]["k-a"], zone="r1-c")
        code, out = self.check(h)
        self.assertEqual(code, 1)
        self.assertIn("added", out)

    def test_other_file_changed(self):
        code, out = self.check(self.head(k_a=15), ["ws/node_pool_reservations.auto.tfvars.json", "ws/iam.tf"])
        self.assertEqual(code, 1)
        self.assertIn("ws/iam.tf", out)

    def test_no_change(self):
        code, out = self.check(self.head())
        self.assertEqual(code, 1)
        self.assertIn("no count changed", out)

    def test_string_count_rejected(self):
        h = self.head()
        h["node_pool_reservations"]["k-a"]["instance_count"] = "15"
        code, _ = self.check(h)
        self.assertEqual(code, 1)


class PlanCheck(unittest.TestCase):
    def plan(self, changes):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "plan.json")
        dump({"resource_changes": changes}, p)
        return run(PLAN, p)

    @staticmethod
    def rc(actions, before, after, typ="google_compute_reservation", addr='module.r.google_compute_reservation.this["k-a"]'):
        return {"address": addr, "type": typ, "change": {"actions": actions, "before": before, "after": after}}

    def test_count_update_ok(self):
        b = {"name": "res-a", "specific_reservation": [{"count": 14, "in_use_count": 13}]}
        a = {"name": "res-a", "specific_reservation": [{"count": 16, "in_use_count": 13}]}
        code, out = self.plan([self.rc(["update"], b, a)])
        self.assertEqual(code, 0, out)

    def test_replace_rejected(self):
        code, _ = self.plan([self.rc(["delete", "create"], {"name": "a"}, {"name": "b"})])
        self.assertEqual(code, 1)

    def test_other_attr_rejected(self):
        b = {"name": "res-a", "specific_reservation": [{"count": 14}], "description": "x"}
        a = {"name": "res-a", "specific_reservation": [{"count": 15}], "description": "y"}
        code, out = self.plan([self.rc(["update"], b, a)])
        self.assertEqual(code, 1)
        self.assertIn("description", out)

    def test_other_resource_rejected(self):
        code, _ = self.plan([self.rc(["update"], {}, {"x": 1}, typ="google_project_iam_member", addr="x")])
        self.assertEqual(code, 1)

    def test_computed_after_apply_not_counted(self):
        # v1.1 failed this real-world shape: status / in_use_count become "(known after apply)"
        b = {"name": "res-a", "status": "READY", "specific_reservation": [{"count": 14, "in_use_count": 13}]}
        a = {"name": "res-a", "specific_reservation": [{"count": 16}]}
        rc = self.rc(["update"], b, a)
        rc["change"]["after_unknown"] = {"status": True, "specific_reservation": [{"in_use_count": True}]}
        code, out = self.plan([rc])
        self.assertEqual(code, 0, out)
        self.assertIn("computed after apply", out)

    def test_known_change_still_rejected_next_to_unknowns(self):
        b = {"name": "res-a", "status": "READY", "description": "x", "specific_reservation": [{"count": 14}]}
        a = {"name": "res-a", "description": "y", "specific_reservation": [{"count": 15}]}
        rc = self.rc(["update"], b, a)
        rc["change"]["after_unknown"] = {"status": True}
        code, out = self.plan([rc])
        self.assertEqual(code, 1)
        self.assertIn("description", out)


class HclConvert(unittest.TestCase):
    def test_roundtrip_and_strip(self):
        d = tempfile.mkdtemp()
        src = os.path.join(d, "terraform.tfvars")
        write(src, '''project_id = "p1"   # keep me
# reservations per zone
node_pool_reservations = {
  "res-ew-m8-a" = {
    enabled        = true
    name           = "res-ew-m8"   // inline comment
    zone           = "r1-a"
    machine_type   = "m-8"
    instance_count = 14
  }
  res-ew-m8-b = {
    enabled = false, name = "res-ew-m8", zone = "r1-b", machine_type = "m-8", instance_count = 13
  }
}
other = 3
''')
        out = os.path.join(d, "node_pool_reservations.auto.tfvars.json")
        code, msg = run(HCL, src, "--out", out, "--strip")
        self.assertEqual(code, 0, msg)
        doc = load(out)["node_pool_reservations"]
        self.assertEqual(doc["res-ew-m8-a"]["instance_count"], 14)
        self.assertIs(doc["res-ew-m8-b"]["enabled"], False)
        with open(src + ".new") as f:
            new = f.read()
        self.assertNotIn("instance_count", new)
        self.assertIn('project_id = "p1"', new)
        self.assertIn("other = 3", new)

    def test_expression_rejected(self):
        d = tempfile.mkdtemp()
        src = os.path.join(d, "t.tfvars")
        write(src, 'node_pool_reservations = {\n  a = { instance_count = var.x }\n}\n')
        code, _ = run(HCL, src, "--out", os.path.join(d, "o.json"))
        self.assertNotEqual(code, 0)


def guard_script():
    """The `run: |` block of the workflow, exactly as GitHub Actions would execute it."""
    lines = read_text(GUARD_YML).splitlines()
    i = next(n for n, line in enumerate(lines) if line.strip() == "run: |")
    indent = len(lines[i + 1]) - len(lines[i + 1].lstrip())
    body = []
    for line in lines[i + 1:]:
        if line.strip() and len(line) - len(line.lstrip()) < indent:
            break
        body.append(line[indent:])
    return "\n".join(body) + "\n"


def git(repo, *args):
    subprocess.run(["git", "-C", repo, *args], check=True, capture_output=True, text=True)


@unittest.skipUnless(shutil.which("git") and shutil.which("bash"), "needs git and bash")
class GuardWorkflow(unittest.TestCase):
    """Runs the guard's shell logic in a real git repo whose HEAD is a PR merge commit."""
    TF = "ws/node_pool_reservations.auto.tfvars.json"

    def setUp(self):
        self.repo, self.tmp = tempfile.mkdtemp(), tempfile.mkdtemp()
        git(self.repo, "init", "-q", "-b", "main")
        git(self.repo, "config", "user.email", "t@example.com")
        git(self.repo, "config", "user.name", "t")
        os.makedirs(os.path.join(self.repo, "ci"))
        os.makedirs(os.path.join(self.repo, "ws"))
        shutil.copy(CHECK, os.path.join(self.repo, "ci", "check_reservation_change.py"))
        dump(BASE, os.path.join(self.repo, self.TF))
        write(os.path.join(self.repo, "README"), "v1\n")
        git(self.repo, "add", "-A")
        git(self.repo, "commit", "-qm", "base")

    def pr(self, branch, files, main_moves=False):
        git(self.repo, "checkout", "-q", "-b", branch)
        for path, text in files.items():
            write(os.path.join(self.repo, path), text)
        git(self.repo, "commit", "-qam", "change")
        git(self.repo, "checkout", "-q", "main")
        if main_moves:   # someone merges to main after the PR was opened
            write(os.path.join(self.repo, "README"), "v2\n")
            git(self.repo, "commit", "-qam", "unrelated change on main")
        git(self.repo, "checkout", "-q", "--detach", "main")
        git(self.repo, "merge", "-q", "--no-ff", "--no-edit", branch)   # = refs/pull/N/merge

    def run_guard(self, head_ref, title="t", labels="[]"):
        env = dict(os.environ, HEAD_REF=head_ref, PR_TITLE=title, PR_LABELS=labels, TFVARS_PATH=self.TF,
                   MAX_STEP="3", RUNNER_TEMP=self.tmp)
        p = subprocess.run(["bash", "-c", guard_script()], cwd=self.repo, env=env, capture_output=True, text=True)
        return p.returncode, p.stdout + p.stderr

    def head(self, **counts):
        h = json.loads(json.dumps(BASE))
        for k, v in counts.items():
            h["node_pool_reservations"][k.replace("_", "-")]["instance_count"] = v
        return json.dumps(h)

    def test_bot_pr_valid(self):
        self.pr("reservation-sizer/pre-c1", {self.TF: self.head(k_a=16)})
        code, out = self.run_guard("reservation-sizer/pre-c1")
        self.assertEqual(code, 0, out)

    def test_item6_checker_runs_from_base_not_from_the_pr(self):
        tampered = "import sys\nprint('TAMPERED')\nsys.exit(0)\n"
        self.pr("reservation-sizer/pre-c1", {self.TF: self.head(k_a=2), "ci/check_reservation_change.py": tampered})
        code, out = self.run_guard("reservation-sizer/pre-c1")
        self.assertNotEqual(code, 0, out)
        self.assertNotIn("TAMPERED", out)
        self.assertIn("ci/check_reservation_change.py", out)          # extra file reported by the base checker

    def test_item6_main_moving_after_the_pr_is_not_blamed_on_it(self):
        self.pr("reservation-sizer/pre-c1", {self.TF: self.head(k_a=16)}, main_moves=True)
        code, out = self.run_guard("reservation-sizer/pre-c1")
        self.assertEqual(code, 0, out)

    def test_item6_needs_a_merge_commit(self):
        code, out = self.run_guard("reservation-sizer/pre-c1")          # HEAD is a plain commit
        self.assertNotEqual(code, 0)
        self.assertIn("merge commit", out)

    def test_item7_do_not_merge_label_fails(self):
        self.pr("reservation-sizer/pre-c1", {self.TF: self.head(k_a=16)})
        code, out = self.run_guard("reservation-sizer/pre-c1", labels='[\n  "reservation-sizer",\n  "do-not-merge"\n]')
        self.assertEqual(code, 1, out)
        self.assertIn("do-not-merge", out)

    def test_item7_dry_run_title_fails_even_without_label(self):
        self.pr("reservation-sizer/pre-c1", {self.TF: self.head(k_a=16)})
        code, out = self.run_guard("reservation-sizer/pre-c1", title="[DRY RUN] reservation-sizer: pre/c1")
        self.assertEqual(code, 1, out)

    def test_human_pr_unrelated_passes(self):
        self.pr("feature/x", {"README": "docs\n"})
        code, out = self.run_guard("feature/x")
        self.assertEqual(code, 0, out)
        self.assertIn("nothing to check", out)

    def test_human_pr_shape_change_only_warns(self):
        h = json.loads(self.head())
        h["node_pool_reservations"]["k-c"] = dict(BASE["node_pool_reservations"]["k-a"], zone="r1-c")
        self.pr("feature/new-zone", {self.TF: json.dumps(h)})
        code, out = self.run_guard("feature/new-zone")
        self.assertEqual(code, 0, out)
        self.assertIn("::warning::", out)

    def test_title_is_never_executed(self):
        self.pr("feature/x", {"README": "docs\n"})
        code, out = self.run_guard("feature/x", title='$(touch pwned) `touch pwned2` "; exit 1')
        self.assertEqual(code, 0, out)
        self.assertFalse(os.path.exists(os.path.join(self.repo, "pwned")))
        self.assertFalse(os.path.exists(os.path.join(self.repo, "pwned2")))

    def test_workflow_triggers_and_env(self):
        text = read_text(GUARD_YML)
        self.assertRegex(text, r"types: \[[^\]]*labeled[^\]]*unlabeled")
        self.assertIn("toJSON(github.event.pull_request.labels.*.name)", text)
        self.assertNotRegex(guard_script(), r"\$\{\{")              # no expressions inside run:
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML not installed")
        doc = yaml.safe_load(text)
        self.assertIn("labeled", doc[True]["pull_request"]["types"])     # YAML 1.1 reads `on` as True


@unittest.skipUnless(os.path.exists(RENDER), "render script missing")
class RenderManifests(unittest.TestCase):
    def render(self, **values):
        d = tempfile.mkdtemp()
        env = read_text(os.path.join(KIT, "config", "sizer.env.example"))
        base = {"PROJECT_ID": "p", "CLUSTER_NAME": "c1", "CLUSTER_LOCATION": "r1", "ENV_NAME": "pre",
                "SYSTEM_POOL": "system", "IMAGE": "reg/sizer:poc-1.3.0"}
        for k, v in {**base, **values}.items():
            env = re.sub(rf'^{k}="[^"]*"', f'{k}="{v}"', env, flags=re.M)
        write(os.path.join(d, "sizer.env"), env)
        dump({"mode": "report", "pools": ["system"]}, os.path.join(d, "policy.json"))
        code, out = run(RENDER, "--env", os.path.join(d, "sizer.env"), "--policy", os.path.join(d, "policy.json"),
                        "--out", os.path.join(d, "out"))
        return code, out, d

    def test_pat_mode_renders_token_secret(self):
        code, out, d = self.render(GITHUB_TOKEN_SECRET="sizer-github-token")
        self.assertEqual(code, 0, out)
        self.assertIn('GITHUB_TOKEN_SECRET, value: "sizer-github-token"', read_text(os.path.join(d, "out", "cronjob.yaml")))

    def test_token_and_app_together_refused(self):
        code, out, _ = self.render(GITHUB_TOKEN_SECRET="t", GITHUB_APP_ID="1")
        self.assertNotEqual(code, 0)
        self.assertIn("not both", out)

    def test_cronjob_has_pod_failure_policy(self):
        code, out, d = self.render()
        self.assertEqual(code, 0, out)
        cron = read_text(os.path.join(d, "out", "cronjob.yaml"))
        self.assertIn("podFailurePolicy", cron)
        try:
            import yaml
        except ImportError:
            return
        job = yaml.safe_load(cron)["spec"]["jobTemplate"]["spec"]
        rule = job["podFailurePolicy"]["rules"][0]
        self.assertEqual((rule["action"], rule["onExitCodes"]["values"]), ("FailJob", [2, 3, 4, 5]))
        self.assertEqual(job["template"]["spec"]["restartPolicy"], "Never")   # required by podFailurePolicy
        for name in os.listdir(os.path.join(d, "out")):
            yaml.safe_load(read_text(os.path.join(d, "out", name)))                # every manifest parses


if __name__ == "__main__":
    unittest.main()
