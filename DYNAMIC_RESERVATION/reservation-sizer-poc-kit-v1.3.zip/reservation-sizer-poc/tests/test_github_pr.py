"""End-to-end tests of sizer/github_pr.py against a local, stateful mock GitHub API (needs PyJWT[crypto]).
Run:  python3 -m unittest discover -s tests -v
"""

import base64
import json
import os
import ssl
import sys
import tempfile
import threading
import unittest
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest import mock

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(KIT, "sizer"))

try:
    import jwt  # noqa: F401
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    HAVE_JWT = True
except ImportError:  # pragma: no cover
    HAVE_JWT = False

REPO, PATH, BASE_SHA = "org/infra", "ws/node_pool_reservations.auto.tfvars.json", "base000"
BRANCH = "reservation-sizer/pre-c1"
FILE = json.dumps({"node_pool_reservations": {"k": {"instance_count": 1}}})


def content(n):
    return json.dumps({"node_pool_reservations": {"k": {"instance_count": n}}})


class Mock(BaseHTTPRequestHandler):
    """Tiny in-memory GitHub: branches, commits, one file, PRs, labels, comments."""
    calls = []
    st = {}

    @classmethod
    def reset(cls):
        cls.calls.clear()
        cls.st.clear()
        cls.st.update({"branches": {"main": {"sha": BASE_SHA, "file": FILE}}, "commits": {BASE_SHA: []},
                       "prs": [], "comments": [], "n": 0, "labels_forbidden": False, "no_drafts": False,
                       "repo_headers": {}, "repo_status": 200})

    def log_message(self, *a):
        pass

    def _send(self, code, obj=None, headers=None):
        body = json.dumps(obj).encode() if obj is not None else b""
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle(self, method):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n)) if n else None
        url = urllib.parse.urlparse(self.path)
        path, q = urllib.parse.unquote(url.path), dict(urllib.parse.parse_qsl(url.query))
        Mock.calls.append((method, path, body, self.headers.get("Authorization", "")))
        st, br = Mock.st, Mock.st["branches"]
        r = f"/repos/{REPO}"
        if method == "POST" and path.endswith("/access_tokens"):
            return self._send(201, {"token": "inst-token"})
        if method == "GET" and path == r:
            if st["repo_status"] != 200:
                return self._send(st["repo_status"], {"message": "Bad credentials"})
            return self._send(200, {"default_branch": "main"}, headers=st["repo_headers"])
        if method == "GET" and path.startswith(f"{r}/git/ref/heads/"):
            name = path[len(f"{r}/git/ref/heads/"):]
            return self._send(200, {"object": {"sha": br[name]["sha"]}}) if name in br else self._send(404, {"message": "Not Found"})
        if method == "POST" and path == f"{r}/git/refs":
            name = body["ref"][len("refs/heads/"):]
            br[name] = {"sha": body["sha"], "file": br["main"]["file"]}
            return self._send(201, {})
        if method == "PATCH" and path.startswith(f"{r}/git/refs/heads/"):
            name = path[len(f"{r}/git/refs/heads/"):]
            br[name] = {"sha": body["sha"], "file": br["main"]["file"]}      # force reset to base
            return self._send(200, {})
        if method == "GET" and path.startswith(f"{r}/git/commits/"):
            sha = path.rsplit("/", 1)[-1]
            return self._send(200, {"sha": sha, "parents": [{"sha": p} for p in st["commits"].get(sha, [])]})
        if method == "GET" and path == f"{r}/contents/{PATH}":
            f = br[q.get("ref", "main")]["file"]
            return self._send(200, {"content": base64.b64encode(f.encode()).decode(), "sha": "filesha"})
        if method == "PUT" and path == f"{r}/contents/{PATH}":
            b = br[body["branch"]]
            st["n"] += 1
            new_sha = f"c{st['n']}"
            st["commits"][new_sha] = [b["sha"]]
            b.update(sha=new_sha, file=base64.b64decode(body["content"]).decode())
            return self._send(200, {})
        if method == "GET" and path == f"{r}/pulls":
            head = q.get("head", "").split(":", 1)[-1]
            return self._send(200, [p for p in st["prs"] if p["head"] == head and p["state"] == "open"])
        if method == "POST" and path == f"{r}/pulls":
            if body.get("draft") and st["no_drafts"]:
                return self._send(422, {"message": "Draft pull requests are not supported in this repository."})
            num = 7 + len(st["prs"])
            pr = {"number": num, "html_url": f"http://pr/{num}", "head": body["head"], "state": "open",
                  "draft": bool(body.get("draft")), "title": body["title"], "body": body["body"], "labels": []}
            st["prs"].append(pr)
            return self._send(201, pr)
        if method == "PATCH" and path.startswith(f"{r}/pulls/"):
            pr = next(p for p in st["prs"] if p["number"] == int(path.rsplit("/", 1)[-1]))
            pr.update({k: v for k, v in body.items() if k in ("title", "body", "state")})
            return self._send(200, pr)
        if method == "POST" and path.endswith("/labels"):
            if st["labels_forbidden"]:
                return self._send(403, {"message": "Resource not accessible by integration"})  # must be non-fatal
            pr = next(p for p in st["prs"] if p["number"] == int(path.split("/")[-2]))
            pr["labels"] += [{"name": x} for x in body["labels"]]
            return self._send(200, pr["labels"])
        if method == "POST" and path.endswith("/comments"):
            st["comments"].append((int(path.split("/")[-2]), body["body"]))
            return self._send(201, {})
        return self._send(500, {"message": f"unexpected {method} {path}"})

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_PATCH(self):
        self._handle("PATCH")


def calls(method, prefix):
    return [c for c in Mock.calls if c[0] == method and c[1].startswith(prefix)]


@unittest.skipUnless(HAVE_JWT, "PyJWT[crypto] not installed")
class GitHubPrTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.pop("HTTPS_PROXY", None)
        os.environ.pop("HTTP_PROXY", None)
        os.environ["NO_PROXY"] = "127.0.0.1,localhost"
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), Mock)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.api = f"http://127.0.0.1:{cls.srv.server_port}"
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                    serialization.NoEncryption()).decode()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def setUp(self):
        Mock.reset()
        import github_pr
        self.m = github_pr
        self.gh = github_pr.GitHub.from_app(self.api, "123", "456", self.pem, repo=REPO)

    def raise_pr(self, n, draft=False, body="body", title=None):
        title = title or (("[DRY RUN] " if draft else "") + "reservation-sizer: pre/c1 increase reservations")
        labels = ["reservation-sizer"] + (["do-not-merge"] if draft else [])
        return self.gh.raise_pr(REPO, None, PATH, content(n), body, branch=BRANCH, title=title, draft=draft, labels=labels)

    def open_prs(self):
        return [p for p in Mock.st["prs"] if p["state"] == "open"]

    def test_token_is_down_scoped_and_pr_flow(self):
        method, path, body, auth = Mock.calls[0]
        self.assertEqual(path, "/app/installations/456/access_tokens")
        self.assertEqual(body["repositories"], ["infra"])
        self.assertEqual(body["permissions"], {"contents": "write", "pull_requests": "write"})
        self.assertTrue(auth.startswith("Bearer ey"))                       # signed App JWT
        Mock.st["labels_forbidden"] = True                                   # labels failing is non-fatal
        url = self.raise_pr(3, draft=True)
        self.assertEqual(url, "http://pr/7")
        self.assertEqual(Mock.st["branches"][BRANCH]["file"], content(3))
        self.assertTrue(Mock.st["prs"][0]["draft"])
        self.assertTrue(all(c[3] == "Bearer inst-token" for c in Mock.calls[1:]))
        self.assertEqual(len(calls("PUT", f"/repos/{REPO}/contents/")), 1)  # exactly one file committed

    def test_changed_content_resets_branch_and_updates_same_pr(self):
        self.raise_pr(3)
        Mock.calls.clear()
        self.raise_pr(4, body="body2")
        self.assertEqual(calls("PATCH", f"/repos/{REPO}/git/refs/heads/")[0][2], {"sha": BASE_SHA, "force": True})
        self.assertEqual(len(calls("PUT", f"/repos/{REPO}/contents/")), 1)
        self.assertFalse(calls("POST", f"/repos/{REPO}/pulls"))            # updated, not duplicated
        self.assertEqual(Mock.st["prs"][0]["body"], "body2")
        self.assertEqual(Mock.st["branches"][BRANCH]["file"], content(4))

    # ---- item 9: unchanged content -> no push (no CI re-run, approvals keep their meaning)
    def test_item9_unchanged_content_is_not_pushed_again(self):
        self.raise_pr(3)
        Mock.calls.clear()
        self.raise_pr(3, body="evidence of today")
        self.assertFalse(calls("PATCH", f"/repos/{REPO}/git/refs/heads/"))
        self.assertFalse(calls("PUT", f"/repos/{REPO}/contents/"))
        self.assertEqual(Mock.st["prs"][0]["body"], "evidence of today")   # body still refreshed

    def test_item9_base_moved_means_push_even_if_content_same(self):
        self.raise_pr(3)
        Mock.st["branches"]["main"]["sha"] = "base001"                     # main moved on
        Mock.st["commits"]["base001"] = [BASE_SHA]
        Mock.calls.clear()
        self.raise_pr(3)
        self.assertEqual(calls("PATCH", f"/repos/{REPO}/git/refs/heads/")[0][2]["sha"], "base001")

    def test_item9_close_bot_pr(self):
        self.raise_pr(3)
        url = self.gh.close_bot_pr(REPO, BRANCH, "no increase is needed any more")
        self.assertEqual(url, "http://pr/7")
        self.assertEqual(Mock.st["prs"][0]["state"], "closed")
        self.assertEqual(Mock.st["comments"], [(7, "no increase is needed any more")])
        self.assertIsNone(self.gh.close_bot_pr(REPO, BRANCH, "again"))     # nothing open -> no-op

    # ---- item 8: a dry-run PR never silently becomes the live PR (and vice versa)
    def test_item8_switch_dry_run_to_live_replaces_the_pr(self):
        self.raise_pr(3, draft=True)
        self.raise_pr(3, draft=False)
        old, new = Mock.st["prs"]
        self.assertEqual(old["state"], "closed")
        self.assertIn("mode changed to live", Mock.st["comments"][0][1])
        self.assertEqual(new["state"], "open")
        self.assertFalse(new["draft"])
        self.assertFalse(new["title"].startswith("[DRY RUN]"))
        self.assertNotIn("do-not-merge", [x["name"] for x in new["labels"]])

    def test_item8_switch_live_to_dry_run_replaces_the_pr(self):
        self.raise_pr(3)
        self.raise_pr(3, draft=True)
        self.assertEqual([p["state"] for p in Mock.st["prs"]], ["closed", "open"])
        self.assertTrue(self.open_prs()[0]["draft"])

    def test_item8_dry_run_detected_by_title_or_label(self):
        self.assertTrue(self.m.is_dry_run_pr({"draft": False, "title": "[DRY RUN] x", "labels": []}))
        self.assertTrue(self.m.is_dry_run_pr({"draft": False, "title": "x", "labels": [{"name": "do-not-merge"}]}))
        self.assertFalse(self.m.is_dry_run_pr({"draft": False, "title": "x", "labels": [{"name": "reservation-sizer"}]}))

    # ---- item 7: no drafts on this repo -> a normal PR that is still marked as dry run
    def test_item7_draft_fallback_keeps_dry_run_markers(self):
        Mock.st["no_drafts"] = True
        self.raise_pr(3, draft=True)
        pr = self.open_prs()[0]
        self.assertFalse(pr["draft"])
        self.assertTrue(pr["title"].startswith("[DRY RUN] "))
        self.assertIn("do-not-merge", [x["name"] for x in pr["labels"]])
        Mock.calls.clear()
        self.raise_pr(3, draft=True)                                       # still recognised as dry-run:
        self.assertEqual(len(Mock.st["prs"]), 1)                            # no close/re-open churn

    # ---- item 4: the corporate CA bundle is added to the public roots
    def test_item4_ssl_context_keeps_public_roots(self):
        sys.path.insert(0, os.path.join(KIT, "sizer", "tests"))
        from test_sizer import TEST_CA_PEM
        d = tempfile.mkdtemp()
        pem = os.path.join(d, "corp.pem")
        with open(pem, "w") as fh:
            fh.write(TEST_CA_PEM)
        orig = ssl.SSLContext.load_default_certs
        with mock.patch.object(ssl.SSLContext, "load_default_certs", autospec=True, side_effect=orig) as m:
            ctx = self.m.ssl_context(pem)
        self.assertTrue(m.called)
        self.assertIn("Test Corporate Root CA",
                      [dict(x[0] for x in c["subject"]).get("commonName") for c in ctx.get_ca_certs()])


def start_mock():
    os.environ.pop("HTTPS_PROXY", None)
    os.environ.pop("HTTP_PROXY", None)
    os.environ["NO_PROXY"] = "127.0.0.1,localhost"
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Mock)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_port}"


class GitHubPatTest(unittest.TestCase):
    """PAT mode (v1.3): no GitHub App, no PyJWT needed."""

    @classmethod
    def setUpClass(cls):
        cls.srv, cls.api = start_mock()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def setUp(self):
        Mock.reset()
        import github_pr
        self.m = github_pr

    def test_pat_is_used_for_every_call_and_no_app_token_is_made(self):
        gh = self.m.GitHub.from_token(self.api, "github_pat_abc\n", repo=REPO)   # newline from the secret is stripped
        self.assertEqual(Mock.calls[0][:2], ("GET", f"/repos/{REPO}"))            # access proved at once
        gh.raise_pr(REPO, None, PATH, content(3), "body", branch=BRANCH, title="t", draft=False,
                    labels=["reservation-sizer"])
        self.assertFalse([c for c in Mock.calls if c[1].endswith("/access_tokens")])
        self.assertTrue(all(c[3] == "Bearer github_pat_abc" for c in Mock.calls))
        self.assertEqual(Mock.st["branches"][BRANCH]["file"], content(3))
        self.assertEqual(gh.auth_kind, "pat")

    def test_fine_grained_token_info(self):
        Mock.st["repo_headers"] = {"GitHub-Authentication-Token-Expiration": "2026-12-31 00:00:00 UTC"}
        info = self.m.GitHub.from_token(self.api, "github_pat_abc", repo=REPO).token_info()
        self.assertFalse(info["classic"])
        self.assertIsNone(info["scopes"])
        self.assertEqual(info["expires"], 1798675200)                              # 2026-12-31T00:00:00Z

    def test_classic_token_scopes_reported(self):
        Mock.st["repo_headers"] = {"X-OAuth-Scopes": "repo, workflow"}
        info = self.m.GitHub.from_token(self.api, "ghp_abc", repo=REPO).token_info()
        self.assertTrue(info["classic"])
        self.assertEqual(info["scopes"], ["repo", "workflow"])
        self.assertIsNone(info["expires"])

    def test_bad_token_fails_at_once(self):
        Mock.st["repo_status"] = 401
        with self.assertRaises(self.m.GitHubError) as cm:
            self.m.GitHub.from_token(self.api, "github_pat_revoked", repo=REPO)
        self.assertIn("401", str(cm.exception))
        self.assertNotIn("github_pat_revoked", str(cm.exception))                 # the token is never echoed

    def test_empty_or_broken_token_rejected_without_a_call(self):
        for bad in ("", "  \n", "github_pat_a b"):
            with self.assertRaises(self.m.GitHubError):
                self.m.GitHub.from_token(self.api, bad, repo=REPO)
        self.assertFalse(Mock.calls)

    def test_parse_expiry_formats(self):
        self.assertEqual(self.m.parse_expiry("2026-12-31 00:00:00 UTC"), 1798675200)
        self.assertEqual(self.m.parse_expiry("2026-12-30 16:00:00 -0800"), 1798675200)
        self.assertEqual(self.m.parse_expiry("2026-12-31T00:00:00Z"), 1798675200)
        self.assertIsNone(self.m.parse_expiry("next tuesday"))


if __name__ == "__main__":
    unittest.main()
