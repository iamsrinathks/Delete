#!/usr/bin/env python3
"""
preflight.py - READ-ONLY checks before building anything. Uses your own gcloud credentials.

  python3 setup/preflight.py --project P --location REGION --cluster C \
      --policy config/policy.json [--tfvars-file path/to/node_pool_reservations.auto.tfvars.json]

Checks: cluster logging/monitoring/Workload Identity/datapath, in-scope node pools and MIGs,
pools sharing machine types (ANY reservations are consumed by all of them), reservations in
the region (count / in use / commitment / specific-required), autoscaler visibility logs and
stockouts, history coverage from BOTH metric sources, and the tfvars file against reality.
Exit code 0 = no blockers, 1 = blockers found.
"""

import argparse
import json
import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sizer"))
import reservation_sizer as rs  # noqa: E402

BLOCKERS, WARNINGS = [], []


def ok(m):
    print(f"  OK    {m}")


def warn(m):
    WARNINGS.append(m)
    print(f"  WARN  {m}")


def bad(m):
    BLOCKERS.append(m)
    print(f"  FAIL  {m}")


def section(t):
    print(f"\n== {t}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--location", required=True)
    ap.add_argument("--cluster", required=True)
    ap.add_argument("--policy", required=True)
    ap.add_argument("--tfvars-file")
    ap.add_argument("--ca-bundle")
    ap.add_argument("--hours", type=int, default=48, help="history sample used for the coverage check")
    a = ap.parse_args()

    pol = rs.load_policy(a.policy)
    http = rs.Http(a.ca_bundle)
    gcp = rs.Gcp(a.project, a.location, a.cluster, http, rs.Token(http))

    section("Cluster")
    try:
        cl = gcp.cluster_info()
    except rs.SizerError as e:
        bad(f"cannot read cluster: {e}")
        return finish()
    ok(f"{cl.get('name')} in {cl.get('location')}, version {cl.get('currentMasterVersion')}")
    log_comp = ((cl.get("loggingConfig") or {}).get("componentConfig") or {}).get("enableComponents", [])
    if "SYSTEM_COMPONENTS" in log_comp or (cl.get("loggingService") or "").startswith("logging.googleapis.com"):
        ok(f"Cloud Logging enabled (components: {', '.join(log_comp) or cl.get('loggingService')})")
    else:
        bad("Cloud Logging system components not enabled - autoscaler visibility events will not exist")
    mon_comp = ((cl.get("monitoringConfig") or {}).get("componentConfig") or {}).get("enableComponents", [])
    ok(f"Cloud Monitoring components: {', '.join(mon_comp) or 'default / none listed'}")
    wi = (cl.get("workloadIdentityConfig") or {}).get("workloadPool")
    ok(f"Workload Identity pool: {wi}") if wi else bad("Workload Identity not enabled on the cluster")
    dp = (cl.get("networkConfig") or {}).get("datapathProvider", "LEGACY_DATAPATH")
    ok(f"datapath: {dp} (ADVANCED_DATAPATH = Dataplane V2 -> see NetworkPolicy metadata-server note)")

    section("In-scope node pools")
    try:
        pools = rs.load_pools(cl, pol["pools"])
    except rs.SizerError as e:
        bad(str(e))
        return finish()
    by_mt = defaultdict(list)
    for p in cl.get("nodePools", []) or []:
        by_mt[(p.get("config") or {}).get("machineType", "")].append(p["name"])
    for pn, p in sorted(pools.items()):
        ok(f"{pn}: {p['machine_type']}, MIGs {[m['zone'] for m in p['migs']]}, maxSurge {p['max_surge']}, "
           f"strategy {p['strategy']}, affinity {p['affinity']}")
        if p["strategy"] == "BLUE_GREEN":
            warn(f"{pn}: BLUE_GREEN upgrades need ~2x nodes - surge headroom is not modelled")
        if p["affinity"] not in ("ANY_RESERVATION", "UNSPECIFIED"):
            warn(f"{pn}: reservation affinity {p['affinity']} {p['reservation_values'] or ''} - only reservations "
                 "this pool can consume are sized for it")
        if p["spot"]:
            bad(f"{pn}: Spot/preemptible pool cannot consume reservations - remove it from policy.pools")
        others = sorted(set(by_mt[p["machine_type"]]) - set(pools))
        if others:
            warn(f"{p['machine_type']} is also used by out-of-scope pools {others}: they consume ANY reservations too "
                 "but are not sized (auto-provisioned / compute-class pools included)")
    auto = [p.get("name") for p in cl.get("nodePools", []) or [] if (p.get("autoscaling") or {}).get("autoprovisioned")]
    if auto:
        warn(f"auto-provisioned pools present (not sized by the POC; names change): {sorted(auto)}")

    section("Reservations in the cluster zones")
    zones = sorted({m["zone"] for p in pools.values() for m in p["migs"]})
    try:
        actual = rs.actual_reservations(gcp, zones)
    except rs.SizerError as e:
        bad(f"cannot list reservations: {e}")
        actual = {}
    for (z, name), r in sorted(actual.items()):
        line = f"{z} {name}: {r['machine_type']} count {r['count']} in-use {r['in_use']}"
        if r["commitment"]:
            warn(line + f" - ATTACHED TO COMMITMENT {r['commitment']} (keep out of the sizer file)")
        elif r["specific_required"]:
            warn(line + " - specificReservationRequired=true (ANY pools will NOT consume it)")
        else:
            ok(line)
    if not actual:
        warn("no reservations found in the cluster zones")

    section("Autoscaler visibility logs (Cloud Logging)")
    now = rs.bucket(int(rs.time.time()))
    try:
        ents = gcp.log_entries(f"projects/{a.project}",
                               rs.stockout_filter(a.cluster, a.location, now - 7 * 86400), max_pages=1)
        ok(f"{len(ents)} visibility entries in the last 7 days (first page)") if ents else \
            warn("no autoscaler visibility entries in 7 days (quiet cluster, or logs excluded/routed elsewhere)")
        hits, n, amb = rs.stockouts(gcp, f"projects/{a.project}", a.cluster, pools, now - 30 * 86400,
                                    location=a.location, ambiguous=pol["stockoutAmbiguous"])
        ok(f"{n} stockout events in 30 days; by pool/zone: {dict(hits) or 'none'}")
        if amb:
            warn(f"{len(amb)} stockout event(s) without the failing MIG and a multi-zone scale-up "
                 f"(stockoutAmbiguous={pol['stockoutAmbiguous']}): {amb[:3]}")
    except rs.SizerError as e:
        warn(f"cannot read logs with your account ({e}) - the sizer will use its log view")

    section("GKE operations (upgrade-window exclusion)")
    try:
        ops = gcp.operations()
        ups = [o for o in ops if o.get("operationType") in pol["excludeOperationTypes"]
               and f"/clusters/{a.cluster}" in (o.get("targetLink") or "")]
        oldest = min((o.get("startTime", "") for o in ops if o.get("startTime")), default="none")
        ok(f"{len(ops)} operations listed, oldest {oldest[:19]}; {len(ups)} of type {pol['excludeOperationTypes']} on this cluster")
        if oldest != "none" and rs.parse_ts(oldest) > now - int(pol["windowDays"]) * 86400:
            warn(f"operations history is shorter than windowDays={pol['windowDays']} - older upgrade surges "
                 "cannot be excluded (they can inflate peaks; maxStep and human review still apply)")
    except rs.SizerError as e:
        bad(f"cannot list GKE operations: {e}")

    section(f"History coverage, last {a.hours}h (5-minute buckets)")
    start, expected = now - a.hours * 3600, a.hours * 3600 // rs.ALIGN
    region = a.location if not rs.re.match(r"^[a-z]+-[a-z]+\d+-[a-z]$", a.location) else a.location.rsplit("-", 1)[0]
    for source, fn in (("mig", lambda: (rs.history_mig(gcp, pools, start, now, 1), None)),
                       ("node-metric", lambda: rs.history_node_metric(gcp, pools, a.cluster, region, start, now, 1))):
        try:
            hist, cluster_buckets = fn()
        except rs.SizerError as e:
            (bad if source == pol["historySource"] else warn)(f"{source}: query failed: {e}")
            continue
        worst = 1.0
        if cluster_buckets is not None:   # node-metric: a MIG at 0 nodes has no series - judge the cluster
            worst = min(1.0, len(cluster_buckets) / expected)
            print(f"        {source:11s} cluster: coverage {worst:.0%} (buckets with any node series)")
        for pn, p in sorted(pools.items()):
            for m in p["migs"]:
                s = hist.get(m["name"], {})
                if cluster_buckets is None:
                    cov = min(1.0, len(s) / expected)
                    worst = min(worst, cov)
                    label = f"coverage {cov:.0%}"
                else:
                    label = f"buckets with nodes {len(s)}/{len(cluster_buckets)}"
                latest = s[max(s)] if s else "-"
                print(f"        {source:11s} {pn}/{m['zone']}: {label}, latest {latest}, "
                      f"max {max(s.values()) if s else '-'}")
        msg = f"{source}: worst coverage {worst:.0%}"
        if worst >= pol["minDataCoverage"]:
            ok(msg + (" <- selected in policy" if source == pol["historySource"] else ""))
        elif source == pol["historySource"]:
            bad(msg + f" < minDataCoverage {pol['minDataCoverage']:.0%} - switch historySource or investigate")
        else:
            warn(msg)

    if a.tfvars_file:
        section("tfvars file vs reality")
        try:
            with open(a.tfvars_file) as f:
                doc = json.load(f)
            entries = doc[pol["tfvarsVariable"]]
        except (OSError, ValueError, KeyError) as e:
            bad(f"cannot read map '{pol['tfvarsVariable']}' from {a.tfvars_file}: {e}")
            return finish()
        for k, e in sorted(entries.items()):
            live = actual.get((e.get("zone"), e.get("name")))
            cnt = e.get(pol["countField"])
            if not isinstance(cnt, int):
                bad(f"{k}: {pol['countField']} must be an integer, got {cnt!r}")
            if not live:
                warn(f"{k}: reservation {e.get('name')} not found in {e.get('zone')}")
            elif live["count"] != cnt:
                warn(f"{k}: file says {cnt}, Compute Engine has {live['count']} (drift - sizer will HOLD)")
            else:
                ok(f"{k}: {cnt} matches Compute Engine")
        keys = {(e.get("zone"), e.get("machine_type")) for e in entries.values()}
        for pn, p in sorted(pools.items()):
            for m in p["migs"]:
                mt = pol["machineTypeAliases"].get(p["machine_type"], p["machine_type"])
                if (m["zone"], mt) not in keys:
                    warn(f"{pn}/{m['zone']}: no key with machine_type {mt} (custom type naming? use machineTypeAliases)")

    print("\n== Manual checks (not visible from APIs)")
    print(f"  - HCP Terraform: '{pol['tfvarsVariable']}' must NOT also be set as a workspace variable")
    print("  - GitHub egress path (proxy?) from the cluster; Secret Manager secret for the App key exists")
    return finish()


def finish():
    print(f"\nSummary: {len(BLOCKERS)} blocker(s), {len(WARNINGS)} warning(s)")
    for b in BLOCKERS:
        print(f"  BLOCKER: {b}")
    return 1 if BLOCKERS else 0


if __name__ == "__main__":
    sys.exit(main())
