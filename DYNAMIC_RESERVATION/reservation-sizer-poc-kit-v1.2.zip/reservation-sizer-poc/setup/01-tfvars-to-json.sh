#!/usr/bin/env bash
# Step 1 - move node_pool_reservations from HCL tfvars into a JSON file the bot can edit.
#   ./setup/01-tfvars-to-json.sh <path/to/workspace/terraform.tfvars>
# Writes <dir>/node_pool_reservations.auto.tfvars.json and <tfvars>.new (variable removed).
# You review + commit both in ONE PR; its speculative plan must say "No changes".
SIZER_ENV_OPTIONAL=1
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need_cmd python3

TFVARS="${1:?usage: $0 <path/to/terraform.tfvars>}"
DIR="$(cd "$(dirname "$TFVARS")" && pwd)"
OUT="$DIR/node_pool_reservations.auto.tfvars.json"

python3 "$KIT_DIR/terraform/hcl_map_to_json.py" "$TFVARS" --out "$OUT" --strip

say "Review"
diff -u "$TFVARS" "$TFVARS.new" || true
cat <<EOF

Next:
  1. mv "$TFVARS.new" "$TFVARS"
  2. Check node_pool_reservations is NOT set as an HCP Terraform workspace variable.
  3. Add lifecycle { prevent_destroy = true } to the reservation resource (terraform/reservations_module_notes.md).
  4. Commit both files in one PR -> speculative plan must show: No changes.
  5. Set LOCAL_TFVARS_FILE="$OUT" and TFVARS_PATH=<repo-relative path> in config/sizer.env
EOF
