#!/usr/bin/env bash
# Step 0 - READ-ONLY checks with your own gcloud login. Changes nothing.
#   ./setup/00-preflight.sh
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need PROJECT_ID CLUSTER_NAME CLUSTER_LOCATION
need_cmd gcloud
need_cmd python3

POLICY="${POLICY_FILE:-$KIT_DIR/config/policy.json}"
[[ -f "$POLICY" ]] || { echo "ERROR: $POLICY missing. Run: cp config/policy.example.json config/policy.json (set pools)" >&2; exit 1; }

say "gcloud account: $(gcloud config get-value account 2>/dev/null)"
args=(--project "$PROJECT_ID" --location "$CLUSTER_LOCATION" --cluster "$CLUSTER_NAME" --policy "$POLICY")
[[ -n "${LOCAL_TFVARS_FILE:-}" ]] && args+=(--tfvars-file "$LOCAL_TFVARS_FILE")
[[ -n "${CA_BUNDLE:-}" ]] && args+=(--ca-bundle "$CA_BUNDLE")

python3 "$KIT_DIR/setup/preflight.py" "${args[@]}"
