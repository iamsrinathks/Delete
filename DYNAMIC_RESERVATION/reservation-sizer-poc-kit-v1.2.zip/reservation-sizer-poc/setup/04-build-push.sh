#!/usr/bin/env bash
# Step 4 - build and push the container image. Builds linux/amd64 even on Apple Silicon.
#   ./setup/04-build-push.sh
# Override the base image with your approved one:  BASE_IMAGE=<registry>/python:3.12-slim ./setup/04-build-push.sh
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need IMAGE
need_cmd docker

BASE="${BASE_IMAGE:-python:3.12-slim}"
run docker buildx build --platform linux/amd64 --build-arg "BASE_IMAGE=$BASE" \
    -t "$IMAGE" -f "$KIT_DIR/sizer/Dockerfile" "$KIT_DIR/sizer" --push
say "Pushed $IMAGE"
echo "  Pin by digest in the CronJob if your policy requires it:"
echo "  docker buildx imagetools inspect $IMAGE --format '{{json .Manifest.Digest}}'"
