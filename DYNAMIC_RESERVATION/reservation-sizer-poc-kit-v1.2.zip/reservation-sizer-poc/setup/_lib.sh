#!/usr/bin/env bash
# Shared helpers for the setup scripts. Sourced, not executed.
set -euo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${SIZER_ENV_FILE:-$KIT_DIR/config/sizer.env}"

if [[ -f "$ENV_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$ENV_FILE"
elif [[ "${SIZER_ENV_OPTIONAL:-0}" != "1" ]]; then
  echo "ERROR: $ENV_FILE not found. Run: cp config/sizer.env.example config/sizer.env  (then fill it in)" >&2
  exit 1
fi

need() {  # need VAR [VAR...] - fail if any is empty
  local missing=()
  for v in "$@"; do [[ -n "${!v:-}" ]] || missing+=("$v"); done
  if (( ${#missing[@]} )); then
    echo "ERROR: set these in $ENV_FILE: ${missing[*]}" >&2
    exit 1
  fi
}

need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' not found on PATH" >&2; exit 1; }; }

say()  { printf '\n\033[1m== %s\033[0m\n' "$*"; }
ok()   { printf '  \033[32mOK\033[0m   %s\n' "$*"; }
warn() { printf '  \033[33mWARN\033[0m %s\n' "$*"; }
bad()  { printf '  \033[31mFAIL\033[0m %s\n' "$*"; }

run() {  # echo (to stderr, shell-quoted = copy-pasteable into a change record) then run; DRY_RUN=1 only prints
  { printf '  $'; printf ' %q' "$@"; printf '\n'; } >&2
  if [[ "${DRY_RUN:-0}" != "1" ]]; then "$@"; fi
}

GSA_EMAIL="${GSA_NAME:-}@${PROJECT_ID:-}.iam.gserviceaccount.com"
export GSA_EMAIL
