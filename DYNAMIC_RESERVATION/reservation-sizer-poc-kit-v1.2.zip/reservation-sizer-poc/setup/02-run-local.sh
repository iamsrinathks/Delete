#!/usr/bin/env bash
# Step 2 - run the sizer from your laptop in REPORT mode (no PR, no writes anywhere).
#   ./setup/02-run-local.sh                       # as YOU (your gcloud login, project-level log read)
#   LOCAL_IMPERSONATE=1 ./setup/02-run-local.sh   # as the sizer GSA (after step 3): proves the
#                                                 # custom role + log view are enough on their own
# Exit codes: 0 ok, 2 fail-safe (data), 3 hold (branch != live), 4 config, 5 PR failed.
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need PROJECT_ID CLUSTER_NAME CLUSTER_LOCATION LOCAL_TFVARS_FILE
need_cmd python3
need_cmd gcloud

POLICY="${POLICY_FILE:-$KIT_DIR/config/policy.json}"
[[ -f "$POLICY" ]] || { echo "ERROR: $POLICY missing. Run: cp config/policy.example.json config/policy.json (set pools)" >&2; exit 1; }
OUT="${OUT_DIR:-$KIT_DIR/sizer-out}"
args=(--project "$PROJECT_ID" --location "$CLUSTER_LOCATION" --cluster "$CLUSTER_NAME"
      --env-name "${ENV_NAME:-local}" --policy "$POLICY" --tfvars-file "$LOCAL_TFVARS_FILE"
      --out-dir "$OUT" --mode report)
[[ -n "${CA_BUNDLE:-}" ]] && args+=(--ca-bundle "$CA_BUNDLE")

export SIZER_AUTH=gcloud            # laptop: skip the metadata server
if [[ "${LOCAL_IMPERSONATE:-0}" == "1" ]]; then
  need GSA_NAME LOG_BUCKET LOG_VIEW LOG_LOCATION
  export SIZER_IMPERSONATE_SA="$GSA_EMAIL"
  args+=(--log-resource "projects/$PROJECT_ID/locations/$LOG_LOCATION/buckets/$LOG_BUCKET/views/$LOG_VIEW")
  say "Running AS $GSA_EMAIL (needs roles/iam.serviceAccountTokenCreator on it for $(gcloud config get-value account 2>/dev/null))"
else
  [[ -n "${LOCAL_LOG_RESOURCE:-}" ]] && args+=(--log-resource "$LOCAL_LOG_RESOURCE")
  say "Running as $(gcloud config get-value account 2>/dev/null)"
fi

rm -f "$OUT/proposed.tfvars.json" "$OUT/pr_body.md"
set +e
python3 "$KIT_DIR/sizer/reservation_sizer.py" "${args[@]}"
code=$?
set -e
say "Exit code $code"
echo "  report:    $OUT/report.json"
[[ -f "$OUT/pr_body.md" ]] && echo "  PR body:   $OUT/pr_body.md"
if [[ -f "$OUT/proposed.tfvars.json" ]]; then
  echo "  proposed:  $OUT/proposed.tfvars.json"
  echo
  diff -u <(python3 -c 'import json,sys; print(json.dumps(json.load(open(sys.argv[1])), indent=2, sort_keys=True))' \
            "$LOCAL_TFVARS_FILE") "$OUT/proposed.tfvars.json" || true
fi
exit $code
