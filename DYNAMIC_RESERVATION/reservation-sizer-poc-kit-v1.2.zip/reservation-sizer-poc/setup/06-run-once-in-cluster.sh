#!/usr/bin/env bash
# Step 6 - trigger one run of the CronJob now and follow its logs (needs kubectl access).
#   ./setup/06-run-once-in-cluster.sh
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need NAMESPACE
need_cmd kubectl

JOB="reservation-sizer-manual-$(date +%Y%m%d%H%M%S)"
run kubectl -n "$NAMESPACE" create job "$JOB" --from=cronjob/reservation-sizer
run kubectl -n "$NAMESPACE" wait --for=condition=Ready pod -l job-name="$JOB" --timeout=180s || true
run kubectl -n "$NAMESPACE" logs -f "job/$JOB"
run kubectl -n "$NAMESPACE" get job "$JOB" -o jsonpath='{.status}' ; echo
