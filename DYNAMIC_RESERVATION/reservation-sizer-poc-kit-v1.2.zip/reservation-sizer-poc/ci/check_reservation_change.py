#!/usr/bin/env python3
"""
check_reservation_change.py - required PR check for reservation-sizer PRs.

  python3 ci/check_reservation_change.py --base base.json --head head.json \
      [--changed-files changed.txt --allowed-path <TFVARS_PATH>] [--max-step 3] [--allow-decrease]

Fails (exit 1) unless ALL hold:
  * only the allowed file changed (when --changed-files is given)
  * same top-level keys; only the map variable changed
  * same reservation keys (no add / remove)
  * every field except the count field is identical
  * every count change is > 0 (unless --allow-decrease) and <= --max-step
"""

import argparse
import json
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--head", required=True)
    ap.add_argument("--var", default="node_pool_reservations")
    ap.add_argument("--count-field", default="instance_count")
    ap.add_argument("--max-step", type=int, default=3)
    ap.add_argument("--allow-decrease", action="store_true")
    ap.add_argument("--changed-files", help="file with one changed path per line (git diff --name-only)")
    ap.add_argument("--allowed-path")
    a = ap.parse_args()
    errors = []

    if a.changed_files:
        with open(a.changed_files) as f:
            changed = [l.strip() for l in f if l.strip()]
        extra = [p for p in changed if p != a.allowed_path]
        if extra:
            errors.append(f"files other than {a.allowed_path} changed: {extra}")

    with open(a.base) as f:
        base = json.load(f)
    with open(a.head) as f:
        head = json.load(f)
    if set(base) != set(head):
        errors.append(f"top-level keys changed: {sorted(set(base) ^ set(head))}")
    for k in set(base) & set(head):
        if k != a.var and base[k] != head[k]:
            errors.append(f"top-level '{k}' changed - only '{a.var}' may change")
    b, h = base.get(a.var, {}), head.get(a.var, {})
    if set(b) != set(h):
        errors.append(f"reservation keys added/removed: added {sorted(set(h) - set(b))}, removed {sorted(set(b) - set(h))}")
    changes = []
    for key in sorted(set(b) & set(h)):
        be, he = b[key], h[key]
        other = {x for x in set(be) | set(he) if x != a.count_field and be.get(x) != he.get(x)}
        if other:
            errors.append(f"{key}: fields other than {a.count_field} changed: {sorted(other)}")
        bc, hc = be.get(a.count_field), he.get(a.count_field)
        if not isinstance(hc, int) or isinstance(hc, bool) or hc < 0:
            errors.append(f"{key}: {a.count_field} must be a non-negative integer, got {hc!r}")
            continue
        d = hc - (bc or 0)
        if d:
            changes.append(f"{key}: {bc} -> {hc} ({d:+d})")
        if d < 0 and not a.allow_decrease:
            errors.append(f"{key}: decrease {d} not allowed in sizer PRs")
        if abs(d) > a.max_step:
            errors.append(f"{key}: change {d:+d} exceeds max step {a.max_step}")
    if not changes:
        errors.append("no count changed")

    for c in changes:
        print(f"change: {c}")
    if errors:
        for e in errors:
            print(f"ERROR: {e}")
        return 1
    print(f"OK: {len(changes)} count change(s), all within policy")
    return 0


if __name__ == "__main__":
    sys.exit(main())
