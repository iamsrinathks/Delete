#!/usr/bin/env python3
"""
check_tf_plan.py - fail unless a Terraform plan only UPDATES reservations in place.

  terraform show -json plan.out > plan.json
  python3 ci/check_tf_plan.py plan.json [--resource-type google_compute_reservation]

Fails on: any create / delete / replace; any change to a resource of another type;
any reservation attribute change other than the count (specific_reservation[].count).
Attributes the provider will only know after apply (after_unknown = true, shown as
"(known after apply)") are listed but not counted as changes: the update is already
restricted to in-place, and the reservation map holds literal values only.
With HCP Terraform, run this in a Run Task, or use the equivalent Sentinel/OPA policy.
"""

import argparse
import json
import sys


def diff_paths(before, after, path=""):
    if isinstance(before, dict) and isinstance(after, dict):
        out = []
        for k in set(before) | set(after):
            out += diff_paths(before.get(k), after.get(k), f"{path}.{k}" if path else k)
        return out
    if isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        out = []
        for i, (x, y) in enumerate(zip(before, after)):
            out += diff_paths(x, y, f"{path}[{i}]")
        return out
    return [] if before == after else [path]


def unknown_paths(u, path=""):
    """Paths flagged true in a plan's after_unknown structure."""
    if u is True:
        return [path]
    out = []
    if isinstance(u, dict):
        for k, v in u.items():
            out += unknown_paths(v, f"{path}.{k}" if path else k)
    elif isinstance(u, list):
        for i, v in enumerate(u):
            out += unknown_paths(v, f"{path}[{i}]")
    return out


def under(p, roots):
    return any(p == r or p.startswith(r + ".") or p.startswith(r + "[") for r in roots)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan_json")
    ap.add_argument("--resource-type", default="google_compute_reservation")
    ap.add_argument("--allowed-attr", action="append",
                    default=["specific_reservation[0].count", "specific_reservation[0].in_use_count"],
                    help="attribute paths allowed to change (in_use_count is computed and may move)")
    a = ap.parse_args()
    with open(a.plan_json) as f:
        plan = json.load(f)
    errors, updates = [], 0
    for rc in plan.get("resource_changes", []) or []:
        actions = rc.get("change", {}).get("actions", [])
        if actions in (["no-op"], ["read"]):
            continue
        addr = rc.get("address")
        if rc.get("type") != a.resource_type:
            errors.append(f"{addr}: {actions} on a non-reservation resource")
            continue
        if actions != ["update"]:
            errors.append(f"{addr}: {actions} (only in-place update is allowed)")
            continue
        changed = diff_paths(rc["change"].get("before"), rc["change"].get("after"))
        computed = unknown_paths(rc["change"].get("after_unknown") or {})
        later = [p for p in changed if p not in a.allowed_attr and under(p, computed)]
        unknown = [p for p in changed if p not in a.allowed_attr and not under(p, computed)]
        if later:
            print(f"computed after apply (not counted): {addr} {later}")
        if unknown:
            errors.append(f"{addr}: attributes other than the count change: {unknown}")
        else:
            updates += 1
            print(f"update: {addr} {[p for p in changed if p not in later]}")
    if errors:
        for e in errors:
            print(f"ERROR: {e}")
        return 1
    print(f"OK: {updates} in-place reservation count update(s), nothing else")
    return 0


if __name__ == "__main__":
    sys.exit(main())
