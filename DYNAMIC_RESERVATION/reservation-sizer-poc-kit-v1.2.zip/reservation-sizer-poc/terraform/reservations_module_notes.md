# Reservation module changes (Step 1)

The sizer edits **one field** (`instance_count`) of **existing keys** in the
`node_pool_reservations` map. The map's shape does not change, so no `moved {}` blocks are
needed — only the file that holds the value moves.

## 1. Move the map value to JSON (no resource address changes)

```bash
python3 terraform/hcl_map_to_json.py <workspace-dir>/terraform.tfvars \
  --out <workspace-dir>/node_pool_reservations.auto.tfvars.json --strip
diff <workspace-dir>/terraform.tfvars <workspace-dir>/terraform.tfvars.new   # review
mv <workspace-dir>/terraform.tfvars.new <workspace-dir>/terraform.tfvars
```

- Terraform and HCP Terraform load `*.auto.tfvars.json` automatically.
- Make sure `node_pool_reservations` is **not** also set as an HCP workspace variable.
- **Acceptance test:** a speculative plan on the PR shows **No changes**. Anything else = stop.

## 2. Guard the reservations inside the module

Add to the reservation resource in the module (if the module is shared, add it in a new
module version and pin it). Example only — keep your module's own resource name and `for_each`:

```hcl
resource "google_compute_reservation" "this" {
  for_each = { for k, v in var.node_pool_reservations : k => v if try(v.enabled, true) }
  # ... existing arguments unchanged ...

  lifecycle {
    prevent_destroy = true
  }
}
```

`prevent_destroy` makes any plan that would delete or replace a reservation fail.

## 3. Only `instance_count` may change in sizer PRs

Enforced by `ci/check_reservation_change.py` (file-level) and `ci/check_tf_plan.py`
(plan-level: only in-place `update` on `google_compute_reservation`).
