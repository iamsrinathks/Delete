# reservation-sizer POC - identity and log access as Terraform (use this OR setup/03-access-gcloud.sh).
# Drop into the workspace that owns project IAM (often the "prj" workspace). Nothing here is
# environment-specific: every value comes from the variables below.

variable "sizer_project_id" { type = string }
variable "sizer_workload_pool" {
  type        = string
  description = "Cluster Workload Identity pool, e.g. <project>.svc.id.goog (gcloud container clusters describe ... workloadIdentityConfig.workloadPool)"
}
variable "sizer_cluster_name" { type = string }
variable "sizer_cluster_location" {
  type        = string
  description = "Cluster region (regional cluster)"
}
variable "sizer_namespace" {
  type    = string
  default = "platform-capacity"
}
variable "sizer_ksa_name" {
  type    = string
  default = "reservation-sizer"
}
variable "sizer_gsa_name" {
  type    = string
  default = "reservation-sizer-poc"
}
variable "sizer_custom_role_id" {
  type    = string
  default = "reservationSizerReaderPoc"
}
variable "sizer_log_bucket" {
  type    = string
  default = "ca-visibility"
}
variable "sizer_log_view" {
  type    = string
  default = "ca-visibility-view"
}
variable "sizer_log_location" {
  type    = string
  default = "global"
}
variable "sizer_log_retention_days" {
  type    = number
  default = 60
}
variable "sizer_github_app_secret" {
  type        = string
  default     = ""
  description = "Secret Manager secret id holding the GitHub App private key; empty = skip"
}

resource "google_service_account" "sizer" {
  project      = var.sizer_project_id
  account_id   = var.sizer_gsa_name
  display_name = "Reservation sizer (POC) - read-only"
}

# Least privilege: no compute.viewer / container.viewer / logging.viewer / monitoring.viewer.
resource "google_project_iam_custom_role" "sizer" {
  project     = var.sizer_project_id
  role_id     = var.sizer_custom_role_id
  title       = "Reservation Sizer Reader (POC)"
  description = "List reservations, read GKE node pools/operations, read Monitoring time series. No writes."
  permissions = [
    "compute.reservations.list",
    "container.clusters.get",
    "container.operations.list",
    "monitoring.timeSeries.list",
  ]
}

resource "google_project_iam_member" "sizer_reader" {
  project = var.sizer_project_id
  role    = google_project_iam_custom_role.sizer.id
  member  = "serviceAccount:${google_service_account.sizer.email}"
}

resource "google_service_account_iam_member" "sizer_wi" {
  service_account_id = google_service_account.sizer.name
  role               = "roles/iam.workloadIdentityUser"
  member             = "serviceAccount:${var.sizer_workload_pool}[${var.sizer_namespace}/${var.sizer_ksa_name}]"
}

# Autoscaler visibility logs -> dedicated bucket -> view -> conditional read for the sizer only.
resource "google_logging_project_bucket_config" "ca" {
  project        = var.sizer_project_id
  location       = var.sizer_log_location
  bucket_id      = var.sizer_log_bucket
  retention_days = var.sizer_log_retention_days
  description    = "Cluster autoscaler visibility events for the reservation sizer"
}

resource "google_logging_project_sink" "ca" {
  project     = var.sizer_project_id
  name        = "${var.sizer_log_bucket}-sink"
  destination = "logging.googleapis.com/projects/${var.sizer_project_id}/locations/${var.sizer_log_location}/buckets/${var.sizer_log_bucket}"
  filter      = "log_id(\"container.googleapis.com/cluster-autoscaler-visibility\") AND resource.type=\"k8s_cluster\" AND resource.labels.cluster_name=\"${var.sizer_cluster_name}\" AND resource.labels.location=\"${var.sizer_cluster_location}\""
  depends_on  = [google_logging_project_bucket_config.ca]
}

resource "google_logging_log_view" "ca" {
  name     = var.sizer_log_view
  bucket   = google_logging_project_bucket_config.ca.id
  location = var.sizer_log_location
  filter   = "log_id(\"container.googleapis.com/cluster-autoscaler-visibility\")"
}

resource "google_project_iam_member" "sizer_log_view" {
  project = var.sizer_project_id
  role    = "roles/logging.viewAccessor"
  member  = "serviceAccount:${google_service_account.sizer.email}"
  condition {
    title      = "reservation-sizer-ca-view-only"
    expression = "resource.name == \"projects/${var.sizer_project_id}/locations/${var.sizer_log_location}/buckets/${var.sizer_log_bucket}/views/${var.sizer_log_view}\""
  }
}

resource "google_secret_manager_secret_iam_member" "sizer_github_key" {
  count     = var.sizer_github_app_secret == "" ? 0 : 1
  project   = var.sizer_project_id
  secret_id = var.sizer_github_app_secret
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.sizer.email}"
}

output "sizer_gsa_email" { value = google_service_account.sizer.email }
output "sizer_log_view_resource" {
  value = "projects/${var.sizer_project_id}/locations/${var.sizer_log_location}/buckets/${var.sizer_log_bucket}/views/${var.sizer_log_view}"
}
output "sizer_sink_writer_identity" {
  value       = google_logging_project_sink.ca.writer_identity
  description = "If no logs arrive in the bucket within ~15 min, grant this identity roles/logging.bucketWriter on the bucket"
}
