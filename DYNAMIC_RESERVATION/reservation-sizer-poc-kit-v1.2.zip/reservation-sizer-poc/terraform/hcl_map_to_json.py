#!/usr/bin/env python3
"""
hcl_map_to_json.py - move ONE map variable (default: node_pool_reservations) out of an HCL
.tfvars file into a sorted *.auto.tfvars.json file, so a bot can edit JSON instead of HCL.

  python3 terraform/hcl_map_to_json.py terraform.tfvars \
      --out node_pool_reservations.auto.tfvars.json [--var node_pool_reservations] [--strip]

--strip also writes <input>.new with the variable block removed (review, then replace the
original). Same variable, same keys, same values -> `terraform plan` must show NO changes.
Supports the subset used by that map: nested blocks of strings, numbers, booleans, comments.
Anything else (lists, expressions, heredocs) -> error, so nothing is silently mis-converted.
"""

import argparse
import os
import json
import re
import sys

TOKEN = re.compile(r'''
    (?P<ws>\s+) | (?P<comment>\#[^\n]*|//[^\n]*|/\*.*?\*/) |
    (?P<str>"(?:[^"\\]|\\.)*") | (?P<num>-?\d+(?:\.\d+)?) |
    (?P<ident>[A-Za-z_][A-Za-z0-9_\-]*) | (?P<punct>[={},:\[\]])
''', re.S | re.X)


def tokenize(text):
    pos, out = 0, []
    while pos < len(text):
        m = TOKEN.match(text, pos)
        if not m:
            raise SystemExit(f"ERROR: unsupported syntax near: {text[pos:pos + 40]!r}")
        kind = m.lastgroup
        if kind not in ("ws", "comment"):
            out.append((kind, m.group(kind), m.start()))
        pos = m.end()
    return out


class Parser:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None, None)

    def take(self, val=None):
        tok = self.peek()
        if tok[0] is None or (val is not None and tok[1] != val):
            raise SystemExit(f"ERROR: expected {val!r}, got {tok[1]!r}")
        self.i += 1
        return tok

    def value(self):
        kind, val, _ = self.peek()
        if val == "{":
            return self.obj()
        if val == "[":
            raise SystemExit("ERROR: lists are not supported in this map - convert by hand")
        self.i += 1
        if kind == "str":
            return json.loads(val)
        if kind == "num":
            return float(val) if "." in val else int(val)
        if val in ("true", "false"):
            return val == "true"
        if val == "null":
            return None
        raise SystemExit(f"ERROR: unsupported value {val!r} (expressions/variables are not allowed)")

    def obj(self):
        self.take("{")
        out = {}
        while self.peek()[1] != "}":
            kind, key, _ = self.take()
            key = json.loads(key) if kind == "str" else key
            if self.peek()[1] in ("=", ":"):
                self.i += 1
            if key in out:
                raise SystemExit(f"ERROR: duplicate key {key!r}")
            out[key] = self.value()
            if self.peek()[1] == ",":
                self.i += 1
        self.take("}")
        return out


def extract(text, var):
    m = re.search(rf'^\s*{re.escape(var)}\s*=\s*\{{', text, re.M)
    if not m:
        raise SystemExit(f"ERROR: variable {var!r} not found as a map block")
    toks = tokenize(text[m.end() - 1:])
    p = Parser(toks)
    value = p.obj()
    end = m.end() - 1 + (toks[p.i - 1][2] + 1)
    return value, m.start(), end


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tfvars")
    ap.add_argument("--var", default="node_pool_reservations")
    ap.add_argument("--out", required=True)
    ap.add_argument("--strip", action="store_true", help="also write <tfvars>.new without the variable")
    a = ap.parse_args()
    with open(a.tfvars) as f:
        text = f.read()
    value, s, e = extract(text, a.var)
    with open(a.out, "w") as f:
        f.write(json.dumps({a.var: value}, indent=2, sort_keys=True) + "\n")
    print(f"wrote {a.out}: {len(value)} entries in '{a.var}'")
    if a.strip:
        new = text[:s] + f"# {a.var} moved to {os.path.basename(a.out)} (edited by reservation-sizer PRs)\n" + text[e:].lstrip("\n")
        with open(a.tfvars + ".new", "w") as f:
            f.write(new)
        print(f"wrote {a.tfvars}.new without '{a.var}' - review the diff, then replace {a.tfvars}")


if __name__ == "__main__":
    sys.exit(main())
