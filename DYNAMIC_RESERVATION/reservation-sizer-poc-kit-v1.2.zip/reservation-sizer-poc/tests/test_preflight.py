"""Offline smoke tests for setup/preflight.py (fixture data instead of Google APIs).
Run:  python3 -m unittest discover -s tests -v
"""

import contextlib
import io
import json
import os
import sys
import unittest
from unittest import mock

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(KIT, "sizer"))
sys.path.insert(0, os.path.join(KIT, "sizer", "tests"))
sys.path.insert(0, os.path.join(KIT, "setup"))

import reservation_sizer as rs  # noqa: E402
import preflight  # noqa: E402
from test_sizer import NOW, REGION, ZA, ZB, Fix, scale_up_decision, stockout_error  # noqa: E402


class PreflightSmoke(unittest.TestCase):
    def setUp(self):
        self.f = Fix()
        self.f.node_metric = True

    def tearDown(self):
        self.f.cleanup()

    def run_preflight(self):
        self.f.write()
        path = os.path.join(self.f.dir, "cluster.json")
        with open(path) as fh:
            cl = json.load(fh)
        cl.update(loggingService="logging.googleapis.com/kubernetes",
                  workloadIdentityConfig={"workloadPool": "p.svc.id.goog"})
        with open(path, "w") as fh:
            json.dump(cl, fh)
        preflight.BLOCKERS.clear()
        preflight.WARNINGS.clear()
        argv = ["preflight.py", "--project", "p", "--location", REGION, "--cluster", "c1",
                "--policy", os.path.join(self.f.dir, "policy.json"),
                "--tfvars-file", os.path.join(self.f.dir, "tfvars.json")]
        out = io.StringIO()
        with mock.patch.object(rs, "Gcp", lambda p, l, c, h, t: rs.FixtureGcp(self.f.dir, c)), \
                mock.patch.object(rs.time, "time", return_value=rs.parse_ts(NOW)), \
                mock.patch.object(sys, "argv", argv), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
            code = preflight.main()
        return code, out.getvalue()

    def test_runs_clean_and_judges_node_metric_coverage_per_cluster(self):
        self.f.value_fns[("user", ZB)] = lambda t: 0          # pool idle at 0 nodes in zone b: not a blocker
        code, out = self.run_preflight()
        self.assertEqual(code, 0, out)
        self.assertIn("node-metric cluster: coverage 100%", out)
        self.assertIn(f"user/{ZB}: buckets with nodes 0/", out)

    def test_ambiguous_stockouts_and_auto_provisioned_pools_are_warned(self):
        self.f.pool_extra["tenant"] = {"autoscaling": {"enabled": True, "autoprovisioned": True}}
        self.f.logs = [stockout_error("2026-11-02T10:01:00Z", "e9", "opaque-id"),
                       scale_up_decision("2026-11-02T10:00:00Z", "e9", ("user", ZA), ("user", ZB))]
        code, out = self.run_preflight()                      # v1.1: KeyError, preflight crashed
        self.assertEqual(code, 0, out)
        self.assertIn("without the failing MIG", out)
        self.assertIn("auto-provisioned pools present", out)
        self.assertIn("tenant", out)


if __name__ == "__main__":
    unittest.main()
