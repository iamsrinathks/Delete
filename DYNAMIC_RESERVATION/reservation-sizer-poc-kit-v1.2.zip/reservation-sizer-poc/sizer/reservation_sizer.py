#!/usr/bin/env python3
"""
reservation_sizer.py - POC: recommend Compute Engine reservation counts for GKE node pools
and (optionally) raise a GitHub PR that changes node_pool_reservations.auto.tfvars.json.

Data sources (all read-only):
  GKE API            node pools -> MIGs per zone, machine type, maxSurge, upgrade strategy
  GKE operations     node pool upgrade windows (surge nodes are excluded from peaks)
  Cloud Monitoring   node count history: kubernetes.io/node/cpu/allocatable_cores counted per
                     node and mapped to MIGs by node-name prefix (same metric as gke_node_peaks.py);
                     optional: compute.googleapis.com/instance_group/size per MIG [verify first]
  Cloud Logging      cluster autoscaler "scale.up.error.out.of.resources" (zonal stockouts)
  Compute API        reservations: count, inUseCount, commitment attachment

Rules (POC):
  * scale UP only; reductions are reported as advisory, never written
  * any missing / low-coverage data -> no recommendation, exit 2 (fail-safe)
  * live reservation ABOVE the branch value (changed outside Terraform) -> nothing proposed for
    any key, exit 3: any apply of the workspace would shrink that reservation
  * branch value above live (apply pending or failed, e.g. stock-out), reservation missing or
    not READY -> that key is held at its branch value, the other keys are still sized, exit 3
  * never adds or removes a reservation key; changes only the count field

Core needs only Python 3.9+ standard library. Auth: GKE metadata server (Workload Identity)
when running in a pod, otherwise `gcloud auth print-access-token` (optionally impersonating the
sizer service account: SIZER_IMPERSONATE_SA=<gsa email>). SIZER_AUTH=gcloud skips the metadata server.
"""

import argparse
import copy
import hashlib
import json
import math
import os
import re
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import datetime, timedelta, timezone

VERSION = "poc-1.2.0"
MIG_METRIC = "compute.googleapis.com/instance_group/size"
NODE_METRIC = "kubernetes.io/node/cpu/allocatable_cores"
CA_LOG = "container.googleapis.com/cluster-autoscaler-visibility"
STOCKOUT_MSG = "scale.up.error.out.of.resources"
ALIGN = 300  # seconds per history bucket

EXIT_OK, EXIT_FAILSAFE, EXIT_HOLD, EXIT_CONFIG, EXIT_PR = 0, 2, 3, 4, 5
HOLD_STATUSES = ("PENDING_APPLY", "DRIFT", "NOT_FOUND", "NOT_READY")
RESULT_FIELDS = ("key", "zone", "current", "actual", "in_use", "target", "target_excl_stockout", "combined_required",
                 "stockout_add", "proposed", "step_back_to", "status")
DRY_RUN_PREFIX = "[DRY RUN] "   # the CI guard fails any PR whose title starts with this

DEFAULT_POLICY = {
    "enabled": True,
    "mode": "report",              # report | dry-run (draft PR, do-not-merge) | live (normal PR)
    "pools": [],                   # node pool NAMES in scope, e.g. ["<system-pool>", "<user-pool>"]
    "windowDays": 7,
    "bufferPct": 10,
    "surgeHeadroom": "auto",       # "auto" = largest maxSurge of the pools sharing a key, or an int
    "stockoutAddPerDay": 1,        # +N per distinct day with a stockout in that zone ...
    "stockoutCapPerKey": 2,        # ... capped
    "stockoutAmbiguous": "skip",   # stockout whose MIG is unknown and whose scale-up touched several
                                   # zones: "skip" (report only) | "all-zones" (count it in each zone)
    "maxStepPerKeyPerPR": 3,
    "minDataCoverage": 0.9,
    "historySource": "node-metric",  # node-metric (default, proven) | mig [verify with preflight]
    "excludeOperationTypes": ["UPGRADE_NODES"],
    "noStacking": True,
    "tfvarsVariable": "node_pool_reservations",
    "countField": "instance_count",
    "machineTypeAliases": {},      # {"<pool machine type>": "<reservation machine type>"}
    "chunkDays": 1,
}


# ----------------------------------------------------------------------------- logging / time
def log(severity, message, **kv):
    rec = {"severity": severity, "message": message, "component": "reservation-sizer", **kv}
    print(json.dumps(rec, default=str), file=sys.stderr, flush=True)


def iso(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_ts(s):
    s = re.sub(r"\.\d+", "", s.strip()).replace("Z", "+00:00")
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def bucket(t):
    return t // ALIGN * ALIGN


def day(t):
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d")


class SizerError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


# ----------------------------------------------------------------------------- HTTP + auth
def ssl_context(ca_bundle=None):
    """Public/system roots ALWAYS, plus the corporate bundle when one is given.
    ssl.create_default_context(cafile=X) would trust ONLY X: Google APIs reached directly (Private
    Google Access, no TLS inspection) would then fail while GitHub through the proxy works."""
    ctx = ssl.create_default_context()
    if ca_bundle:
        ctx.load_verify_locations(cafile=ca_bundle)
    return ctx


class Http:
    """urllib with retries. Honours HTTPS_PROXY / NO_PROXY; TLS verification always on."""

    def __init__(self, ca_bundle=None):
        ctx = ssl_context(ca_bundle)
        self.opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
        self.direct = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # metadata server

    def call(self, method, url, token=None, body=None, headers=None, direct=False, attempts=5, timeout=60):
        hdrs = dict(headers or {})
        if token:
            hdrs["Authorization"] = f"Bearer {token}"
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            hdrs.setdefault("Content-Type", "application/json")
        opener = self.direct if direct else self.opener
        for i in range(attempts):
            req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
            try:
                with opener.open(req, timeout=timeout) as r:
                    raw = r.read()
                    return json.loads(raw.decode()) if raw else {}
            except urllib.error.HTTPError as e:
                text = e.read().decode(errors="replace")[:600]
                if e.code in (429, 500, 502, 503, 504) and i < attempts - 1:
                    time.sleep(2 ** i)
                    continue
                raise SizerError(EXIT_FAILSAFE, f"HTTP {e.code} {method} {url.split('?')[0]}: {text}")
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                if isinstance(getattr(e, "reason", None), ssl.SSLCertVerificationError):
                    raise SizerError(EXIT_FAILSAFE, f"TLS verification failed for {url.split('?')[0]} - "
                                     "pass --ca-bundle <corporate root CA pem> (never disable TLS)")
                if i < attempts - 1:
                    time.sleep(2 ** i)
                    continue
                raise SizerError(EXIT_FAILSAFE, f"network error {method} {url.split('?')[0]}: {e}")


class Token:
    """Metadata server first (Workload Identity in GKE), then gcloud (local runs)."""

    MD = "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"

    def __init__(self, http):
        self.http, self.tok, self.exp, self.source = http, None, 0, None

    def get(self):
        if self.tok and time.time() < self.exp - 120:
            return self.tok
        if os.environ.get("SIZER_ACCESS_TOKEN"):
            self.tok, self.exp, self.source = os.environ["SIZER_ACCESS_TOKEN"], time.time() + 300, "env"
            return self.tok
        mode = os.environ.get("SIZER_AUTH", "auto")          # auto | metadata | gcloud
        if mode != "gcloud" and self.source in (None, "metadata"):
            try:
                d = self.http.call("GET", self.MD, headers={"Metadata-Flavor": "Google"}, direct=True,
                                   attempts=2, timeout=5)
                self.tok, self.exp, self.source = d["access_token"], time.time() + int(d.get("expires_in", 300)), "metadata"
                return self.tok
            except SizerError:
                if self.source == "metadata" or mode == "metadata":
                    raise
        cmd = ["gcloud", "auth", "print-access-token"]
        imp = os.environ.get("SIZER_IMPERSONATE_SA")
        if imp:
            cmd.append(f"--impersonate-service-account={imp}")
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, check=True)
        except FileNotFoundError:
            raise SizerError(EXIT_CONFIG, "no credentials: metadata server unreachable and gcloud not found")
        except subprocess.CalledProcessError as e:
            raise SizerError(EXIT_CONFIG, f"no credentials: {' '.join(cmd)} failed: {e.stderr.strip()[:300]}")
        self.tok, self.exp = out.stdout.strip(), time.time() + 1800
        self.source = f"gcloud-impersonating:{imp}" if imp else "gcloud"
        return self.tok


# ----------------------------------------------------------------------------- Google APIs
class Gcp:
    def __init__(self, project, location, cluster, http, token):
        self.project, self.location, self.cluster, self.http, self.token = project, location, cluster, http, token

    def _get(self, url):
        return self.http.call("GET", url, token=self.token.get())

    def cluster_info(self):
        return self._get(f"https://container.googleapis.com/v1/projects/{self.project}/locations/"
                         f"{self.location}/clusters/{self.cluster}")

    def operations(self):
        d = self._get(f"https://container.googleapis.com/v1/projects/{self.project}/locations/{self.location}/operations")
        return d.get("operations", []) or []

    def reservations(self, zone):
        out, page = [], None
        while True:
            q = {"maxResults": "500"}
            if page:
                q["pageToken"] = page
            d = self._get(f"https://compute.googleapis.com/compute/v1/projects/{self.project}/zones/{zone}/"
                          f"reservations?{urllib.parse.urlencode(q)}")
            out += d.get("items", []) or []
            page = d.get("nextPageToken")
            if not page:
                return out

    def timeseries(self, flt, start, end, chunk_days=1):
        out = []
        step = max(1, int(chunk_days)) * 86400
        lo = start
        while lo < end:
            hi = min(lo + step, end)
            page = None
            while True:
                q = {"filter": flt, "interval.startTime": iso(lo), "interval.endTime": iso(hi),
                     "aggregation.alignmentPeriod": f"{ALIGN}s", "aggregation.perSeriesAligner": "ALIGN_MAX",
                     "view": "FULL", "pageSize": "100000"}
                if page:
                    q["pageToken"] = page
                d = self._get(f"https://monitoring.googleapis.com/v3/projects/{self.project}/timeSeries?"
                              + urllib.parse.urlencode(q))
                out += d.get("timeSeries", []) or []
                page = d.get("nextPageToken")
                if not page:
                    break
            lo = hi
        return out

    def log_entries(self, resource, flt, max_pages=20):
        out, page = [], None
        for _ in range(max_pages):
            body = {"resourceNames": [resource], "filter": flt, "orderBy": "timestamp desc", "pageSize": 1000}
            if page:
                body["pageToken"] = page
            d = self.http.call("POST", "https://logging.googleapis.com/v2/entries:list", token=self.token.get(), body=body)
            out += d.get("entries", []) or []
            page = d.get("nextPageToken")
            if not page:
                return out
        log("WARNING", "log read hit max pages - stockout list may be incomplete", resource=resource)
        return out

    def secret(self, secret_project, name):
        import base64
        d = self._get(f"https://secretmanager.googleapis.com/v1/projects/{secret_project}/secrets/{name}/versions/latest:access")
        return base64.b64decode(d["payload"]["data"]).decode()


class FixtureGcp:
    """Offline source for tests and demos: reads JSON files from a directory."""

    def __init__(self, path, cluster):
        self.path, self.cluster = path, cluster

    def _load(self, name, default):
        p = os.path.join(self.path, name)
        if not os.path.exists(p):
            return default
        with open(p) as f:
            return json.load(f)

    def cluster_info(self):
        return self._load("cluster.json", {})

    def operations(self):
        return self._load("operations.json", [])

    def reservations(self, zone):
        return self._load("reservations.json", {}).get(zone, [])

    def timeseries(self, flt, start, end, chunk_days=1):
        out = []
        for ts in self._load("timeseries.json", []):
            if f'"{ts["metric"]["type"]}"' not in flt:
                continue
            pts = [p for p in ts.get("points", []) if start <= parse_ts(p["interval"]["endTime"]) <= end]
            out.append({**ts, "points": pts})
        return out

    def log_entries(self, resource, flt, max_pages=20):
        entries = self._load("logs.json", [])
        if "jsonPayload.decision.eventId" in flt:
            ids = set(re.findall(r'jsonPayload\.decision\.eventId="([^"]+)"', flt))
            return [e for e in entries if (e.get("jsonPayload", {}).get("decision") or {}).get("eventId") in ids]
        return [e for e in entries if e.get("jsonPayload", {}).get("resultInfo")]

    def secret(self, secret_project, name):
        raise SizerError(EXIT_CONFIG, "secrets are not available in fixture mode")


# ----------------------------------------------------------------------------- collection
def load_pools(cluster, wanted):
    pools = {}
    for p in cluster.get("nodePools", []) or []:
        if p.get("name") not in wanted:
            continue
        cfg = p.get("config") or {}
        up = p.get("upgradeSettings") or {}
        migs = []
        for u in p.get("instanceGroupUrls", []) or []:
            m = re.search(r"/zones/([^/]+)/instanceGroup(?:Manager)?s/([^/]+)$", u)
            if m:
                migs.append({"zone": m.group(1), "name": m.group(2)})
        ra = cfg.get("reservationAffinity") or {}
        pools[p["name"]] = {
            "machine_type": cfg.get("machineType", ""),
            "migs": migs,
            "max_surge": int(up.get("maxSurge", 0) or 0),
            "strategy": up.get("strategy", "SURGE") or "SURGE",
            "affinity": ra.get("consumeReservationType", "UNSPECIFIED"),
            # SPECIFIC affinity values may be "name" or ".../reservations/name"
            "reservation_values": sorted({v.rstrip("/").split("/")[-1] for v in ra.get("values", []) or []}),
            "spot": bool(cfg.get("spot") or cfg.get("preemptible")),
        }
    missing = sorted(set(wanted) - set(pools))
    if missing:
        raise SizerError(EXIT_CONFIG, f"node pools in policy not found in cluster: {missing}")
    for name, p in pools.items():
        if not p["migs"]:
            raise SizerError(EXIT_FAILSAFE, f"node pool {name} has no instanceGroupUrls")
    return pools


def other_pools(cluster, wanted):
    """Pools NOT in policy.pools (including auto-provisioned / compute-class pools): they consume
    ANY reservations of the same machine type too, but the POC does not size them."""
    out = []
    for p in cluster.get("nodePools", []) or []:
        if p.get("name") in wanted:
            continue
        zones = set(p.get("locations", []) or [])
        for u in p.get("instanceGroupUrls", []) or []:
            m = re.search(r"/zones/([^/]+)/", u)
            if m:
                zones.add(m.group(1))
        cfg = p.get("config") or {}
        out.append({"name": p.get("name", ""), "machine_type": cfg.get("machineType", ""), "zones": sorted(zones),
                    "autoprovisioned": bool((p.get("autoscaling") or {}).get("autoprovisioned"))})
    return out


def consumes(pool, res_name, specific_required):
    """(True, "") if VMs of this pool can consume reservation `res_name`, else (False, reason)."""
    if pool["spot"]:
        return False, "Spot VMs cannot consume reservations"
    aff = pool["affinity"]
    if aff == "NO_RESERVATION":
        return False, "reservation affinity NO_RESERVATION"
    if aff == "SPECIFIC_RESERVATION":
        if res_name in pool["reservation_values"]:
            return True, ""
        return False, f"SPECIFIC affinity to {pool['reservation_values'] or 'other reservations'}"
    if specific_required:   # ANY / UNSPECIFIED pools never use a specificReservationRequired reservation
        return False, "reservation has specificReservationRequired=true and the pool uses ANY affinity"
    return True, ""


def history_mig(gcp, pools, start, end, chunk_days):
    names = sorted({m["name"] for p in pools.values() for m in p["migs"]})
    flt = (f'metric.type="{MIG_METRIC}" AND resource.type="instance_group" AND '
           f'resource.labels.instance_group_name=one_of({", ".join(json.dumps(n) for n in names)})')
    hist = defaultdict(dict)
    for ts in gcp.timeseries(flt, start, end, chunk_days):
        name = (ts.get("resource", {}).get("labels", {}) or {}).get("instance_group_name")
        if name not in names:
            continue
        for pt in ts.get("points", []) or []:
            v = pt.get("value", {}) or {}
            val = int(float(v.get("int64Value", v.get("doubleValue", 0)) or 0))
            b = bucket(parse_ts(pt["interval"]["endTime"]))
            hist[name][b] = max(hist[name].get(b, 0), val)
    return dict(hist)


def history_node_metric(gcp, pools, cluster_name, region, start, end, chunk_days):
    """Count k8s_node series per bucket, mapped to MIGs by node-name prefix.

    Returns (hist, cluster_buckets). A MIG with 0 nodes has NO series, so "no series" cannot mean
    "no data" per MIG. cluster_buckets = buckets in which the cluster reported ANY node (any pool):
    that is the metric pipeline's coverage. Inside those buckets a MIG without nodes counts as 0."""
    prefix = {}
    for p in pools.values():
        for m in p["migs"]:
            prefix[m["name"][:-4] if m["name"].endswith("-grp") else m["name"]] = m["name"]
    flt = (f'metric.type="{NODE_METRIC}" AND resource.type="k8s_node" AND '
           f'resource.labels.cluster_name="{cluster_name}" AND resource.labels.location=starts_with("{region}")')
    nodes = defaultdict(lambda: defaultdict(set))
    unmapped, cluster_buckets = set(), set()
    for ts in gcp.timeseries(flt, start, end, chunk_days):
        node = (ts.get("resource", {}).get("labels", {}) or {}).get("node_name", "")
        mig = prefix.get(node.rsplit("-", 1)[0])
        buckets = {bucket(parse_ts(pt["interval"]["endTime"])) for pt in ts.get("points", []) or []}
        cluster_buckets |= buckets
        if not mig:
            unmapped.add(node)
            continue
        for b in buckets:
            nodes[mig][b].add(node)
    if unmapped:
        log("INFO", "node-metric: nodes not in an in-scope MIG (other pools or deleted MIGs) not counted",
            count=len(unmapped))
    return {mig: {b: len(s) for b, s in by_b.items()} for mig, by_b in nodes.items()}, cluster_buckets


def upgrade_spans(ops, cluster_name, types, now):
    spans = defaultdict(list)   # pool -> [(start, end)]; "*" = whole cluster
    rows = []
    for op in ops:
        if op.get("operationType") not in types:
            continue
        tl = op.get("targetLink", "") or ""
        m = re.search(r"/clusters/([^/]+)(?:/nodePools/([^/]+))?", tl)
        if not m or m.group(1) != cluster_name or not op.get("startTime"):
            continue
        s = parse_ts(op["startTime"])
        e = parse_ts(op["endTime"]) if op.get("endTime") else now
        pool = m.group(2) or "*"
        spans[pool].append((s - ALIGN, e + ALIGN))
        rows.append({"operation": op.get("name", ""), "type": op.get("operationType"), "pool": pool,
                     "start": iso(s), "end": iso(e) if op.get("endTime") else "running"})
    return dict(spans), rows


def stockout_filter(cluster_name, location, start):
    loc = f' AND resource.labels.location="{location}"' if location else ""
    return (f'log_id("{CA_LOG}") AND resource.type="k8s_cluster" AND '
            f'resource.labels.cluster_name="{cluster_name}"{loc} AND timestamp>="{iso(start)}"')


def stockouts(gcp, resource, cluster_name, pools, start, location=None, ambiguous="skip"):
    """Returns ((pool, zone) -> sorted days with scale.up.error.out.of.resources, event count,
    ambiguous events). Only this message counts: quota / IP / noScaleUp reasons are not fixable by
    a reservation and can be triggered by any tenant's misconfigured pod.

    The failing MIG normally appears in the error parameters. If it does not, the scale-up decision
    is looked up by eventId; when that decision touched several in-scope pool/zones (BALANCED often
    scales all three zones at once) the failing zone is unknown: "skip" reports the event without
    adding to any zone, "all-zones" counts it in every zone of the decision."""
    mig_index = {m["name"]: (pn, m["zone"]) for pn, p in pools.items() for m in p["migs"]}
    amb = []
    base = stockout_filter(cluster_name, location, start)
    # text search + resultInfo presence; the messageId is re-checked in code below
    entries = gcp.log_entries(resource, base + f' AND jsonPayload.resultInfo:* AND "{STOCKOUT_MSG}"')
    hits, unresolved, n_events = defaultdict(set), {}, 0
    for e in entries:
        ts = parse_ts(e.get("timestamp", iso(start)))
        for r in (e.get("jsonPayload", {}).get("resultInfo") or {}).get("results", []) or []:
            em = r.get("errorMsg") or {}
            if em.get("messageId") != STOCKOUT_MSG:
                continue
            n_events += 1
            found = False
            for param in em.get("parameters", []) or []:
                for mig, key in mig_index.items():
                    if mig in str(param):
                        hits[key].add(day(ts))
                        found = True
            if not found and r.get("eventId"):
                unresolved[r["eventId"]] = ts
    ids = list(unresolved)
    for i in range(0, len(ids), 20):
        chunk = ids[i:i + 20]
        flt = base.replace(f'timestamp>="{iso(start)}"', f'timestamp>="{iso(start - 3600)}"')
        flt += " AND (" + " OR ".join(f'jsonPayload.decision.eventId="{x}"' for x in chunk) + ")"
        for e in gcp.log_entries(resource, flt):
            dec = e.get("jsonPayload", {}).get("decision") or {}
            eid = dec.get("eventId")
            if eid not in unresolved:          # unrelated, or already resolved by an earlier entry
                continue
            keys = sorted({((im.get("mig") or {}).get("nodepool"), (im.get("mig") or {}).get("zone"))
                           for im in (dec.get("scaleUp") or {}).get("increasedMigs", []) or []
                           if (im.get("mig") or {}).get("nodepool") in pools})
            if not keys:
                continue
            ts = unresolved.pop(eid)           # read once: several MIGs may share this event
            if len(keys) == 1 or ambiguous == "all-zones":
                for k in keys:
                    hits[k].add(day(ts))
            else:
                amb.append({"event_id": eid, "day": day(ts), "pool_zones": [f"{p}/{z}" for p, z in keys]})
    if amb:
        log("WARNING", "stockout events with an unknown failing zone (scale-up touched several zones) - "
            f"policy stockoutAmbiguous={ambiguous}", count=len(amb))
    if unresolved:
        log("WARNING", "stockout events whose node pool/zone could not be resolved (ignored)", count=len(unresolved))
    return {k: sorted(v) for k, v in hits.items()}, n_events, amb


def actual_reservations(gcp, zones):
    out = {}
    for z in sorted(zones):
        for r in gcp.reservations(z):
            sr = r.get("specificReservation") or {}
            out[(z, r.get("name"))] = {
                "count": int(sr.get("count", 0) or 0),
                "in_use": int(sr.get("inUseCount", 0) or 0),
                "machine_type": ((sr.get("instanceProperties") or {}).get("machineType") or "").split("/")[-1],
                "commitment": (r.get("commitment") or "").split("/")[-1],
                "specific_required": bool(r.get("specificReservationRequired")),
                "status": r.get("status", ""),
            }
    return out


# ----------------------------------------------------------------------------- sizing
def required_for(peak, buffer_pct):
    # round() first: 10 x 1.1 = 11.000000000000002 must give 11, not 12
    return math.ceil(round(peak * (1 + buffer_pct / 100.0), 6))


def compute(entries, pools, hist, spans, hits, actual, pol, start, end, cluster_buckets=None, others=()):
    """cluster_buckets: node-metric only (see history_node_metric) - coverage is judged for the whole
    cluster and buckets without nodes of a MIG count as 0. None (mig source): coverage per MIG."""
    count_f = pol["countField"]
    aliases = pol.get("machineTypeAliases") or {}
    expected = max(1, (end - start) // ALIGN)
    rows, problems, holds = [], [], []
    proposed = copy.deepcopy(entries)
    covered = set()
    window = None if cluster_buckets is None else sorted(b for b in cluster_buckets if start <= b <= end)

    for key in sorted(entries):
        ent = entries[key]
        zone, mt, name = ent.get("zone"), ent.get("machine_type"), ent.get("name")
        row = {"key": key, "zone": zone, "machine_type": mt, "reservation": name, "notes": []}
        rows.append(row)
        if not ent.get("enabled", True):
            row["status"] = "DISABLED"
            continue
        try:
            current = int(ent[count_f])
        except (KeyError, TypeError, ValueError):
            problems.append(f"{key}: missing/invalid {count_f}")
            row["status"] = "INVALID"
            continue
        row["current"] = current

        candidates = []
        for pn, p in sorted(pools.items()):
            if aliases.get(p["machine_type"], p["machine_type"]) != mt:
                continue
            for m in p["migs"]:
                if m["zone"] == zone:
                    candidates.append((pn, p, m))
                    covered.add((pn, zone))
        if not candidates:
            row["status"] = "NO_POOLS_IN_SCOPE"
            row["notes"].append("no in-scope pool uses this machine type in this zone - left unchanged")
            continue
        shared = sorted(o["name"] + (" (auto-provisioned)" if o["autoprovisioned"] else "") for o in others
                        if aliases.get(o["machine_type"], o["machine_type"]) == mt and zone in o["zones"])
        if shared:
            row["out_of_scope_pools"] = shared
            row["notes"].append(f"out-of-scope pool(s) {', '.join(shared)} also use {mt} in this zone and can "
                                "consume this reservation - their nodes are NOT counted")

        live = actual.get((zone, name))
        row["actual"] = live["count"] if live else None
        row["in_use"] = live["in_use"] if live else None
        if live is None:
            holds.append(f"{key}: reservation {name} not found in {zone} (not applied yet, or wrong name) - key held")
            row["status"] = "NOT_FOUND"
            continue
        if live["status"] and live["status"] != "READY":
            holds.append(f"{key}: reservation {name} status {live['status']} (resize in progress?) - key held")
            row["status"] = "NOT_READY"
            continue
        if live["machine_type"] and live["machine_type"] != mt:
            problems.append(f"{key}: tfvars machine_type {mt} but reservation {name} is {live['machine_type']}")
            row["status"] = "MISMATCH"
            continue
        if live["commitment"]:
            row["status"] = "COMMITMENT_ATTACHED"
            row["notes"].append(f"attached to commitment {live['commitment']} - resize via replace process, skipped")
            continue

        members = []
        for pn, p, m in candidates:
            ok, why = consumes(p, name, live["specific_required"])
            if ok:
                members.append((pn, p, m))
            else:
                row["notes"].append(f"{pn} cannot consume {name}: {why} - not counted")
        if not members:
            row["status"] = "NOT_CONSUMABLE"
            row["notes"].append("no in-scope pool can consume this reservation - left unchanged (idle cost?)")
            continue

        total, latest, details, data_ok = 0, 0, [], True
        combined, combined_excl = defaultdict(int), set()
        for pn, p, m in members:
            series = hist.get(m["name"], {})
            if window is not None:
                present = {b: series.get(b, 0) for b in window}
                cov = min(1.0, len(window) / expected)
                what = "cluster node-metric coverage"
            else:
                present = {b: v for b, v in series.items() if start <= b <= end}
                cov = min(1.0, len(present) / expected)
                what = f"MIG {m['name']} coverage"
            excl = spans.get(pn, []) + spans.get("*", [])
            kept = {b: v for b, v in present.items() if not any(s <= b <= e for s, e in excl)}
            combined_excl |= set(present) - set(kept)
            for b, v in present.items():
                combined[b] += v
            if cov < pol["minDataCoverage"] or not kept:
                data_ok = False
                problems.append(f"{key}: pool {pn}: {what} {cov:.0%} "
                                f"(< {pol['minDataCoverage']:.0%}) or no data outside upgrade windows")
            peak = max(kept.values()) if kept else 0
            req = required_for(peak, pol["bufferPct"])
            total += req
            latest += present[max(present)] if present else 0
            details.append({"pool": pn, "mig": m["name"], "coverage": round(cov, 3), "peak": peak,
                            "required": req, "excluded_buckets": len(present) - len(kept),
                            "buckets_with_nodes": sum(1 for v in present.values() if v > 0)})
            if p["strategy"] == "BLUE_GREEN":
                row["notes"].append(f"{pn} uses BLUE_GREEN upgrades - surge headroom not modelled")
        row["pools"] = details
        if not data_ok:
            row["status"] = "NO_DATA"
            continue

        # For comparison with gke_node_peaks.py: peak of the SUMMED members (the sizer itself sums
        # per-pool peaks, which is >= this when pools peak at different times).
        combined_kept = [v for b, v in combined.items() if b not in combined_excl]
        combined_peak = max(combined_kept) if combined_kept else 0
        surge = (max(p["max_surge"] for _, p, _ in members) if pol["surgeHeadroom"] == "auto"
                 else int(pol["surgeHeadroom"]))
        stock_days = sorted({d for pn, _, _ in members for d in hits.get((pn, zone), [])})
        stock = min(pol["stockoutAddPerDay"] * len(stock_days), pol["stockoutCapPerKey"])
        target = total + surge + stock
        row.update({"surge": surge, "stockout_days": stock_days, "stockout_add": stock, "target": target,
                    "target_excl_stockout": total + surge,
                    "combined_peak": combined_peak,
                    "combined_required": required_for(combined_peak, pol["bufferPct"]),
                    "latest_nodes": latest,
                    "on_demand_exposure": latest - live["in_use"]})

        if live["count"] != current:
            if current > live["count"]:
                step_back = live["count"] + max(1, (current - live["count"]) // 2)
                row["step_back_to"] = step_back
                holds.append(f"{key}: branch says {current}, Compute Engine has {live['count']} - key held "
                             f"(apply pending, or failed). If the apply failed with a stock-out, retry a smaller "
                             f"step: set {count_f} to {step_back} in a human PR")
                row["status"] = "PENDING_APPLY"
            else:
                # Out-of-band change: ANY apply of this workspace would SHRINK the reservation back.
                holds.append(f"{key}: Compute Engine has {live['count']} but branch says {current} "
                             "(changed outside Terraform) - nothing is proposed for ANY key until the file "
                             "is reconciled, because any apply would shrink this reservation")
                row["status"] = "DRIFT"
            continue
        if row["on_demand_exposure"] is not None and row["on_demand_exposure"] < 0:
            row["notes"].append(f"in-use {live['in_use']} > in-scope nodes {latest}: other pools/VMs consume this reservation")
        delta = target - current
        if delta > 0:
            step = min(delta, pol["maxStepPerKeyPerPR"])
            proposed[key][count_f] = current + step
            row["proposed"] = current + step
            row["status"] = "INCREASE"
            if step < delta:
                row["notes"].append(f"clamped by maxStepPerKeyPerPR ({delta} needed)")
        elif delta < 0:
            row["proposed"] = current
            row["status"] = "COULD_REDUCE"
            row["notes"].append(f"advisory only: target {target} is {-delta} below current - not changed")
        else:
            row["proposed"] = current
            row["status"] = "OK"

    uncovered = sorted({(pn, m["zone"], p["machine_type"]) for pn, p in pools.items() for m in p["migs"]
                        if (pn, m["zone"]) not in covered and not p["spot"] and p["affinity"] != "NO_RESERVATION"})
    return rows, proposed, problems, holds, uncovered


# ----------------------------------------------------------------------------- outputs
def dump_tfvars(doc):
    return json.dumps(doc, indent=2, sort_keys=True) + "\n"


def pr_body(meta, rows, ops_rows, n_events, uncovered, snapshot, holds=(), ambiguous=()):
    title = f"## Reservation Sizer - {meta['env']} / {meta['project']} / {meta['location']} / {meta['cluster']}"
    L = [title, ""]
    if meta.get("mode") == "dry-run":
        L += ["> **DRY RUN - do not merge.** The `reservation-sizer-guard` check fails on this PR on purpose.", ""]
    L += [
         "| Key | Zone | Machine type | Branch | Live | Proposed | Δ | Driver | Status |",
         "|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        if "target" not in r and r.get("status") not in ("PENDING_APPLY", "DRIFT", "NOT_FOUND", "NOT_READY"):
            continue
        drv = " + ".join(f"{d['pool']} {d['peak']}→{d['required']}" for d in r.get("pools", []))
        drv += f" + surge {r.get('surge', 0)}" + (f" + stockout {r['stockout_add']}" if r.get("stockout_add") else "")
        delta = (r.get("proposed", r.get("current", 0)) or 0) - (r.get("current", 0) or 0)
        L.append(f"| `{r['key']}` | {r['zone']} | {r['machine_type']} | {r.get('current', '')} | {r.get('actual', '')} | "
                 f"{r.get('proposed', '')} | {delta:+d} | {drv} = {r.get('target', '')} | {r.get('status')} |")
    L += ["", "**Evidence**",
          f"- Window: {meta['window_days']}d ({meta['start']} → {meta['end']}), buffer {meta['buffer_pct']}%, "
          f"history source `{meta['history_source']}`",
          f"- Excluded upgrade operations: {', '.join(o['operation'] + ' (' + o['pool'] + ')' for o in ops_rows) or 'none'}",
          f"- Stockout events (`{STOCKOUT_MSG}`) in window: {n_events}"]
    for r in rows:
        if r.get("stockout_days"):
            L.append(f"  - `{r['key']}`: days {', '.join(r['stockout_days'])}")
    if ambiguous:
        L.append(f"- Stockouts with an unknown failing zone (not added, `stockoutAmbiguous`): "
                 + ", ".join(f"{a['day']} {'/'.join(a['pool_zones'])}" for a in ambiguous))
    diffs = [r for r in rows if "combined_required" in r and r["combined_required"] + r["surge"] != r["target_excl_stockout"]]
    if diffs:
        L.append("- Sum of per-pool peaks vs peak of the summed pools (+ surge): " + ", ".join(
            f"`{r['key']}` {r['target_excl_stockout']} vs {r['combined_required'] + r['surge']}" for r in diffs))
    L.append("- On-demand exposure now (nodes − reservation in use): " + (", ".join(
        f"`{r['key']}` {r['on_demand_exposure']}" for r in rows if r.get("on_demand_exposure") is not None) or "n/a"))
    adv = [r for r in rows if r.get("status") == "COULD_REDUCE"]
    if adv:
        L.append("- Advisory reductions (NOT applied): " + ", ".join(f"`{r['key']}` target {r['target']}" for r in adv))
    if uncovered:
        L.append("- ⚠️ In-scope pools/zones with no reservation key: "
                 + ", ".join(f"{p}/{z}/{mt}" for p, z, mt in uncovered))
    if holds:
        L += ["", "**Held keys (left at their branch value in this PR)**"] + [f"- {h}" for h in holds]
    notes = [f"`{r['key']}`: {n}" for r in rows for n in r.get("notes", [])]
    if notes:
        L += ["", "**Notes**"] + [f"- {n}" for n in notes]
    L += ["", f"**Input snapshot hash:** `{snapshot}`",
          f"Generated by reservation-sizer {VERSION} · run {meta['run_id']} · mode `{meta['mode']}`"]
    return "\n".join(L) + "\n"


def print_table(rows):
    cols = ["key", "zone", "machine_type", "current", "actual", "target", "proposed", "status"]
    data = [{c: ("" if r.get(c) is None else str(r.get(c))) for c in cols} for r in rows]
    w = {c: max([len(c)] + [len(d[c]) for d in data]) for c in cols}
    print("  ".join(c.ljust(w[c]) for c in cols))
    print("  ".join("-" * w[c] for c in cols))
    for d in data:
        print("  ".join(d[c].ljust(w[c]) for c in cols))


# ----------------------------------------------------------------------------- main
def load_policy(path):
    with open(path) as f:
        user = json.load(f)
    unknown = sorted(set(user) - set(DEFAULT_POLICY))
    if unknown:
        raise SizerError(EXIT_CONFIG, f"unknown policy keys: {unknown}")
    pol = {**DEFAULT_POLICY, **user}
    if pol["mode"] not in ("report", "dry-run", "live"):
        raise SizerError(EXIT_CONFIG, "policy.mode must be report | dry-run | live")
    if not pol["pools"]:
        raise SizerError(EXIT_CONFIG, "policy.pools is empty - list the in-scope node pool names")
    if pol["historySource"] not in ("mig", "node-metric"):
        raise SizerError(EXIT_CONFIG, "policy.historySource must be mig | node-metric")
    if pol["stockoutAmbiguous"] not in ("skip", "all-zones"):
        raise SizerError(EXIT_CONFIG, "policy.stockoutAmbiguous must be skip | all-zones")
    return pol


def env(name, default=None):
    v = os.environ.get(name)
    return v if v not in (None, "") else default


def parse_args(argv):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", default=env("PROJECT_ID"))
    ap.add_argument("--location", default=env("CLUSTER_LOCATION"), help="cluster region")
    ap.add_argument("--cluster", default=env("CLUSTER_NAME"))
    ap.add_argument("--env-name", default=env("ENV_NAME", "unknown"))
    ap.add_argument("--policy", default=env("SIZER_POLICY", "/etc/sizer/policy.json"))
    ap.add_argument("--tfvars-file", default=env("TFVARS_FILE"), help="local copy of the reservations tfvars JSON")
    ap.add_argument("--log-resource", default=env("LOG_RESOURCE"),
                    help="log view (projects/P/locations/L/buckets/B/views/V) or projects/P; default projects/<project>")
    ap.add_argument("--out-dir", default=env("OUT_DIR", "./sizer-out"))
    ap.add_argument("--ca-bundle", default=env("CA_BUNDLE"))
    ap.add_argument("--fixtures", help="offline mode: read API responses from this directory")
    ap.add_argument("--now", help="override current time (RFC3339), for fixtures/tests")
    ap.add_argument("--mode", choices=["report", "dry-run", "live"], help="override policy.mode")
    gh = ap.add_argument_group("GitHub (optional; only used in dry-run/live mode)")
    gh.add_argument("--github-repo", default=env("GITHUB_REPO"), help="owner/repo")
    gh.add_argument("--github-api", default=env("GITHUB_API_URL", "https://api.github.com"))
    gh.add_argument("--github-base", default=env("GITHUB_BASE_BRANCH"))
    gh.add_argument("--tfvars-path", default=env("TFVARS_PATH"), help="path of the tfvars JSON inside the repo")
    gh.add_argument("--github-app-id", default=env("GITHUB_APP_ID"))
    gh.add_argument("--github-installation-id", default=env("GITHUB_APP_INSTALLATION_ID"))
    gh.add_argument("--github-key-secret", default=env("GITHUB_APP_SECRET"), help="Secret Manager secret name")
    gh.add_argument("--github-key-secret-project", default=env("GITHUB_APP_SECRET_PROJECT"))
    gh.add_argument("--github-key-file", default=env("GITHUB_APP_KEY_FILE"), help="local PEM (local runs only)")
    a = ap.parse_args(argv)
    for req in ("project", "location", "cluster"):
        if not getattr(a, req) and not a.fixtures:
            ap.error(f"--{req} (or its env var) is required")
    return a


def run(argv=None):
    a = parse_args(argv)
    pol = load_policy(a.policy)
    if a.mode:
        pol["mode"] = a.mode
    if not pol["enabled"]:
        log("NOTICE", "policy.enabled=false - kill switch on, nothing done")
        return EXIT_OK, None

    now = parse_ts(a.now) if a.now else int(time.time())
    end = bucket(now)
    start = end - int(pol["windowDays"]) * 86400
    run_id = datetime.fromtimestamp(now, timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    os.makedirs(a.out_dir, exist_ok=True)

    http = Http(a.ca_bundle)
    token = Token(http)
    gcp = FixtureGcp(a.fixtures, a.cluster) if a.fixtures else Gcp(a.project, a.location, a.cluster, http, token)
    github = None
    if pol["mode"] in ("dry-run", "live") and not (a.github_repo and a.tfvars_path):
        raise SizerError(EXIT_CONFIG, f"mode {pol['mode']} needs GITHUB_REPO and TFVARS_PATH")
    if a.github_repo and a.tfvars_path and not a.tfvars_file:
        import github_pr  # optional dependency (PyJWT[crypto])
        if a.github_key_file:
            with open(a.github_key_file) as f:
                key = f.read()
        elif a.github_key_secret:
            key = gcp.secret(a.github_key_secret_project or a.project, a.github_key_secret)
        else:
            raise SizerError(EXIT_CONFIG, "GitHub key: set --github-key-secret or --github-key-file")
        github = github_pr.GitHub.from_app(a.github_api, a.github_app_id, a.github_installation_id, key,
                                           repo=a.github_repo, ca_bundle=a.ca_bundle)

    # ---- current desired state (branch)
    if github and a.tfvars_path:
        base = a.github_base or github.default_branch(a.github_repo)
        text, _ = github.get_file(a.github_repo, a.tfvars_path, base)
        tfvars = json.loads(text)
    elif a.tfvars_file:
        with open(a.tfvars_file) as f:
            tfvars = json.load(f)
    else:
        raise SizerError(EXIT_CONFIG, "give --tfvars-file, or GitHub settings with --tfvars-path")
    var = pol["tfvarsVariable"]
    if var not in tfvars or not isinstance(tfvars[var], dict):
        raise SizerError(EXIT_CONFIG, f"tfvars JSON has no map '{var}'")
    entries = tfvars[var]

    # ---- collect
    cluster = gcp.cluster_info()
    cluster_name = cluster.get("name", a.cluster)
    region = (a.location or cluster.get("location", "")).rsplit("-", 1)[0] if re.match(
        r"^[a-z]+-[a-z]+\d+-[a-z]$", a.location or cluster.get("location", "")) else (a.location or cluster.get("location", ""))
    pools = load_pools(cluster, pol["pools"])
    others = other_pools(cluster, pol["pools"])
    log("INFO", "collecting history", source=pol["historySource"], pools=sorted(pools), window_days=pol["windowDays"])
    cluster_buckets = None
    if pol["historySource"] == "mig":
        hist = history_mig(gcp, pools, start, end, pol["chunkDays"])
    else:
        hist, cluster_buckets = history_node_metric(gcp, pools, cluster_name, region, start, end, pol["chunkDays"])
    spans, ops_rows = upgrade_spans(gcp.operations(), cluster_name, pol["excludeOperationTypes"], now)
    resource = a.log_resource or f"projects/{a.project}"
    hits, n_events, ambiguous = stockouts(gcp, resource, cluster_name, pools, start, location=a.location,
                                          ambiguous=pol["stockoutAmbiguous"])
    zones = {e.get("zone") for e in entries.values() if e.get("zone")}
    actual = actual_reservations(gcp, zones)

    rows, proposed, problems, holds, uncovered = compute(entries, pools, hist, spans, hits, actual, pol, start, end,
                                                         cluster_buckets=cluster_buckets, others=others)
    snapshot = hashlib.sha256(json.dumps(
        {"entries": entries, "hist": {k: sorted(v.items()) for k, v in sorted(hist.items())},
         "cluster_buckets": sorted(cluster_buckets) if cluster_buckets is not None else None,
         "spans": spans, "hits": {f"{k[0]}|{k[1]}": v for k, v in hits.items()},
         "actual": {f"{k[0]}|{k[1]}": v for k, v in sorted(actual.items())}, "policy": pol},
        sort_keys=True, default=str).encode()).hexdigest()[:16]

    meta = {"env": a.env_name, "project": a.project, "location": a.location, "cluster": cluster_name,
            "window_days": pol["windowDays"], "start": iso(start), "end": iso(end), "buffer_pct": pol["bufferPct"],
            "history_source": pol["historySource"], "run_id": run_id, "mode": pol["mode"], "version": VERSION}
    drift = [r["key"] for r in rows if r.get("status") == "DRIFT"]
    blocked = bool(drift and pol["noStacking"])          # any apply would shrink a drifted reservation
    held = [r["key"] for r in rows if r.get("status") in HOLD_STATUSES]
    changed = not problems and not blocked and any(r.get("status") == "INCREASE" for r in rows)
    report = {"meta": meta, "rows": rows, "problems": problems, "holds": holds, "held_keys": held,
              "blocked_by_drift": drift if blocked else [], "uncovered": uncovered,
              "upgrade_operations": ops_rows, "stockout_events": n_events, "stockout_ambiguous": ambiguous,
              "changed": changed, "snapshot": snapshot}
    with open(os.path.join(a.out_dir, "report.json"), "w") as f:
        json.dump(report, f, indent=2, default=str)
    print_table(rows)
    # report.json lives in the pod's emptyDir and is gone when the Job ends: log the numbers too.
    log("NOTICE", "sizer result", run_id=run_id, snapshot=snapshot,
        rows=[{k: r.get(k) for k in RESULT_FIELDS if r.get(k) not in (None, [], "")} for r in rows])

    branch = f"reservation-sizer/{a.env_name}-{cluster_name}"
    pr_mode = github is not None and pol["mode"] in ("dry-run", "live")

    def close_stale(reason):
        """An open bot PR that no longer matches the recommendation must not stay mergeable."""
        if not pr_mode:
            return
        try:
            url = github.close_bot_pr(a.github_repo, branch,
                                      f"Closed by reservation-sizer {VERSION} (run {run_id}): {reason}")
        except Exception as e:  # noqa: BLE001
            raise SizerError(EXIT_PR, f"closing the stale bot PR failed: {e}")
        if url:
            log("NOTICE", "stale bot PR closed", url=url, reason=reason)

    if problems:
        for p in problems:
            log("ERROR", "fail-safe: " + p)
        log("ERROR", "FAIL-SAFE: data incomplete - no recommendation written (an open bot PR is left as is)",
            problems=len(problems))
        return EXIT_FAILSAFE, report
    for h in holds:
        log("WARNING", "hold: " + h)
    if blocked:
        log("WARNING", "HOLD: live reservation above the branch value - nothing proposed for any key until "
            "the file is reconciled", keys=drift)
        close_stale(f"held - live reservation above the branch value for {', '.join(drift)}; "
                    "merging this PR would trigger an apply that shrinks it")
        return EXIT_HOLD, report
    for u in uncovered:
        log("WARNING", "in-scope pool/zone has no reservation key", pool=u[0], zone=u[1], machine_type=u[2])

    new_doc = copy.deepcopy(tfvars)
    new_doc[var] = proposed
    out_tfvars = os.path.join(a.out_dir, "proposed.tfvars.json")
    with open(out_tfvars, "w") as f:
        f.write(dump_tfvars(new_doc))
    body = pr_body(meta, rows, ops_rows, n_events, uncovered, snapshot, holds=holds, ambiguous=ambiguous)
    with open(os.path.join(a.out_dir, "pr_body.md"), "w") as f:
        f.write(body)

    summary = {k: sum(1 for r in rows if r.get("status") == k) for k in
               ("INCREASE", "OK", "COULD_REDUCE", "NO_POOLS_IN_SCOPE", "NOT_CONSUMABLE", "COMMITMENT_ATTACHED",
                "DISABLED", "PENDING_APPLY", "NOT_FOUND", "NOT_READY")}
    summary["notes"] = sum(len(r.get("notes", [])) for r in rows)
    log("NOTICE", "sizer run complete", changed=changed, statuses=summary, held_keys=held, snapshot=snapshot,
        out_dir=os.path.abspath(a.out_dir), token_source=token.source)

    if changed and pr_mode:
        dry = pol["mode"] == "dry-run"
        try:
            url = github.raise_pr(a.github_repo, a.github_base, a.tfvars_path, dump_tfvars(new_doc), body,
                                  branch=branch,
                                  title=(DRY_RUN_PREFIX if dry else "")
                                  + f"reservation-sizer: {a.env_name}/{cluster_name} increase reservations",
                                  draft=dry,
                                  labels=["reservation-sizer", f"env:{a.env_name}"] + (["do-not-merge"] if dry else []))
            log("NOTICE", "pull request raised/updated", url=url)
        except SizerError:
            raise
        except Exception as e:  # noqa: BLE001
            raise SizerError(EXIT_PR, f"PR raise failed: {e}")
    elif pr_mode:
        close_stale("no increase is needed any more" + (f" (held keys: {', '.join(held)})" if held else ""))
    elif changed:
        log("NOTICE", "change proposed - PR not raised (report mode)",
            file=os.path.abspath(out_tfvars))
    return (EXIT_HOLD if holds and pol["noStacking"] else EXIT_OK), report

def main():
    try:
        code, _ = run()
    except SizerError as e:
        log("ERROR", str(e), exit_code=e.code)
        code = e.code
    except Exception as e:  # noqa: BLE001 - e.g. GitHub App auth, bad JSON
        log("ERROR", f"{type(e).__name__}: {e}", exit_code=EXIT_CONFIG)
        code = EXIT_CONFIG
    sys.exit(code)


if __name__ == "__main__":
    main()
