"""Offline tests for reservation_sizer.py. Run:  python3 -m unittest discover -s sizer/tests -v"""

import contextlib
import io
import json
import os
import shutil
import ssl
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import reservation_sizer as rs  # noqa: E402

NOW = "2026-11-04T06:00:00Z"
REGION = "test-region1"
ZA, ZB = f"{REGION}-a", f"{REGION}-b"
MT = "m-std-8"
MIGS = {("system", ZA): "gke-c1-system-aaaa1111-grp", ("system", ZB): "gke-c1-system-bbbb2222-grp",
        ("user", ZA): "gke-c1-user-cccc3333-grp", ("user", ZB): "gke-c1-user-dddd4444-grp",
        ("tenant", ZA): "gke-c1-tenant-eeee5555-grp"}


def series_points(value_fn, days=7, drop_every=None):
    end = rs.bucket(rs.parse_ts(NOW))
    start = end - days * 86400
    pts, t, i = [], start, 0
    while t <= end:
        if not (drop_every and i % drop_every == 0):
            pts.append({"interval": {"endTime": rs.iso(t)}, "value": {"int64Value": str(value_fn(t))}})
        t += rs.ALIGN
        i += 1
    return pts


class Fix:
    def __init__(self):
        self.dir = tempfile.mkdtemp()
        self.values = {("system", ZA): 3, ("system", ZB): 3, ("user", ZA): 10, ("user", ZB): 9, ("tenant", ZA): 2}
        self.value_fns = {}
        self.drop = {}
        self.surge = {"system": 1, "user": 1}
        self.ops, self.logs = [], []
        self.res = {ZA: [{"name": "res-a", "status": "READY", "specificReservation": {"count": "14", "inUseCount": "13",
                                                                   "instanceProperties": {"machineType": MT}}}],
                    ZB: [{"name": "res-b", "status": "READY", "specificReservation": {"count": "13", "inUseCount": "12",
                                                                   "instanceProperties": {"machineType": MT}}}]}
        self.tfvars = {"node_pool_reservations": {
            "k-a": {"enabled": True, "name": "res-a", "zone": ZA, "machine_type": MT, "instance_count": 14},
            "k-b": {"enabled": True, "name": "res-b", "zone": ZB, "machine_type": MT, "instance_count": 13}}}
        self.policy = {"mode": "report", "pools": ["system", "user"]}
        self.node_metric = False
        self.pool_cfg = {}        # pool -> extra "config" fields (reservationAffinity, spot)
        self.pool_extra = {}      # pool -> extra top-level fields (autoscaling)

    def write(self):
        self.policy.setdefault("historySource", "node-metric" if self.node_metric else "mig")
        pools = []
        for pn in ("system", "user", "tenant"):
            urls = [f"https://www.googleapis.com/compute/v1/projects/p/zones/{z}/instanceGroupManagers/{m}"
                    for (p, z), m in MIGS.items() if p == pn]
            pools.append({"name": pn, "config": {"machineType": MT, **self.pool_cfg.get(pn, {})},
                          "instanceGroupUrls": urls,
                          "upgradeSettings": {"maxSurge": self.surge.get(pn, 1), "strategy": "SURGE"},
                          **self.pool_extra.get(pn, {})})
        ts = []
        for key, mig in MIGS.items():
            fn = self.value_fns.get(key, (lambda v: (lambda t: v))(self.values[key]))
            if self.node_metric:
                peak_n = max(int(p["value"]["int64Value"]) for p in series_points(fn))
                for n in range(peak_n):
                    node = mig[:-4] + f"-n{n:03d}"
                    pts = [p for p in series_points(fn) if int(p["value"]["int64Value"]) > n]
                    for p in pts:
                        p["value"] = {"doubleValue": 8.0}
                    ts.append({"metric": {"type": rs.NODE_METRIC}, "resource": {"type": "k8s_node", "labels": {
                        "node_name": node, "cluster_name": "c1", "location": key[1]}}, "points": pts})
            else:
                ts.append({"metric": {"type": rs.MIG_METRIC}, "resource": {"type": "instance_group", "labels": {
                    "instance_group_name": mig, "location": key[1]}},
                    "points": series_points(fn, drop_every=self.drop.get(key))})
        files = {"cluster.json": {"name": "c1", "location": REGION, "nodePools": pools},
                 "operations.json": self.ops, "reservations.json": self.res, "timeseries.json": ts,
                 "logs.json": self.logs, "tfvars.json": self.tfvars, "policy.json": self.policy}
        for name, doc in files.items():
            with open(os.path.join(self.dir, name), "w") as f:
                json.dump(doc, f)
        return self

    def run(self, extra=()):
        self.write()
        out = os.path.join(self.dir, "out")
        code, report = rs.run(["--fixtures", self.dir, "--project", "p", "--location", REGION, "--cluster", "c1",
                               "--policy", os.path.join(self.dir, "policy.json"),
                               "--tfvars-file", os.path.join(self.dir, "tfvars.json"),
                               "--out-dir", out, "--now", NOW, "--env-name", "test", *extra])
        proposed = None
        if os.path.exists(os.path.join(out, "proposed.tfvars.json")):
            with open(os.path.join(out, "proposed.tfvars.json")) as f:
                proposed = json.load(f)["node_pool_reservations"]
        return code, report, proposed

    def cleanup(self):
        shutil.rmtree(self.dir, ignore_errors=True)


def row(report, key):
    return next(r for r in report["rows"] if r["key"] == key)


class SizerTests(unittest.TestCase):
    def setUp(self):
        self.f = Fix()

    def tearDown(self):
        self.f.cleanup()

    def test_basic_increase_and_rounding(self):
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        # zone a: system 3 -> ceil(3.3)=4, user 10 -> 11 (not 12: float rounding guard), +1 surge = 16
        self.assertEqual(row(rep, "k-a")["target"], 16)
        self.assertEqual(prop["k-a"]["instance_count"], 16)
        # zone b: 4 + ceil(9.9)=10 + 1 = 15
        self.assertEqual(prop["k-b"]["instance_count"], 15)
        self.assertTrue(rep["changed"])

    def test_surge_is_max_not_sum(self):
        self.f.surge = {"system": 1, "user": 2}
        _, rep, _ = self.f.run()
        self.assertEqual(row(rep, "k-a")["surge"], 2)

    def test_upgrade_window_excluded(self):
        end = rs.bucket(rs.parse_ts(NOW))
        s, e = end - 3 * 86400, end - 3 * 86400 + 7200
        self.f.value_fns[("user", ZA)] = lambda t: 13 if s <= t <= e else 10
        self.f.ops = [{"name": "op-1", "operationType": "UPGRADE_NODES",
                       "targetLink": f"https://container.googleapis.com/v1/projects/p/locations/{REGION}/clusters/c1/nodePools/user",
                       "startTime": rs.iso(s), "endTime": rs.iso(e)}]
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 16)        # spike of 13 ignored
        self.f.ops = []                                       # same spike without an upgrade op
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 20)        # 4 + ceil(14.3)=15 + 1
        self.assertEqual(prop["k-a"]["instance_count"], 17)    # clamped: 14 + maxStep 3

    def test_stockout_add_is_capped_and_resolved_by_event_id(self):
        def ev(ts, eid, param):
            return {"timestamp": ts, "jsonPayload": {"resultInfo": {"results": [
                {"eventId": eid, "errorMsg": {"messageId": rs.STOCKOUT_MSG, "parameters": [param]}}]}}}
        self.f.logs = [ev("2026-11-01T10:00:00Z", "e1", MIGS[("user", ZB)]),
                       ev("2026-11-02T10:00:00Z", "e2", MIGS[("user", ZB)]),
                       ev("2026-11-03T10:00:00Z", "e3", "opaque-id-123"),
                       {"timestamp": "2026-11-03T09:59:00Z", "jsonPayload": {"decision": {"eventId": "e3", "scaleUp": {
                           "increasedMigs": [{"mig": {"name": MIGS[("user", ZB)], "nodepool": "user", "zone": ZB},
                                              "requestedNodes": 2}]}}}}]
        _, rep, prop = self.f.run()
        r = row(rep, "k-b")
        self.assertEqual(r["stockout_days"], ["2026-11-01", "2026-11-02", "2026-11-03"])
        self.assertEqual(r["stockout_add"], 2)                 # capped
        self.assertEqual(r["target"], 17)                      # 15 + 2
        self.assertEqual(row(rep, "k-a")["stockout_add"], 0)

    def test_low_coverage_is_fail_safe(self):
        self.f.drop[("user", ZA)] = 2                          # ~50% of points missing
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)
        self.assertTrue(rep["problems"])

    def test_missing_series_is_fail_safe(self):
        self.f.value_fns[("user", ZB)] = lambda t: 0
        self.f.drop[("user", ZB)] = 1                          # every point dropped
        code, _, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)

    def test_no_stacking_hold(self):
        # v1.2: branch 14 > live 12 (apply pending or failed) holds ONLY that key; k-b is still sized
        self.f.res[ZA][0]["specificReservation"]["count"] = "12"
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["status"], "PENDING_APPLY")
        self.assertEqual(prop["k-a"]["instance_count"], 14)      # left at its branch value, never stacked
        self.assertEqual(prop["k-b"]["instance_count"], 15)
        self.assertEqual(rep["held_keys"], ["k-a"])

    def test_reduction_is_advisory_only(self):
        self.f.values[("user", ZA)] = 5
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(row(rep, "k-a")["status"], "COULD_REDUCE")
        self.assertEqual(prop["k-a"]["instance_count"], 14)

    def test_commitment_attached_is_skipped(self):
        self.f.res[ZA][0]["commitment"] = "https://www.googleapis.com/compute/v1/projects/p/regions/r/commitments/cud-1"
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["status"], "COMMITMENT_ATTACHED")
        self.assertEqual(prop["k-a"]["instance_count"], 14)

    def test_kill_switch(self):
        self.f.policy["enabled"] = False
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertIsNone(rep)

    def test_node_metric_fallback(self):
        self.f.node_metric = True
        self.f.policy["historySource"] = "node-metric"
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(prop["k-a"]["instance_count"], 16)

    def test_uncovered_pool_zone_reported(self):
        del self.f.tfvars["node_pool_reservations"]["k-b"]
        _, rep, _ = self.f.run()
        self.assertIn(["system", ZB, MT], [list(u) for u in rep["uncovered"]])

    def test_out_of_scope_pool_ignored(self):
        _, rep, _ = self.f.run()
        pools = [d["pool"] for d in row(rep, "k-a")["pools"]]
        self.assertEqual(sorted(pools), ["system", "user"])

    def test_unknown_pool_is_config_error(self):
        self.f.policy["pools"] = ["system", "does-not-exist"]
        with self.assertRaises(rs.SizerError) as cm:
            self.f.run()
        self.assertEqual(cm.exception.code, rs.EXIT_CONFIG)

    def test_live_above_branch_is_hold_never_shrinks(self):
        # someone raised the reservation outside Terraform: 16 live, 14 in the file, target 16.
        # Writing anything < 16 would SHRINK it on apply -> must hold.
        self.f.res[ZA][0]["specificReservation"]["count"] = "16"
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["status"], "DRIFT")
        self.assertIsNone(prop)

    def test_reservation_missing_is_hold(self):
        self.f.res[ZB] = []
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-b")["status"], "NOT_FOUND")
        self.assertEqual(prop["k-b"]["instance_count"], 13)      # held key unchanged
        self.assertEqual(prop["k-a"]["instance_count"], 16)      # other key still sized

    def test_reservation_updating_is_hold(self):
        self.f.res[ZA][0]["status"] = "UPDATING"
        code, rep, _ = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["status"], "NOT_READY")

    def test_machine_type_mismatch_is_fail_safe(self):
        self.f.res[ZA][0]["specificReservation"]["instanceProperties"]["machineType"] = "other-type"
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)

    def test_other_consumers_noted(self):
        self.f.res[ZA][0]["specificReservation"]["inUseCount"] = "14"   # > 13 in-scope nodes (3 + 10)
        _, rep, _ = self.f.run()
        self.assertTrue(any("other pools/VMs" in n for n in row(rep, "k-a")["notes"]))

    def test_dry_run_without_github_is_config_error(self):
        self.f.policy["mode"] = "dry-run"
        with self.assertRaises(rs.SizerError) as cm:
            self.f.run()
        self.assertEqual(cm.exception.code, rs.EXIT_CONFIG)

    def test_default_history_source_is_node_metric(self):
        self.assertEqual(rs.DEFAULT_POLICY["historySource"], "node-metric")

    def test_stockout_filter_is_scoped(self):
        f = rs.stockout_filter("c1", REGION, 0)
        self.assertIn('resource.labels.cluster_name="c1"', f)
        self.assertIn(f'resource.labels.location="{REGION}"', f)
        self.assertIn('log_id("container.googleapis.com/cluster-autoscaler-visibility")', f)

    def test_pr_body_and_snapshot(self):
        _, rep, _ = self.f.run()
        with open(os.path.join(self.f.dir, "out", "pr_body.md")) as fh:
            body = fh.read()
        self.assertIn(rep["snapshot"], body)
        self.assertIn("`k-a`", body)

    def test_only_count_field_changes(self):
        _, _, prop = self.f.run()
        for k, v in prop.items():
            orig = self.f.tfvars["node_pool_reservations"][k]
            self.assertEqual({x: y for x, y in v.items() if x != "instance_count"},
                             {x: y for x, y in orig.items() if x != "instance_count"})


# ----------------------------------------------------------------------------- v1.2 helpers
TEST_CA_PEM = """-----BEGIN CERTIFICATE-----
MIIB3TCCAYOgAwIBAgIURpX5H0THQifT/oprt2ZXrlNI4k4wCgYIKoZIzj0EAwIw
QzEfMB0GA1UEAwwWVGVzdCBDb3Jwb3JhdGUgUm9vdCBDQTEgMB4GA1UECgwXcmVz
ZXJ2YXRpb24tc2l6ZXIgdGVzdHMwIBcNMjYxMTA1MTcyODMxWhgPMjEyNjEwMTIx
NzI4MzFaMEMxHzAdBgNVBAMMFlRlc3QgQ29ycG9yYXRlIFJvb3QgQ0ExIDAeBgNV
BAoMF3Jlc2VydmF0aW9uLXNpemVyIHRlc3RzMFkwEwYHKoZIzj0CAQYIKoZIzj0D
AQcDQgAE4adMrOgSfRcOf49xCwQo0vSca69S6vhXcPhMNVRfhJo9Ql5epCjb9g9W
TxwmV2i2MxJ7My9qEQdfR0LpK31ghqNTMFEwHQYDVR0OBBYEFHg+i+LroYJhFUvm
aYMAtArTbWnHMB8GA1UdIwQYMBaAFHg+i+LroYJhFUvmaYMAtArTbWnHMA8GA1Ud
EwEB/wQFMAMBAf8wCgYIKoZIzj0EAwIDSAAwRQIgWnLujq5M9SI61w/L1Uas9WE0
+RgX/ucb6brhdDkCLogCIQCvwnKzcjtreYtpXYASTxOXfg/FTk7yjl5PFfadeRo9
wg==
-----END CERTIFICATE-----
"""
WINDOW_END = rs.bucket(rs.parse_ts(NOW))
WINDOW_START = WINDOW_END - 7 * 86400


def stockout_error(ts, eid, param):
    return {"timestamp": ts, "jsonPayload": {"resultInfo": {"results": [
        {"eventId": eid, "errorMsg": {"messageId": rs.STOCKOUT_MSG, "parameters": [param]}}]}}}


def scale_up_decision(ts, eid, *pool_zones):
    return {"timestamp": ts, "jsonPayload": {"decision": {"eventId": eid, "scaleUp": {"increasedMigs": [
        {"mig": {"name": MIGS[pz], "nodepool": pz[0], "zone": pz[1]}, "requestedNodes": 1} for pz in pool_zones]}}}}


class FakeGitHub:
    """Stands in for github_pr.GitHub inside rs.run(): records what the sizer asks for."""

    def __init__(self, tfvars):
        self.tfvars, self.raised, self.closed = tfvars, [], []

    def default_branch(self, repo):
        return "main"

    def get_file(self, repo, path, ref):
        return json.dumps(self.tfvars), "sha"

    def raise_pr(self, repo, base, path, content, body, branch, title, draft, labels):
        self.raised.append({"content": json.loads(content)["node_pool_reservations"], "body": body,
                            "branch": branch, "title": title, "draft": draft, "labels": labels})
        return "http://pr/1"

    def close_bot_pr(self, repo, branch, comment):
        self.closed.append((branch, comment))
        return "http://pr/1"


def run_with_github(fix, mode):
    """rs.run() in dry-run/live mode against FakeGitHub (no network, no PyJWT)."""
    fix.policy["mode"] = mode
    fix.write()
    key = os.path.join(fix.dir, "key.pem")
    with open(key, "w") as fh:
        fh.write("unused")
    fake = FakeGitHub(fix.tfvars)
    module = types.ModuleType("github_pr")
    module.GitHub = types.SimpleNamespace(from_app=lambda *a, **k: fake)
    with mock.patch.dict(sys.modules, {"github_pr": module}):
        code, report = rs.run(["--fixtures", fix.dir, "--project", "p", "--location", REGION, "--cluster", "c1",
                               "--policy", os.path.join(fix.dir, "policy.json"), "--out-dir",
                               os.path.join(fix.dir, "out"), "--now", NOW, "--env-name", "test",
                               "--github-repo", "org/infra", "--tfvars-path", "ws/r.auto.tfvars.json",
                               "--github-key-file", key, "--github-app-id", "1", "--github-installation-id", "2"])
    return code, report, fake


class V12Tests(unittest.TestCase):
    """One or more tests per review item fixed in v1.2."""

    def setUp(self):
        self.f = Fix()

    def tearDown(self):
        self.f.cleanup()

    # ---- item 1: stockout fallback lookup
    def test_item1_multi_zone_decision_without_mig_does_not_crash_and_is_skipped(self):
        self.f.logs = [stockout_error("2026-11-02T10:01:00Z", "e9", "opaque-id"),
                       scale_up_decision("2026-11-02T10:00:00Z", "e9", ("user", ZA), ("user", ZB))]
        code, rep, prop = self.f.run()                       # v1.1: KeyError -> exit 4
        self.assertEqual(code, 0)
        self.assertEqual(row(rep, "k-a")["stockout_add"], 0)
        self.assertEqual(row(rep, "k-b")["stockout_add"], 0)
        self.assertEqual(rep["stockout_ambiguous"],
                         [{"event_id": "e9", "day": "2026-11-02", "pool_zones": [f"user/{ZA}", f"user/{ZB}"]}])
        with open(os.path.join(self.f.dir, "out", "pr_body.md")) as fh:
            self.assertIn("unknown failing zone", fh.read())

    def test_item1_all_zones_policy_counts_each_zone_once(self):
        self.f.policy["stockoutAmbiguous"] = "all-zones"
        self.f.logs = [stockout_error("2026-11-02T10:01:00Z", "e9", "opaque-id"),
                       scale_up_decision("2026-11-02T10:00:00Z", "e9", ("user", ZA), ("user", ZB), ("system", ZA))]
        code, rep, _ = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(row(rep, "k-a")["stockout_days"], ["2026-11-02"])   # system+user in ZA = one day
        self.assertEqual(row(rep, "k-b")["stockout_add"], 1)

    def test_item1_bad_ambiguous_policy_is_config_error(self):
        self.f.policy["stockoutAmbiguous"] = "guess"
        with self.assertRaises(rs.SizerError) as cm:
            self.f.run()
        self.assertEqual(cm.exception.code, rs.EXIT_CONFIG)

    # ---- item 2: holds per key; drift still blocks everything
    def test_item2_pending_apply_hint_suggests_smaller_step(self):
        self.f.res[ZA][0]["specificReservation"]["count"] = "10"   # branch 14, live 10 (apply failed)
        code, rep, _ = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["step_back_to"], 12)       # live + half of the missing 4
        self.assertTrue(any("set instance_count to 12" in h for h in rep["holds"]))

    def test_item2_drift_still_blocks_every_key(self):
        self.f.res[ZA][0]["specificReservation"]["count"] = "16"   # live above branch
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertIsNone(prop)                                      # k-b NOT proposed either
        self.assertEqual(rep["blocked_by_drift"], ["k-a"])
        self.assertFalse(rep["changed"])

    def test_item2_hold_plus_increase_raises_pr_and_exits_3(self):
        self.f.res[ZA][0]["specificReservation"]["count"] = "12"
        code, rep, gh = run_with_github(self.f, "live")
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(len(gh.raised), 1)
        self.assertEqual(gh.raised[0]["content"]["k-a"]["instance_count"], 14)   # held, unchanged
        self.assertEqual(gh.raised[0]["content"]["k-b"]["instance_count"], 15)
        self.assertIn("Held keys", gh.raised[0]["body"])

    # ---- item 3: zero nodes are not missing data (node-metric)
    def test_item3_zone_at_zero_nodes_is_not_missing_data(self):
        self.f.node_metric = True
        cut = WINDOW_START + int(0.3 * 7 * 86400)
        self.f.value_fns[("user", ZB)] = lambda t: 0 if t < cut else 9    # 30% of the window at 0 nodes
        code, rep, prop = self.f.run()                                     # v1.1: NO_DATA, exit 2
        self.assertEqual(code, 0, rep["problems"])
        self.assertEqual(prop["k-b"]["instance_count"], 15)               # 4 + 10 + 1
        user_b = next(d for d in row(rep, "k-b")["pools"] if d["pool"] == "user")
        self.assertLess(user_b["buckets_with_nodes"], 0.75 * 7 * 288)

    def test_item3_cluster_wide_gap_is_still_fail_safe(self):
        self.f.node_metric = True
        cut = WINDOW_START + int(0.2 * 7 * 86400)
        for k in MIGS:                                                    # no node series at all: pipeline gap
            v = self.f.values[k]
            self.f.value_fns[k] = (lambda v: (lambda t: 0 if t < cut else v))(v)
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)
        self.assertTrue(any("cluster node-metric coverage" in p for p in rep["problems"]))

    def test_item3_out_of_scope_nodes_prove_the_pipeline_works(self):
        self.f.node_metric = True
        cut = WINDOW_START + int(0.2 * 7 * 86400)
        for k in MIGS:
            if k[0] != "tenant":                                          # tenant pool keeps reporting
                v = self.f.values[k]
                self.f.value_fns[k] = (lambda v: (lambda t: 0 if t < cut else v))(v)
        code, rep, _ = self.f.run()
        self.assertEqual(code, 0, rep["problems"])

    # ---- item 4: CA bundle is added to the public roots
    def test_item4_ssl_context_keeps_public_roots_and_adds_bundle(self):
        pem = os.path.join(self.f.dir, "corp.pem")
        with open(pem, "w") as fh:
            fh.write(TEST_CA_PEM)
        orig = ssl.SSLContext.load_default_certs
        with mock.patch.object(ssl.SSLContext, "load_default_certs", autospec=True, side_effect=orig) as m:
            ctx = rs.ssl_context(pem)
        self.assertTrue(m.called)                                          # v1.1: never called with cafile=
        subjects = [dict(x[0] for x in c["subject"]).get("commonName") for c in ctx.get_ca_certs()]
        self.assertIn("Test Corporate Root CA", subjects)
        self.assertEqual(ctx.verify_mode, ssl.CERT_REQUIRED)

    # ---- item 5: a stockout-free number for the Step 3b / Step 6 comparison
    def test_item5_target_excl_stockout_reported(self):
        self.f.logs = [stockout_error("2026-11-02T10:00:00Z", "e1", MIGS[("user", ZB)])]
        _, rep, _ = self.f.run()
        r = row(rep, "k-b")
        self.assertEqual(r["stockout_add"], 1)
        self.assertEqual(r["target_excl_stockout"], r["target"] - 1)

    # ---- item 7: dry-run PRs are marked three ways
    def test_item7_dry_run_pr_is_marked(self):
        code, _, gh = run_with_github(self.f, "dry-run")
        self.assertEqual(code, 0)
        pr = gh.raised[0]
        self.assertTrue(pr["title"].startswith("[DRY RUN] "))
        self.assertTrue(pr["draft"])
        self.assertIn("do-not-merge", pr["labels"])
        self.assertIn("DRY RUN - do not merge", pr["body"])

    def test_item7_live_pr_is_not_marked(self):
        _, _, gh = run_with_github(self.f, "live")
        pr = gh.raised[0]
        self.assertFalse(pr["title"].startswith("[DRY RUN]"))
        self.assertFalse(pr["draft"])
        self.assertNotIn("do-not-merge", pr["labels"])

    # ---- item 9: stale bot PRs are closed
    def test_item9_open_pr_closed_when_no_increase_needed(self):
        self.f.values[("user", ZA)], self.f.values[("user", ZB)] = 5, 5     # targets now below current
        code, _, gh = run_with_github(self.f, "live")
        self.assertEqual(code, 0)
        self.assertFalse(gh.raised)
        self.assertEqual(len(gh.closed), 1)
        self.assertIn("no increase is needed", gh.closed[0][1])

    def test_item9_open_pr_closed_on_drift(self):
        self.f.res[ZA][0]["specificReservation"]["count"] = "16"
        code, _, gh = run_with_github(self.f, "live")
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertFalse(gh.raised)
        self.assertIn("shrinks", gh.closed[0][1])

    def test_item9_fail_safe_leaves_open_pr_alone(self):
        self.f.drop[("user", ZA)] = 2
        code, _, gh = run_with_github(self.f, "live")
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertFalse(gh.raised)
        self.assertFalse(gh.closed)

    # ---- item 10: per-pool sum vs peak of the summed pools
    def test_item10_combined_peak_reported_next_to_per_pool_sum(self):
        t1, t2 = WINDOW_END - 2 * 86400, WINDOW_END - 4 * 86400
        self.f.value_fns[("system", ZA)] = lambda t: 6 if t1 <= t <= t1 + 3600 else 3
        self.f.value_fns[("user", ZA)] = lambda t: 12 if t2 <= t <= t2 + 3600 else 10
        _, rep, _ = self.f.run()
        r = row(rep, "k-a")
        self.assertEqual(r["target_excl_stockout"], 22)        # ceil(6.6)=7 + ceil(13.2)=14 + surge 1
        self.assertEqual(r["combined_peak"], 16)               # max(6+10, 3+12)
        self.assertEqual(r["combined_required"], 18)           # ceil(17.6)
        with open(os.path.join(self.f.dir, "out", "pr_body.md")) as fh:
            self.assertIn("`k-a` 22 vs 19", fh.read())

    # ---- item 11: out-of-scope / auto-provisioned pools on the same machine type
    def test_item11_out_of_scope_and_auto_provisioned_pools_noted(self):
        self.f.pool_extra["tenant"] = {"autoscaling": {"enabled": True, "autoprovisioned": True}}
        _, rep, _ = self.f.run()
        self.assertEqual(row(rep, "k-a")["out_of_scope_pools"], ["tenant (auto-provisioned)"])
        self.assertNotIn("out_of_scope_pools", row(rep, "k-b"))   # tenant has no MIG in zone b

    # ---- item 13: reservation affinity and Spot
    def test_item13_no_reservation_pool_not_counted(self):
        self.f.pool_cfg["user"] = {"reservationAffinity": {"consumeReservationType": "NO_RESERVATION"}}
        _, rep, _ = self.f.run()
        r = row(rep, "k-a")
        self.assertEqual(r["target"], 5)                        # system 4 + surge 1 only
        self.assertTrue(any("user cannot consume" in n for n in r["notes"]))
        self.assertNotIn("user", [u[0] for u in rep["uncovered"]])

    def test_item13_specific_required_reservation_is_not_grown(self):
        self.f.res[ZA][0]["specificReservationRequired"] = True
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(row(rep, "k-a")["status"], "NOT_CONSUMABLE")
        self.assertEqual(prop["k-a"]["instance_count"], 14)    # v1.1 grew it to 16
        self.assertEqual(prop["k-b"]["instance_count"], 15)

    def test_item13_specific_affinity_counts_only_for_named_reservation(self):
        self.f.pool_cfg["user"] = {"reservationAffinity": {
            "consumeReservationType": "SPECIFIC_RESERVATION", "key": "compute.googleapis.com/reservation-name",
            "values": [f"projects/p/zones/{ZA}/reservations/res-a"]}}
        _, rep, _ = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 16)         # user counted for res-a
        self.assertEqual(row(rep, "k-b")["target"], 5)          # but not for res-b

    def test_item13_spot_pool_not_counted(self):
        self.f.pool_cfg["user"] = {"spot": True}
        _, rep, _ = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 5)
        self.assertTrue(any("Spot" in n for n in row(rep, "k-a")["notes"]))

    # ---- minor: the result survives the pod (structured log line)
    def test_result_logged_as_one_structured_line(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            self.f.run()
        lines = [json.loads(x) for x in err.getvalue().splitlines() if x.startswith("{")]
        result = next(x for x in lines if x["message"] == "sizer result")
        ka = next(r for r in result["rows"] if r["key"] == "k-a")
        self.assertEqual((ka["target"], ka["proposed"], ka["status"]), (16, 16, "INCREASE"))


if __name__ == "__main__":
    unittest.main()
