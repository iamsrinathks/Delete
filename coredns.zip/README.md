# Add-on troubleshooting skills

One skill per add-on, same shape, so on-call engineers (and Claude) get a consistent workflow.

```
<addon>-troubleshooting/
  SKILL.md                     frontmatter (name, trigger-rich description) + workflow, safety rules, report format
  references/
    our-environment.md         our clusters, labels, paths, owners (CHANGE-ME values)
    triage-by-symptom.md       symptom -> likely causes -> distinguishing evidence -> fix
    <component specifics>.md   e.g. gke-environment, config/plugins, metrics-and-logs
    fixes-and-safety.md        GitOps change path, approved emergency actions, rollback
  scripts/
    collect.sh                 READ-ONLY evidence bundle (works without Claude; uploadable)
    analyze_bundle.py          deterministic findings from the bundle (stdlib only)
    <active probe>.sh          anything that creates objects: refuses to run without --approved
  evals/                       test cases for `claude plugin eval` (not packaged into the .skill)
```

Rules every add-on skill keeps:
1. Read-only by default; any mutation needs explicit approval for that action and cluster.
2. Fixes go through the GitOps repo (Config Sync reverts manual edits).
3. Three modes: Live (kubectl), Bundle (uploaded tarball), Guided (no access).
4. Report states confidence (confirmed / likely / hypothesis) and what was not checked.

Next candidates: `externaldns-troubleshooting` (records not created/updated, provider auth via
Workload Identity, ownership TXT records, domain filters) and `istio-troubleshooting` (larger:
split references by control plane, data plane, mTLS/authz, ingress/egress, DNS proxying).

Keep each skill in step with upgrades: when an upgrade report flags plugin/option changes,
update that add-on's references in the same PR.

Install: package with skill-creator (`python -m scripts.package_skill <folder>`) and upload the
.skill file in Claude, or use the folder directly in Claude Code / Cowork.
