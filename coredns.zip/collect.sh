#!/usr/bin/env bash
# Read-only DNS evidence collector for self-managed CoreDNS on GKE.
# Uses only: kubectl get / describe / logs / top / get --raw (GET via API proxy), and optionally
# gcloud ... describe and nomos status. Creates nothing in the cluster. Never reads Secrets.
set -uo pipefail

usage() {
  cat <<'EOF'
Usage: collect.sh --context CTX [options]
  --context CTX         kubectl context (required; confirm it is the cluster you mean)
  --gke-cluster NAME    with --region and --project: add GKE DNS config via gcloud (optional)
  --region REGION
  --project PROJECT
  --target NS/POD       a failing client pod to include (spec, events; no exec)
  --since DURATION      log window, default 2h
  --selector SEL        CoreDNS pod label selector (default app.kubernetes.io/name=coredns or $COREDNS_SELECTOR)
  --dns-service NAME    default kube-dns
  --out DIR             output directory, default .
EOF
}

CTX="" CLUSTER="" REGION="" PROJECT="" TARGET="" SINCE="2h" OUT="."
NS="kube-system" DNS_SVC="kube-dns"
SELECTOR="${COREDNS_SELECTOR:-app.kubernetes.io/name=coredns}"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --context) CTX="$2"; shift 2 ;;
    --gke-cluster) CLUSTER="$2"; shift 2 ;;
    --region) REGION="$2"; shift 2 ;;
    --project) PROJECT="$2"; shift 2 ;;
    --target) TARGET="$2"; shift 2 ;;
    --since) SINCE="$2"; shift 2 ;;
    --selector) SELECTOR="$2"; shift 2 ;;
    --dns-service) DNS_SVC="$2"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done
[[ -n "$CTX" ]] || { usage; exit 2; }
command -v kubectl >/dev/null || { echo "kubectl not found" >&2; exit 2; }

TS="$(date -u +%Y%m%dT%H%M%SZ)"
NAME="dns-bundle-${CTX//[^A-Za-z0-9_.-]/_}-${TS}"
DIR="${OUT%/}/${NAME}"
mkdir -p "$DIR/logs" "$DIR/metrics"
ERR="$DIR/collect-errors.log"
: > "$ERR"

k() { kubectl --context "$CTX" "$@"; }
save() {  # save <file> <command...>; failures are recorded, never fatal
  local file="$1"; shift
  if ! "$@" > "$DIR/$file" 2>>"$ERR"; then
    echo "FAILED: $*" >> "$ERR"
  fi
  [[ -s "$DIR/$file" ]] || rm -f "$DIR/$file"
}

echo "Collecting DNS evidence from context '$CTX' into $DIR (read-only)"
printf '{"context":"%s","collected_at":"%s","namespace":"%s","selector":"%s","dns_service":"%s","target":"%s","since":"%s","gke_cluster":"%s"}\n' \
  "$CTX" "$TS" "$NS" "$SELECTOR" "$DNS_SVC" "$TARGET" "$SINCE" "$CLUSTER" > "$DIR/meta.json"

save version.json              k version -o json
save deploy-coredns.json       k -n "$NS" get deploy -l "$SELECTOR" -o json
save rs-coredns.json           k -n "$NS" get rs -l "$SELECTOR" -o json
save pods-coredns.json         k -n "$NS" get pods -l "$SELECTOR" -o json
save describe-coredns.txt      k -n "$NS" describe pods -l "$SELECTOR"
save cm-coredns.json           k -n "$NS" get cm -l "$SELECTOR" -o json
if ! grep -q '"Corefile"' "$DIR/cm-coredns.json" 2>/dev/null; then
  save cm-coredns.json         k -n "$NS" get cm coredns -o json
fi
save svc-kube-dns.json         k -n "$NS" get svc "$DNS_SVC" -o json
save endpointslices-kube-dns.json k -n "$NS" get endpointslices -l "kubernetes.io/service-name=$DNS_SVC" -o json
save legacy-kube-dns.json      k -n "$NS" get deploy kube-dns kube-dns-autoscaler --ignore-not-found -o json
save node-local-dns.json       k -n "$NS" get ds node-local-dns --ignore-not-found -o json
save pdb-coredns.json          k -n "$NS" get pdb -l "$SELECTOR" -o json
save hpa-kube-system.json      k -n "$NS" get hpa -o json
save events-kube-system.json   k -n "$NS" get events -o json
save nodes.json                k get nodes -o json
save netpol-all.json           k get networkpolicy -A -o json
save rootsync.json             k -n config-management-system get rootsync -o json
save top-coredns.txt           k -n "$NS" top pods -l "$SELECTOR" --containers

for pod in $(k -n "$NS" get pods -l "$SELECTOR" -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' 2>>"$ERR"); do
  save "logs/${pod}.log"          k -n "$NS" logs "$pod" --all-containers --timestamps --since="$SINCE"
  save "logs/${pod}.previous.log" k -n "$NS" logs "$pod" --all-containers --timestamps --previous
  save "metrics/${pod}.txt"       k get --raw "/api/v1/namespaces/$NS/pods/${pod}:9153/proxy/metrics"
done

if [[ -n "$TARGET" ]]; then
  TNS="${TARGET%%/*}"; TPOD="${TARGET##*/}"
  save target-pod.json      k -n "$TNS" get pod "$TPOD" -o json
  save target-events.json   k -n "$TNS" get events --field-selector "involvedObject.name=$TPOD" -o json
fi

if [[ -n "$CLUSTER" ]] && command -v gcloud >/dev/null; then
  save gke-cluster.json gcloud container clusters describe "$CLUSTER" --region "$REGION" --project "$PROJECT" --format=json
fi
if command -v nomos >/dev/null; then
  save nomos-status.txt nomos status --contexts "$CTX"
fi

tar -czf "${OUT%/}/${NAME}.tar.gz" -C "${OUT%/}" "$NAME"
echo "Bundle: ${OUT%/}/${NAME}.tar.gz"
if [[ -s "$ERR" ]]; then
  echo "Some items could not be collected (see $NAME/collect-errors.log)."
fi
