---
name: coredns-troubleshooting
description: Diagnose DNS problems in our GKE clusters, where self-managed CoreDNS (Helm chart via Config Sync) replaces kube-dns. Use this skill whenever someone reports name resolution failures, NXDOMAIN or SERVFAIL, DNS timeouts or slow lookups, "could not resolve host", intermittent 5s delays, CoreDNS crashloops or restarts, kube-dns Service or endpoint problems, Corefile or stub-domain/forwarder questions, DNS after a CoreDNS upgrade or GKE upgrade, or DNS behaviour inside Istio-meshed pods, even if they don't say "CoreDNS". Also use it to analyze a DNS evidence bundle (dns-bundle-*.tar.gz) someone uploads.
---

# CoreDNS / cluster DNS troubleshooting

Goal: find the failing layer with evidence, state the root cause with an honest confidence level,
and propose a fix that goes through GitOps. Diagnose first; change nothing without approval.

## Safety rules (read before running anything)

These exist because DNS is a single point of failure for every workload in the cluster.

1. **Read-only by default.** `scripts/collect.sh` and `scripts/analyze_bundle.py` only read.
   Anything that creates, changes or deletes an object (debug pods, `kubectl exec`, restarts,
   scaling, ConfigMap edits) needs the user's explicit approval for that specific action,
   cluster and namespace. Say what it does and how to undo it before asking.
2. **Fixes go through Git.** CoreDNS objects are managed by Config Sync, which reverts manual
   edits. Propose the change as a diff to the ring/cluster overlay in the GitOps repo. Manual
   changes are only for an approved emergency, following `references/fixes-and-safety.md`.
3. **Never touch GKE-managed objects** (anything labeled `addonmanager.kubernetes.io/mode`,
   the `kube-dns` Service itself, NodeLocal DNSCache) except the documented kube-dns fallback.
4. **Production needs extra care.** Confirm the kubectl context and cluster name out loud
   before every command batch; contexts are easy to mix up across 15 clusters.
5. **Don't collect or echo Secrets.** The collector never reads them; don't add commands that do.

## Operating modes

Pick the mode from what this session can do, and say which one you're in:

- **Live**: you can run `kubectl` (and optionally `gcloud`) against the cluster. Run the
  collector yourself, then analyze.
- **Bundle**: the user uploaded a `dns-bundle-*.tar.gz`. Extract it and run the analyzer.
- **Guided**: no cluster access and no bundle. Give the user the exact collector command
  (below), ask them to upload the result, and meanwhile reason from what they describe.
  Don't guess a root cause from a symptom description alone when a bundle would settle it.

## Workflow

### 1. Frame the problem (ask only what's missing)

- Which cluster(s) and environment? Which namespace/workload?
- Symptom, verbatim: error text, which names fail, NXDOMAIN vs SERVFAIL vs timeout.
- Scope: one pod, one namespace, one node, one zone, or the whole cluster? Internal names
  (`*.svc.cluster.local`), external names, or private zones/stub domains?
- Since when, and what changed: a CoreDNS upgrade PR merge, a GKE upgrade, a NetworkPolicy,
  an Istio change, a new workload with a lot of lookups?

Scope is the strongest clue. Read `references/our-environment.md` for cluster-specific facts.

### 2. Collect evidence

```bash
# Read-only. Needs kubectl context for the cluster; gcloud flags are optional.
bash scripts/collect.sh --context <kubectl-context> \
  [--gke-cluster <name> --region <region> --project <project>] \
  [--target <namespace>/<pod>] [--since 2h]
```

It writes `dns-bundle-<context>-<timestamp>.tar.gz` and a folder with the same name. Then:

```bash
python3 scripts/analyze_bundle.py <bundle-folder-or-tar.gz>
```

The analyzer prints deterministic findings (severity, evidence, what it means). Treat them as
leads to confirm, not conclusions; it only knows the patterns it was written for.

### 3. Isolate the layer

Work from the client towards upstream. Stop at the first layer that is clearly broken, but
note anything else abnormal.

| Layer | Quick evidence | Read |
|---|---|---|
| Client pod | `dnsPolicy`, `dnsConfig`, resolv.conf (`ndots`, search list, nameserver), libc (Alpine/musl), Istio sidecar DNS capture | triage-by-symptom.md §Client |
| Network path | NetworkPolicies on client and kube-system (UDP **and** TCP 53), node/zone pattern, conntrack symptoms | triage-by-symptom.md §Network |
| Service & endpoints | `kube-dns` Service ClusterIP; EndpointSlices == ready CoreDNS pods; legacy kube-dns at 0 | gke-environment.md |
| CoreDNS pods | ready/restarts/OOM, CPU throttling, logs, Corefile, zone spread, PDB | corefile-and-plugins.md, metrics-and-logs.md |
| Upstream | `forward` targets, metadata server / Cloud DNS, stub-domain resolvers, timeouts | gke-environment.md §Upstream |
| Kubernetes API | `kubernetes` plugin watch errors, RBAC, API server availability | corefile-and-plugins.md §kubernetes |

Read `references/triage-by-symptom.md` for the symptom you have; each section lists causes in
order of likelihood here, the evidence that distinguishes them, and the fix.

### 4. Confirm with a targeted test (approval required)

If the evidence doesn't settle it, propose one specific probe, e.g. querying the same name
against the Service IP and each CoreDNS pod IP over UDP and TCP. `scripts/dns-probe.sh` does this
from a short-lived pod and deletes it afterwards; it refuses to run without `--approved`.
Never probe from inside a production application pod without the owner's approval.

### 5. Report

Use this structure so the on-call engineer and the next person can follow it:

```
## DNS diagnosis: <cluster> / <scope>
**Status:** root cause confirmed | likely | hypotheses only
**Impact:** who/what fails, since when, how often
**Root cause:** one or two sentences, naming the failing layer
**Evidence:** bullet list; each item = command or file + the observed value
**Fix (GitOps):** the file and diff in the ring/cluster overlay, or the workload change
**Mitigation now (needs approval):** only if impact is ongoing; include the undo step
**Ruled out:** layers checked and found healthy, with the evidence
**Not checked / can't see:** see "Limits" below
```

Label every claim as observed (you saw it in output) or inferred. Don't present an inference
as the root cause without saying so.

## Limits: say so when you hit them

This skill can't directly observe, and must hand off rather than guess:

- Node internals (iptables/eBPF datapath, conntrack tables, kernel) without approved node debug access.
- VPC firewall, Cloud NAT, hybrid connectivity and on-prem resolvers beyond what `gcloud` shows.
- Intermittent problems that need packet captures or long-running observation.
- The GKE control plane and Google-managed components.
In these cases, state what evidence is needed and who can get it.

## References

- `references/our-environment.md`: our setup (cluster list, rings, labels, forwarders, Istio). Read first.
- `references/triage-by-symptom.md`: symptom playbooks.
- `references/gke-environment.md`: GKE specifics: kube-dns replacement, NodeLocal DNSCache, Cloud DNS, metadata server.
- `references/corefile-and-plugins.md`: plugin behaviour and common Corefile mistakes.
- `references/metrics-and-logs.md`: metrics to read and log patterns.
- `references/fixes-and-safety.md`: change paths, emergency actions, kube-dns fallback.
