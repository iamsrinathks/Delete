#!/usr/bin/env python3
"""Analyze a DNS evidence bundle produced by collect.sh. Read-only, Python stdlib only.

Usage: analyze_bundle.py <bundle-dir | bundle.tar.gz> [--json]

Prints findings ordered by severity. Each finding has evidence and a pointer to the reference
file that explains it. Findings are leads to confirm, not conclusions.
"""
from __future__ import annotations

import json
import re
import sys
import tarfile
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

SEVERITY = ["critical", "high", "medium", "low", "info"]


class Findings:
    def __init__(self):
        self.items: list[dict] = []

    def add(self, severity: str, title: str, evidence: str, ref: str = "", next_step: str = ""):
        self.items.append({"severity": severity, "title": title, "evidence": evidence,
                           "ref": ref, "next": next_step})


# ---- loading ---------------------------------------------------------------------------

def open_bundle(path: Path) -> Path:
    if path.is_dir():
        return path
    tmp = Path(tempfile.mkdtemp(prefix="dns-bundle-"))
    with tarfile.open(path) as tf:
        for m in tf.getmembers():  # refuse absolute paths / traversal
            if m.name.startswith("/") or ".." in Path(m.name).parts:
                raise SystemExit(f"unsafe path in archive: {m.name}")
        tf.extractall(tmp)
    dirs = [p for p in tmp.iterdir() if p.is_dir()]
    return dirs[0] if len(dirs) == 1 else tmp


def load(d: Path, name: str):
    p = d / name
    if not p.exists() or p.stat().st_size == 0:
        return None
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError:
        return None


def items(obj) -> list[dict]:
    if not obj:
        return []
    if "items" in obj:
        return obj["items"] or []
    return [obj]


def ready(pod: dict) -> bool:
    st = pod.get("status") or {}
    return st.get("phase") == "Running" and any(
        c.get("type") == "Ready" and c.get("status") == "True" for c in st.get("conditions") or [])


# ---- Corefile ----------------------------------------------------------------------------

def parse_corefile(text: str) -> list[dict]:
    """Returns server blocks: {"zones": [...], "plugins": {name: [args per occurrence]},
    "options": {name: [lines inside the plugin's { } block]}}."""
    servers, cur, depth, current_plugin = [], None, 0, None
    for raw in text.splitlines():
        s = raw.split("#", 1)[0].strip()
        if not s:
            continue
        if s.startswith("}"):
            depth = max(0, depth - 1)
            if depth == 0:
                cur = None
            continue
        if depth == 0:
            cur = {"zones": s.rstrip("{").split(), "plugins": {}, "options": {}}
            servers.append(cur)
        elif depth == 1 and cur is not None:
            parts = s.rstrip("{").split()
            current_plugin = parts[0]
            cur["plugins"].setdefault(current_plugin, []).append(" ".join(parts[1:]))
        elif depth >= 2 and cur is not None and current_plugin:
            cur["options"].setdefault(current_plugin, []).append(s.rstrip("{").strip())
        if s.endswith("{"):
            depth += 1
    return servers


# ---- Prometheus text -------------------------------------------------------------------------

LINE = re.compile(r'^([a-zA-Z_:][\w:]*)(?:\{([^}]*)\})?\s+(\S+)')
LABEL = re.compile(r'(\w+)="((?:[^"\\]|\\.)*)"')


def parse_metrics(text: str) -> list[tuple[str, dict, float]]:
    out = []
    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue
        m = LINE.match(line)
        if not m:
            continue
        try:
            val = float(m.group(3))
        except ValueError:
            continue
        out.append((m.group(1), dict(LABEL.findall(m.group(2) or "")), val))
    return out


# ---- checks ----------------------------------------------------------------------------------

def analyze(d: Path) -> tuple[dict, Findings]:
    f = Findings()
    meta = load(d, "meta.json") or {}
    pods = items(load(d, "pods-coredns.json"))
    deps = items(load(d, "deploy-coredns.json"))
    svc = load(d, "svc-kube-dns.json") or {}
    slices = items(load(d, "endpointslices-kube-dns.json"))
    nodes = {n["metadata"]["name"]: n for n in items(load(d, "nodes.json"))}
    ctx = {"context": meta.get("context"), "collected_at": meta.get("collected_at"), "pods": len(pods)}

    # GKE DNS provider
    gke = load(d, "gke-cluster.json") or {}
    dns_cfg = (gke.get("networkConfig") or {}).get("dnsConfig") or {}
    if dns_cfg.get("clusterDns") == "CLOUD_DNS":
        f.add("critical", "Cloud DNS for GKE is the cluster DNS provider",
              f"networkConfig.dnsConfig={dns_cfg}", "gke-environment.md",
              "Pods are not using CoreDNS at all; confirm this was intended.")
    if ((gke.get("addonsConfig") or {}).get("dnsCacheConfig") or {}).get("enabled"):
        f.add("info", "NodeLocal DNSCache is enabled", "addonsConfig.dnsCacheConfig.enabled=true",
              "gke-environment.md", "Node-scoped failures may come from node-local-dns.")

    # CoreDNS pods
    if not pods:
        f.add("critical", "No CoreDNS pods found with the selector",
              f"selector={meta.get('selector')}", "gke-environment.md",
              "Check the selector (--selector) and that CoreDNS is deployed in kube-system.")
    ready_pods = [p for p in pods if ready(p)]
    if pods and len(ready_pods) < len(pods):
        f.add("high", f"{len(pods) - len(ready_pods)} of {len(pods)} CoreDNS pods not ready",
              ", ".join(p["metadata"]["name"] for p in pods if not ready(p)), "triage-by-symptom.md")
    reasons, restarts, digests, zones = Counter(), 0, set(), Counter()
    for p in pods:
        for cs in (p.get("status") or {}).get("containerStatuses") or []:
            restarts += cs.get("restartCount", 0)
            r = ((cs.get("lastState") or {}).get("terminated") or {}).get("reason")
            if r:
                reasons[r] += 1
            if cs.get("imageID"):
                digests.add(cs["imageID"].split("@")[-1])
        node = nodes.get((p.get("spec") or {}).get("nodeName", ""))
        if node and ready(p):
            zones[node["metadata"].get("labels", {}).get("topology.kubernetes.io/zone", "?")] += 1
    if restarts:
        f.add("high" if reasons.get("OOMKilled") else "medium", f"CoreDNS containers restarted {restarts} time(s)",
              f"last termination reasons: {dict(reasons) or 'n/a'}", "triage-by-symptom.md",
              "Check previous logs (logs/*.previous.log) and memory limits.")
    if len(digests) > 1:
        f.add("high", "CoreDNS pods run different image digests", ", ".join(sorted(digests)),
              "triage-by-symptom.md", "A rollout is in progress or stuck.")
    if nodes and len(ready_pods) >= 3 and len(zones) < 3:
        f.add("medium", f"Ready CoreDNS pods span only {len(zones)} zone(s)", str(dict(zones)),
              "triage-by-symptom.md", "A zone outage would take DNS down; add topology spread via GitOps.")

    # Deployment spec
    for dep in deps:
        spec = dep.get("spec") or {}
        tmpl = spec.get("template") or {}
        policy = (tmpl.get("spec") or {}).get("dnsPolicy", "ClusterFirst")
        if policy == "ClusterFirst":
            f.add("critical", "CoreDNS pods use dnsPolicy ClusterFirst",
                  f"{dep['metadata']['name']}.spec.template.spec.dnsPolicy={policy}", "corefile-and-plugins.md",
                  "CoreDNS would forward to itself (loop). It must be Default.")
        ru = (spec.get("strategy") or {}).get("rollingUpdate") or {}
        if str(ru.get("maxUnavailable", "25%")) not in ("0", "0%"):
            f.add("low", "Rolling updates may take CoreDNS replicas down before new ones are ready",
                  f"maxUnavailable={ru.get('maxUnavailable', 'default 25%')}", "fixes-and-safety.md")
        st = dep.get("status") or {}
        want = spec.get("replicas", 0)
        if st.get("readyReplicas", 0) < want:
            f.add("high", f"Deployment {dep['metadata']['name']} has {st.get('readyReplicas', 0)}/{want} ready",
                  json.dumps({k: st.get(k) for k in ("replicas", "updatedReplicas", "readyReplicas", "availableReplicas")}),
                  "triage-by-symptom.md")

    # Service selector and endpoints
    selector = (svc.get("spec") or {}).get("selector") or {}
    if svc and pods:
        unmatched = [p["metadata"]["name"] for p in pods
                     if any((p["metadata"].get("labels") or {}).get(k) != v for k, v in selector.items())]
        if unmatched:
            f.add("critical", "CoreDNS pods don't match the kube-dns Service selector",
                  f"selector={selector}; unmatched pods: {', '.join(unmatched)}", "gke-environment.md",
                  "The Service can't route to them. Likely a label change in a chart upgrade.")
    ep_ips = {a for s in slices for e in s.get("endpoints") or []
              if (e.get("conditions") or {}).get("ready", True) for a in e.get("addresses") or []}
    pod_ips = {(p.get("status") or {}).get("podIP") for p in ready_pods} - {None}
    if svc and not ep_ips:
        f.add("critical", "kube-dns Service has no ready endpoints", "EndpointSlices empty or none ready",
              "triage-by-symptom.md", "All DNS lookups through the Service fail.")
    elif ep_ips and pod_ips and ep_ips != pod_ips:
        f.add("high", "kube-dns endpoints differ from ready CoreDNS pods",
              f"endpoints only: {sorted(ep_ips - pod_ips)}; pods only: {sorted(pod_ips - ep_ips)}",
              "gke-environment.md", "Other pods (e.g. legacy kube-dns) may be serving, or CoreDNS isn't selected.")

    for dep in items(load(d, "legacy-kube-dns.json")):
        reps = (dep.get("spec") or {}).get("replicas", 0)
        if reps:
            f.add("high", f"Legacy {dep['metadata']['name']} is scaled to {reps}",
                  "expected 0 replicas", "gke-environment.md",
                  "kube-dns may answer some queries without our stub domains (mixed answers).")

    nld = load(d, "node-local-dns.json")
    if nld:
        st = nld.get("status") or {}
        if st.get("numberReady", 0) < st.get("desiredNumberScheduled", 0):
            f.add("high", "NodeLocal DNSCache not ready on all nodes",
                  f"{st.get('numberReady')}/{st.get('desiredNumberScheduled')} ready", "gke-environment.md")

    # Corefile
    cm = next((c for c in items(load(d, "cm-coredns.json")) if (c.get("data") or {}).get("Corefile")), None)
    if not cm:
        f.add("medium", "Corefile not found in bundle", "no ConfigMap with data.Corefile", "corefile-and-plugins.md")
    else:
        servers = parse_corefile(cm["data"]["Corefile"])
        cluster_ip = (svc.get("spec") or {}).get("clusterIP")
        for s in servers:
            pl, zones_s = s["plugins"], " ".join(s["zones"])
            for name, why, sev in (("errors", "query errors are not logged", "low"),
                                   ("ready", "readiness can't reflect plugin state", "medium")):
                if "kubernetes" in pl and name not in pl:
                    f.add(sev, f"Server `{zones_s}` has no `{name}` plugin", why, "corefile-and-plugins.md")
            opts = s["options"]
            if "health" in pl and not any("lameduck" in a for a in pl["health"] + opts.get("health", [])):
                f.add("low", f"Server `{zones_s}` health plugin without lameduck",
                      "queries can be dropped during rollouts", "corefile-and-plugins.md")
            if "forward" in pl and "cache" not in pl:
                f.add("medium", f"Server `{zones_s}` forwards without `cache`",
                      "every external lookup goes upstream", "corefile-and-plugins.md")
            for args in pl.get("forward", []):
                if cluster_ip and cluster_ip in args.split():
                    f.add("critical", f"Server `{zones_s}` forwards to the kube-dns ClusterIP",
                          f"forward {args}", "corefile-and-plugins.md", "Forwarding loop.")
                extra = f" {{ {'; '.join(opts.get('forward', []))} }}" if opts.get("forward") else ""
                f.add("info", f"Server `{zones_s}` forwards upstream", f"forward {args}{extra}", "gke-environment.md")
            if "kubernetes" in pl and "in-addr.arpa" not in " ".join(pl["kubernetes"]):  # zones are header args
                f.add("low", "kubernetes plugin doesn't serve reverse zones", "PTR lookups for cluster IPs will fail",
                      "corefile-and-plugins.md")
            if "log" in pl:
                f.add("info", f"Query logging (`log`) is on for `{zones_s}`", "high log volume", "metrics-and-logs.md")
        ctx["servers"] = [" ".join(s["zones"]) for s in servers]

    # Logs
    pats = {"loop": re.compile(r"plugin/loop.*[Ll]oop"), "timeout": re.compile(r"i/o timeout"),
            "forbidden": re.compile(r"forbidden"), "watch": re.compile(r"[Ff]ailed to (watch|list)"),
            "panic": re.compile(r"\bpanic\b"), "reload_err": re.compile(r"plugin/reload.*(error|[Ff]ail)")}
    counts, upstreams, samples = Counter(), Counter(), {}
    for log in sorted((d / "logs").glob("*.log")) if (d / "logs").exists() else []:
        for line in log.read_text(errors="replace").splitlines():
            for key, rx in pats.items():
                if rx.search(line):
                    counts[key] += 1
                    samples.setdefault(key, f"{log.name}: {line.strip()[:240]}")
                    if key == "timeout":
                        m = re.search(r"->\s*([\d.:\[\]a-f]+):53", line)
                        upstreams[m.group(1) if m else "?"] += 1
    if counts["loop"]:
        f.add("critical", "Forwarding loop detected by CoreDNS", samples["loop"], "corefile-and-plugins.md",
              "CoreDNS stops on loop detection; fix dnsPolicy or forward target.")
    if counts["timeout"]:
        f.add("high" if counts["timeout"] > 20 else "medium", f"{counts['timeout']} upstream i/o timeouts in logs",
              f"by upstream: {dict(upstreams)}; e.g. {samples['timeout']}", "triage-by-symptom.md",
              "External/private names affected; check that upstream's reachability and load.")
    if counts["forbidden"] or counts["watch"]:
        f.add("high", "kubernetes plugin API errors", samples.get("forbidden") or samples.get("watch"),
              "corefile-and-plugins.md", "Check CoreDNS RBAC and API server reachability.")
    if counts["panic"]:
        f.add("high", "panic in CoreDNS logs", samples["panic"], "metrics-and-logs.md")
    if counts["reload_err"]:
        f.add("medium", "Corefile reload errors", samples["reload_err"], "corefile-and-plugins.md",
              "The previous config is still running.")

    # Metrics
    tot = defaultdict(float)
    for mf in sorted((d / "metrics").glob("*.txt")) if (d / "metrics").exists() else []:
        for name, labels, val in parse_metrics(mf.read_text(errors="replace")):
            if name == "coredns_dns_responses_total":
                tot[f"rcode:{labels.get('rcode', '?')}"] += val
                tot["responses"] += val
            elif name in ("coredns_forward_max_concurrent_rejects_total", "coredns_forward_healthcheck_failures_total",
                          "coredns_panics_total", "coredns_reload_failed_total", "coredns_cache_hits_total",
                          "coredns_cache_misses_total"):
                tot[name] += val
    if tot["responses"]:
        servfail = tot["rcode:SERVFAIL"] / tot["responses"]
        nx = tot["rcode:NXDOMAIN"] / tot["responses"]
        ctx["servfail_ratio"], ctx["nxdomain_ratio"] = round(servfail, 4), round(nx, 4)
        if servfail > 0.01:
            f.add("high", f"SERVFAIL is {servfail:.1%} of responses (since pod start)",
                  f"{int(tot['rcode:SERVFAIL'])}/{int(tot['responses'])}", "triage-by-symptom.md",
                  "Usually upstream or stub-domain failures; compare with i/o timeouts.")
        elif servfail > 0.001:
            f.add("medium", f"SERVFAIL is {servfail:.2%} of responses", "", "triage-by-symptom.md")
        if nx > 0.5:
            f.add("medium", f"NXDOMAIN is {nx:.0%} of responses",
                  "typical of ndots:5 search-path expansion", "triage-by-symptom.md",
                  "Check client resolv.conf; FQDNs or lower ndots for chatty workloads.")
    if tot["coredns_forward_max_concurrent_rejects_total"]:
        f.add("high", "forward rejected queries at max_concurrent",
              f"{int(tot['coredns_forward_max_concurrent_rejects_total'])} rejects", "corefile-and-plugins.md",
              "Upstream too slow or too few CoreDNS replicas.")
    if tot["coredns_forward_healthcheck_failures_total"]:
        f.add("medium", "Upstream health-check failures",
              f"{int(tot['coredns_forward_healthcheck_failures_total'])}", "metrics-and-logs.md")
    if tot["coredns_panics_total"]:
        f.add("high", "CoreDNS panics recorded", f"{int(tot['coredns_panics_total'])}", "metrics-and-logs.md")
    if tot["coredns_reload_failed_total"]:
        f.add("medium", "Failed Corefile reloads", f"{int(tot['coredns_reload_failed_total'])}", "metrics-and-logs.md")
    lookups = tot["coredns_cache_hits_total"] + tot["coredns_cache_misses_total"]
    if lookups and tot["coredns_cache_hits_total"] / lookups < 0.3:
        f.add("low", f"Cache hit ratio {tot['coredns_cache_hits_total'] / lookups:.0%}", "", "corefile-and-plugins.md")
    if not (d / "metrics").exists() or not any((d / "metrics").glob("*.txt")):
        f.add("info", "No metrics collected", "pods/proxy access may be missing", "metrics-and-logs.md")

    # Events
    warn = Counter()
    for ev in items(load(d, "events-kube-system.json")):
        name = (ev.get("involvedObject") or {}).get("name", "")
        if ev.get("type") == "Warning" and ("coredns" in name or "kube-dns" in name):
            warn[f"{ev.get('reason')}: {(ev.get('message') or '')[:120]}"] += ev.get("count") or 1
    for msg, n in warn.most_common(5):
        f.add("medium", "Warning event on DNS objects", f"{n}× {msg}", "metrics-and-logs.md")

    # Config Sync
    for rs in items(load(d, "rootsync.json")):
        es = (((rs.get("status") or {}).get("sync") or {}).get("errorSummary") or {}).get("totalCount", 0)
        if es:
            f.add("high", f"RootSync {rs['metadata']['name']} reports {es} sync error(s)",
                  "kubectl -n config-management-system get rootsync -o yaml", "gke-environment.md",
                  "Git changes (including reverts) may not be applied.")

    # NetworkPolicies and target pod
    def allows_dns(pol: dict) -> bool:
        for rule in (pol.get("spec") or {}).get("egress") or []:
            ports = rule.get("ports")
            if not ports:
                return True
            protos = {p.get("protocol", "TCP") for p in ports if p.get("port") is None or str(p.get("port")) == "53"}
            if {"UDP", "TCP"} <= protos:
                return True
        return False

    egress_ns = defaultdict(list)
    for pol in items(load(d, "netpol-all.json")):
        if "Egress" in ((pol.get("spec") or {}).get("policyTypes") or []):
            egress_ns[pol["metadata"]["namespace"]].append(pol)
    target = load(d, "target-pod.json")
    if target:
        tns, tspec = target["metadata"]["namespace"], target.get("spec") or {}
        ctx["target"] = f"{tns}/{target['metadata']['name']}"
        if tspec.get("hostNetwork") and tspec.get("dnsPolicy") != "ClusterFirstWithHostNet":
            f.add("high", "Target pod uses hostNetwork without ClusterFirstWithHostNet",
                  f"dnsPolicy={tspec.get('dnsPolicy', 'ClusterFirst')}", "triage-by-symptom.md",
                  "It uses the node resolver and can't resolve cluster names.")
        if tspec.get("dnsPolicy") in ("Default", "None"):
            f.add("medium", f"Target pod dnsPolicy={tspec.get('dnsPolicy')}",
                  json.dumps(tspec.get("dnsConfig") or {}), "triage-by-symptom.md")
        if any(c.get("name") == "istio-proxy" for c in tspec.get("containers", []) + tspec.get("initContainers", [])):
            f.add("info", "Target pod has an Istio sidecar", "DNS may be proxied by the sidecar",
                  "triage-by-symptom.md", "Compare with a pod without a sidecar.")
        if any("alpine" in (c.get("image") or "") for c in tspec.get("containers", [])):
            f.add("info", "Target pod uses an Alpine-based image", "musl resolver behaviour differs",
                  "triage-by-symptom.md")
        if tns in egress_ns and not any(allows_dns(p) for p in egress_ns[tns]):
            f.add("high", f"Egress NetworkPolicies in {tns} don't clearly allow DNS (UDP+TCP 53)",
                  ", ".join(p["metadata"]["name"] for p in egress_ns[tns]), "triage-by-symptom.md",
                  "Verify the rule set; add an egress rule to kube-system DNS via GitOps.")
    elif egress_ns:
        f.add("info", f"{len(egress_ns)} namespace(s) have egress NetworkPolicies",
              ", ".join(sorted(egress_ns)[:15]), "triage-by-symptom.md",
              "If one namespace fails, check its egress allows UDP+TCP 53.")

    # Collection gaps
    errs = (d / "collect-errors.log").read_text(errors="replace") if (d / "collect-errors.log").exists() else ""
    gaps = [ln for ln in errs.splitlines() if ln.startswith("FAILED") and "--previous" not in ln]
    if gaps:
        f.add("info", f"{len(gaps)} item(s) could not be collected", "; ".join(gaps[:5])[:400], "",
              "Missing data limits these findings.")
    return ctx, f


def render(ctx: dict, f: Findings) -> str:
    order = sorted(f.items, key=lambda x: SEVERITY.index(x["severity"]))
    counts = Counter(x["severity"] for x in f.items)
    out = [f"# DNS bundle analysis: {ctx.get('context')} ({ctx.get('collected_at')})",
           "Deterministic checks only: confirm before treating any finding as the root cause.", "",
           "Summary: " + (", ".join(f"{s} {counts[s]}" for s in SEVERITY if counts[s]) or "no findings"), ""]
    for k in ("pods", "servers", "servfail_ratio", "nxdomain_ratio", "target"):
        if k in ctx:
            out.append(f"- {k}: {ctx[k]}")
    out.append("")
    for x in order:
        out.append(f"## [{x['severity'].upper()}] {x['title']}")
        if x["evidence"]:
            out.append(f"- Evidence: {x['evidence']}")
        if x["next"]:
            out.append(f"- Meaning / next: {x['next']}")
        if x["ref"]:
            out.append(f"- Reference: references/{x['ref']}")
        out.append("")
    return "\n".join(out)


def main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    d = open_bundle(Path(argv[0]))
    ctx, f = analyze(d)
    if "--json" in argv:
        print(json.dumps({"context": ctx, "findings": f.items}, indent=2))
    else:
        print(render(ctx, f))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
