#!/usr/bin/env bash
# Step 3 - identity + log access with gcloud (use terraform/sizer_access.tf instead if IAM is
# Terraform-managed in your org - do NOT mix both). Idempotent: re-running is safe.
#   DRY_RUN=1 ./setup/03-access-gcloud.sh   # print the commands only
#   ./setup/03-access-gcloud.sh
# Needs (your account): iam.roleAdmin + resourcemanager.projectIamAdmin + iam.serviceAccountAdmin
# + logging.configWriter on PROJECT_ID (and secretmanager.admin on the secret, if set).
# shellcheck source=setup/_lib.sh
source "$(dirname "$0")/_lib.sh"
need PROJECT_ID CLUSTER_NAME CLUSTER_LOCATION NAMESPACE KSA_NAME GSA_NAME CUSTOM_ROLE_ID \
     LOG_BUCKET LOG_VIEW LOG_LOCATION LOG_SINK LOG_RETENTION_DAYS
need_cmd gcloud
G=(--project "$PROJECT_ID" --quiet)
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

WI_POOL="$(gcloud container clusters describe "$CLUSTER_NAME" --region "$CLUSTER_LOCATION" "${G[@]}" \
           --format='value(workloadIdentityConfig.workloadPool)')"
[[ -n "$WI_POOL" ]] || { echo "ERROR: Workload Identity is not enabled on $CLUSTER_NAME" >&2; exit 1; }

say "1/6 Service account $GSA_EMAIL"
if gcloud iam service-accounts describe "$GSA_EMAIL" "${G[@]}" >/dev/null 2>&1; then ok "exists"
else run gcloud iam service-accounts create "$GSA_NAME" --display-name="Reservation sizer (POC) - read-only" "${G[@]}"; fi

say "2/6 Custom role $CUSTOM_ROLE_ID (read-only, 4 permissions)"
cat >"$TMP/role.yaml" <<EOF
title: Reservation Sizer Reader (POC)
description: List reservations, read GKE node pools/operations, read Monitoring time series. No writes.
stage: GA
includedPermissions:
- compute.reservations.list
- container.clusters.get
- container.operations.list
- monitoring.timeSeries.list
EOF
if gcloud iam roles describe "$CUSTOM_ROLE_ID" "${G[@]}" >/dev/null 2>&1; then
  run gcloud iam roles update "$CUSTOM_ROLE_ID" --file="$TMP/role.yaml" "${G[@]}"
else
  run gcloud iam roles create "$CUSTOM_ROLE_ID" --file="$TMP/role.yaml" "${G[@]}"
fi
run gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:$GSA_EMAIL" \
    --role="projects/$PROJECT_ID/roles/$CUSTOM_ROLE_ID" --condition=None --quiet --format=none

say "3/6 Workload Identity: ${WI_POOL}[${NAMESPACE}/${KSA_NAME}] -> $GSA_EMAIL"
run gcloud iam service-accounts add-iam-policy-binding "$GSA_EMAIL" --role=roles/iam.workloadIdentityUser \
    --member="serviceAccount:${WI_POOL}[${NAMESPACE}/${KSA_NAME}]" "${G[@]}" --format=none

say "4/6 Dedicated log bucket + sink + view for autoscaler visibility events (this cluster only)"
FILTER="log_id(\"container.googleapis.com/cluster-autoscaler-visibility\") AND resource.type=\"k8s_cluster\" AND resource.labels.cluster_name=\"$CLUSTER_NAME\" AND resource.labels.location=\"$CLUSTER_LOCATION\""
if gcloud logging buckets describe "$LOG_BUCKET" --location="$LOG_LOCATION" "${G[@]}" >/dev/null 2>&1; then ok "bucket exists"
else run gcloud logging buckets create "$LOG_BUCKET" --location="$LOG_LOCATION" --retention-days="$LOG_RETENTION_DAYS" \
        --description="Cluster autoscaler visibility events for the reservation sizer" "${G[@]}"; fi
DEST="logging.googleapis.com/projects/$PROJECT_ID/locations/$LOG_LOCATION/buckets/$LOG_BUCKET"
if gcloud logging sinks describe "$LOG_SINK" "${G[@]}" >/dev/null 2>&1; then ok "sink exists"
else run gcloud logging sinks create "$LOG_SINK" "$DEST" --log-filter="$FILTER" "${G[@]}"; fi
if gcloud logging views describe "$LOG_VIEW" --bucket="$LOG_BUCKET" --location="$LOG_LOCATION" "${G[@]}" >/dev/null 2>&1; then ok "view exists"
else run gcloud logging views create "$LOG_VIEW" --bucket="$LOG_BUCKET" --location="$LOG_LOCATION" \
        --log-filter='log_id("container.googleapis.com/cluster-autoscaler-visibility")' \
        --description="Autoscaler visibility events - read by the reservation sizer only" "${G[@]}"; fi

VIEW_RES="projects/$PROJECT_ID/locations/$LOG_LOCATION/buckets/$LOG_BUCKET/views/$LOG_VIEW"
cat >"$TMP/cond.yaml" <<EOF
title: reservation-sizer-ca-view-only
description: Read only the autoscaler visibility log view
expression: resource.name == "$VIEW_RES"
EOF
say "5/6 Log read on that ONE view only (conditional roles/logging.viewAccessor)"
run gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:$GSA_EMAIL" \
    --role=roles/logging.viewAccessor --condition-from-file="$TMP/cond.yaml" --quiet --format=none

say "6/6 Optional grants"
if [[ -n "${GITHUB_APP_SECRET:-}" ]]; then
  SP="${GITHUB_APP_SECRET_PROJECT:-$PROJECT_ID}"
  ok "secretAccessor on secret $GITHUB_APP_SECRET (project $SP) only"
  run gcloud secrets add-iam-policy-binding "$GITHUB_APP_SECRET" --project "$SP" \
      --member="serviceAccount:$GSA_EMAIL" --role=roles/secretmanager.secretAccessor --quiet --format=none
else
  warn "GITHUB_APP_SECRET empty - skipped (re-run after step 5)"
fi
if [[ -n "${LOCAL_IMPERSONATOR_MEMBER:-}" ]]; then
  ok "tokenCreator on $GSA_EMAIL for $LOCAL_IMPERSONATOR_MEMBER (lets you run step 2 AS the sizer; remove after the POC)"
  run gcloud iam service-accounts add-iam-policy-binding "$GSA_EMAIL" --role=roles/iam.serviceAccountTokenCreator \
      --member="$LOCAL_IMPERSONATOR_MEMBER" "${G[@]}" --format=none
fi
if [[ "${CREATE_LOG_METRIC:-0}" == "1" ]]; then
  MF="resource.type=\"k8s_container\" AND resource.labels.namespace_name=\"$NAMESPACE\" AND jsonPayload.component=\"reservation-sizer\" AND severity>=ERROR"
  if gcloud logging metrics describe reservation_sizer_errors "${G[@]}" >/dev/null 2>&1; then ok "log metric exists"
  else run gcloud logging metrics create reservation_sizer_errors --log-filter="$MF" \
          --description="reservation-sizer fail-safe / config / PR errors - alert on > 0" "${G[@]}"; fi
fi

say "Done"
echo "  LOG_RESOURCE (CronJob): $VIEW_RES"
echo "  Sink writer identity:   $(gcloud logging sinks describe "$LOG_SINK" "${G[@]}" --format='value(writerIdentity)' 2>/dev/null)"
echo "  Check entries arrive (wait ~15 min after any scale event):"
echo "    gcloud logging read 'log_id(\"container.googleapis.com/cluster-autoscaler-visibility\")' --project $PROJECT_ID \\"
echo "      --bucket $LOG_BUCKET --location $LOG_LOCATION --view $LOG_VIEW --limit 3 --format='value(timestamp)'"
echo "  If nothing arrives, grant the writer identity roles/logging.bucketWriter."
echo "  NOTE: the bucket only holds events from now on - the stockout signal builds up over the window."
