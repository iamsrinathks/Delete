"""End-to-end test of sizer/github_pr.py against a local mock GitHub API (needs PyJWT[crypto]).
Run:  python3 -m unittest discover -s tests -v
"""

import base64
import json
import os
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(KIT, "sizer"))

try:
    import jwt  # noqa: F401
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    HAVE_JWT = True
except ImportError:  # pragma: no cover
    HAVE_JWT = False

REPO, PATH, BASE_SHA = "org/infra", "ws/node_pool_reservations.auto.tfvars.json", "base000"
FILE = json.dumps({"node_pool_reservations": {"k": {"instance_count": 1}}})


class Mock(BaseHTTPRequestHandler):
    calls, state = [], {}

    def log_message(self, *a):
        pass

    def _send(self, code, obj=None):
        body = json.dumps(obj).encode() if obj is not None else b""
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle(self, method):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n)) if n else None
        path = self.path.split("?")[0]
        Mock.calls.append((method, path, body, self.headers.get("Authorization", "")))
        st = Mock.state
        if method == "POST" and path.endswith("/access_tokens"):
            return self._send(201, {"token": "inst-token"})
        if method == "GET" and path == f"/repos/{REPO}":
            return self._send(200, {"default_branch": "main"})
        if method == "GET" and path == f"/repos/{REPO}/git/ref/heads/main":
            return self._send(200, {"object": {"sha": BASE_SHA}})
        if method == "GET" and path.startswith(f"/repos/{REPO}/git/ref/heads/reservation-sizer/"):
            return self._send(200, {"object": {"sha": "old"}}) if st.get("branch") else self._send(404, {"message": "Not Found"})
        if method == "POST" and path == f"/repos/{REPO}/git/refs":
            st["branch"] = True
            return self._send(201, {})
        if method == "PATCH" and "/git/refs/heads/" in path:
            return self._send(200, {})
        if method == "GET" and path == f"/repos/{REPO}/contents/{PATH}":
            return self._send(200, {"content": base64.b64encode(FILE.encode()).decode(), "sha": "filesha"})
        if method == "PUT" and path == f"/repos/{REPO}/contents/{PATH}":
            st["written"] = base64.b64decode(body["content"]).decode()
            return self._send(200, {})
        if method == "GET" and path == f"/repos/{REPO}/pulls":
            return self._send(200, [{"number": 7, "html_url": "http://pr/7"}] if st.get("pr") else [])
        if method == "POST" and path == f"/repos/{REPO}/pulls":
            st["pr"] = True
            return self._send(201, {"number": 7, "html_url": "http://pr/7"})
        if method == "PATCH" and path == f"/repos/{REPO}/pulls/7":
            return self._send(200, {"number": 7, "html_url": "http://pr/7"})
        if method == "POST" and path == f"/repos/{REPO}/issues/7/labels":
            return self._send(403, {"message": "Resource not accessible by integration"})  # must be non-fatal
        return self._send(500, {"message": f"unexpected {method} {path}"})

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_PATCH(self):
        self._handle("PATCH")


@unittest.skipUnless(HAVE_JWT, "PyJWT[crypto] not installed")
class GitHubPrTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.pop("HTTPS_PROXY", None)
        os.environ.pop("HTTP_PROXY", None)
        os.environ["NO_PROXY"] = "127.0.0.1,localhost"
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), Mock)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.api = f"http://127.0.0.1:{cls.srv.server_port}"
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                    serialization.NoEncryption()).decode()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def setUp(self):
        Mock.calls.clear()
        Mock.state.clear()
        import github_pr
        self.gh_mod = github_pr

    def test_token_is_down_scoped_and_pr_flow(self):
        gh = self.gh_mod.GitHub.from_app(self.api, "123", "456", self.pem, repo=REPO)
        method, path, body, auth = Mock.calls[0]
        self.assertEqual(path, "/app/installations/456/access_tokens")
        self.assertEqual(body["repositories"], ["infra"])
        self.assertEqual(body["permissions"], {"contents": "write", "pull_requests": "write"})
        self.assertTrue(auth.startswith("Bearer ey"))                       # signed App JWT

        new = json.dumps({"node_pool_reservations": {"k": {"instance_count": 3}}})
        url = gh.raise_pr(REPO, None, PATH, new, "body", branch="reservation-sizer/pre-c1",
                          title="t", draft=True, labels=["reservation-sizer", "do-not-merge"])
        self.assertEqual(url, "http://pr/7")
        self.assertEqual(Mock.state["written"], new)
        pr_post = [c for c in Mock.calls if c[0] == "POST" and c[1] == f"/repos/{REPO}/pulls"][0]
        self.assertTrue(pr_post[2]["draft"])
        self.assertTrue(all(c[3] == "Bearer inst-token" for c in Mock.calls[1:]))
        writes = [c for c in Mock.calls if c[0] in ("PUT",)]
        self.assertEqual(len(writes), 1)                                     # exactly one file committed

        # second run: branch exists -> force-reset to base, PR updated not duplicated
        Mock.calls.clear()
        gh.raise_pr(REPO, "main", PATH, new, "body2", branch="reservation-sizer/pre-c1",
                    title="t", draft=True, labels=[])
        reset = [c for c in Mock.calls if c[0] == "PATCH" and "/git/refs/heads/" in c[1]][0]
        self.assertEqual(reset[2], {"sha": BASE_SHA, "force": True})
        self.assertFalse([c for c in Mock.calls if c[0] == "POST" and c[1] == f"/repos/{REPO}/pulls"])
        self.assertTrue([c for c in Mock.calls if c[0] == "PATCH" and c[1] == f"/repos/{REPO}/pulls/7"])


if __name__ == "__main__":
    unittest.main()
