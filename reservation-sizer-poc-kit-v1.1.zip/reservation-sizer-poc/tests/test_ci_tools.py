"""Tests for the CI guards and the HCL->JSON converter. Run:  python3 -m unittest discover -s tests -v"""

import json
import os
import subprocess
import sys
import tempfile
import unittest

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECK = os.path.join(KIT, "ci", "check_reservation_change.py")
PLAN = os.path.join(KIT, "ci", "check_tf_plan.py")
HCL = os.path.join(KIT, "terraform", "hcl_map_to_json.py")

BASE = {"node_pool_reservations": {
    "k-a": {"enabled": True, "name": "res-a", "zone": "r1-a", "machine_type": "m-8", "instance_count": 14},
    "k-b": {"enabled": True, "name": "res-b", "zone": "r1-b", "machine_type": "m-8", "instance_count": 13}}}


def dump(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f)


def write(path, text):
    with open(path, "w") as f:
        f.write(text)


def load(path):
    with open(path) as f:
        return json.load(f)


def run(*args):
    p = subprocess.run([sys.executable, *args], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


class ChangeCheck(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()

    def check(self, head, changed=None, extra=()):
        b, h = os.path.join(self.d, "b.json"), os.path.join(self.d, "h.json")
        dump(BASE, b)
        dump(head, h)
        args = [CHECK, "--base", b, "--head", h, "--max-step", "3", *extra]
        if changed is not None:
            c = os.path.join(self.d, "changed.txt")
            write(c, "\n".join(changed) + "\n")
            args += ["--changed-files", c, "--allowed-path", "ws/node_pool_reservations.auto.tfvars.json"]
        return run(*args)

    def head(self, **counts):
        h = json.loads(json.dumps(BASE))
        for k, v in counts.items():
            h["node_pool_reservations"][k.replace("_", "-")]["instance_count"] = v
        return h

    def test_valid_increase(self):
        code, out = self.check(self.head(k_a=16), ["ws/node_pool_reservations.auto.tfvars.json"])
        self.assertEqual(code, 0, out)

    def test_decrease_rejected(self):
        code, out = self.check(self.head(k_a=12))
        self.assertEqual(code, 1)
        self.assertIn("decrease", out)

    def test_step_too_big(self):
        code, out = self.check(self.head(k_a=18))
        self.assertEqual(code, 1)
        self.assertIn("exceeds max step", out)

    def test_other_field_changed(self):
        h = self.head(k_a=15)
        h["node_pool_reservations"]["k-a"]["machine_type"] = "m-16"
        code, out = self.check(h)
        self.assertEqual(code, 1)
        self.assertIn("machine_type", out)

    def test_key_added(self):
        h = self.head(k_a=15)
        h["node_pool_reservations"]["k-c"] = dict(BASE["node_pool_reservations"]["k-a"], zone="r1-c")
        code, out = self.check(h)
        self.assertEqual(code, 1)
        self.assertIn("added", out)

    def test_other_file_changed(self):
        code, out = self.check(self.head(k_a=15), ["ws/node_pool_reservations.auto.tfvars.json", "ws/iam.tf"])
        self.assertEqual(code, 1)
        self.assertIn("ws/iam.tf", out)

    def test_no_change(self):
        code, out = self.check(self.head())
        self.assertEqual(code, 1)
        self.assertIn("no count changed", out)

    def test_string_count_rejected(self):
        h = self.head()
        h["node_pool_reservations"]["k-a"]["instance_count"] = "15"
        code, _ = self.check(h)
        self.assertEqual(code, 1)


class PlanCheck(unittest.TestCase):
    def plan(self, changes):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "plan.json")
        dump({"resource_changes": changes}, p)
        return run(PLAN, p)

    @staticmethod
    def rc(actions, before, after, typ="google_compute_reservation", addr='module.r.google_compute_reservation.this["k-a"]'):
        return {"address": addr, "type": typ, "change": {"actions": actions, "before": before, "after": after}}

    def test_count_update_ok(self):
        b = {"name": "res-a", "specific_reservation": [{"count": 14, "in_use_count": 13}]}
        a = {"name": "res-a", "specific_reservation": [{"count": 16, "in_use_count": 13}]}
        code, out = self.plan([self.rc(["update"], b, a)])
        self.assertEqual(code, 0, out)

    def test_replace_rejected(self):
        code, _ = self.plan([self.rc(["delete", "create"], {"name": "a"}, {"name": "b"})])
        self.assertEqual(code, 1)

    def test_other_attr_rejected(self):
        b = {"name": "res-a", "specific_reservation": [{"count": 14}], "description": "x"}
        a = {"name": "res-a", "specific_reservation": [{"count": 15}], "description": "y"}
        code, out = self.plan([self.rc(["update"], b, a)])
        self.assertEqual(code, 1)
        self.assertIn("description", out)

    def test_other_resource_rejected(self):
        code, _ = self.plan([self.rc(["update"], {}, {"x": 1}, typ="google_project_iam_member", addr="x")])
        self.assertEqual(code, 1)


class HclConvert(unittest.TestCase):
    def test_roundtrip_and_strip(self):
        d = tempfile.mkdtemp()
        src = os.path.join(d, "terraform.tfvars")
        write(src, '''project_id = "p1"   # keep me
# reservations per zone
node_pool_reservations = {
  "res-ew-m8-a" = {
    enabled        = true
    name           = "res-ew-m8"   // inline comment
    zone           = "r1-a"
    machine_type   = "m-8"
    instance_count = 14
  }
  res-ew-m8-b = {
    enabled = false, name = "res-ew-m8", zone = "r1-b", machine_type = "m-8", instance_count = 13
  }
}
other = 3
''')
        out = os.path.join(d, "node_pool_reservations.auto.tfvars.json")
        code, msg = run(HCL, src, "--out", out, "--strip")
        self.assertEqual(code, 0, msg)
        doc = load(out)["node_pool_reservations"]
        self.assertEqual(doc["res-ew-m8-a"]["instance_count"], 14)
        self.assertIs(doc["res-ew-m8-b"]["enabled"], False)
        with open(src + ".new") as f:
            new = f.read()
        self.assertNotIn("instance_count", new)
        self.assertIn('project_id = "p1"', new)
        self.assertIn("other = 3", new)

    def test_expression_rejected(self):
        d = tempfile.mkdtemp()
        src = os.path.join(d, "t.tfvars")
        write(src, 'node_pool_reservations = {\n  a = { instance_count = var.x }\n}\n')
        code, _ = run(HCL, src, "--out", os.path.join(d, "o.json"))
        self.assertNotEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
