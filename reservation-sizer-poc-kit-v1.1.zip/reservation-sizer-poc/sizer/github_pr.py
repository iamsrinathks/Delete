"""
github_pr.py - minimal GitHub App client used by reservation_sizer.py to raise ONE PR per file.

Needs PyJWT[crypto] (PyJWT + cryptography) for the App JWT. Works with github.com and GitHub
Enterprise Server (pass --github-api https://<ghe-host>/api/v3). Honours HTTPS_PROXY / NO_PROXY
and an optional corporate CA bundle. TLS verification is always on.

Behaviour:
  * installation token is DOWN-SCOPED to the one repo, contents:write + pull_requests:write only
  * fixed branch reservation-sizer/<env>-<cluster>, reset to the base branch on every run
  * commits only the one tfvars file; opens a PR or updates the existing open one
  * dry-run mode -> draft PR + do-not-merge label (falls back to non-draft if drafts unsupported)
If your team already has a PR raiser, ignore this module and feed it sizer-out/proposed.tfvars.json
and sizer-out/pr_body.md.
"""

import base64
import json
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

TOKEN_PERMISSIONS = {"contents": "write", "pull_requests": "write"}


class GitHubError(Exception):
    pass


class GitHub:
    def __init__(self, api, token, ca_bundle=None):
        self.api, self.token = api.rstrip("/"), token
        ctx = ssl.create_default_context(cafile=ca_bundle) if ca_bundle else ssl.create_default_context()
        self.opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

    @classmethod
    def from_app(cls, api, app_id, installation_id, private_key_pem, repo=None, ca_bundle=None):
        if not (app_id and installation_id and private_key_pem):
            raise GitHubError("GitHub App id, installation id and private key are all required")
        import jwt  # PyJWT
        now = int(time.time())
        app_jwt = jwt.encode({"iat": now - 60, "exp": now + 540, "iss": str(app_id)}, private_key_pem, algorithm="RS256")
        body = {"permissions": TOKEN_PERMISSIONS}
        if repo:
            body["repositories"] = [repo.split("/", 1)[-1]]
        tmp = cls(api, None, ca_bundle)
        d = tmp._call("POST", f"/app/installations/{installation_id}/access_tokens", body, auth=f"Bearer {app_jwt}")
        return cls(api, d["token"], ca_bundle)

    def _call(self, method, path, body=None, auth=None, ok404=False):
        url = path if path.startswith("http") else self.api + path
        hdrs = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "reservation-sizer"}
        if auth or self.token:
            hdrs["Authorization"] = auth or f"Bearer {self.token}"
        data = json.dumps(body).encode() if body is not None else None
        if data:
            hdrs["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        try:
            with self.opener.open(req, timeout=60) as r:
                raw = r.read()
                return json.loads(raw.decode()) if raw else {}
        except urllib.error.HTTPError as e:
            if ok404 and e.code == 404:
                return None
            raise GitHubError(f"GitHub {method} {path.split('?')[0]} -> HTTP {e.code}: "
                              f"{e.read().decode(errors='replace')[:400]}")

    def default_branch(self, repo):
        return self._call("GET", f"/repos/{repo}")["default_branch"]

    def get_file(self, repo, path, ref):
        q = urllib.parse.urlencode({"ref": ref})
        d = self._call("GET", f"/repos/{repo}/contents/{urllib.parse.quote(path)}?{q}")
        return base64.b64decode(d["content"]).decode(), d["sha"]

    def raise_pr(self, repo, base, path, content, body, branch, title, draft, labels):
        base = base or self.default_branch(repo)
        base_sha = self._call("GET", f"/repos/{repo}/git/ref/heads/{urllib.parse.quote(base)}")["object"]["sha"]
        ref = self._call("GET", f"/repos/{repo}/git/ref/heads/{urllib.parse.quote(branch)}", ok404=True)
        if ref is None:
            self._call("POST", f"/repos/{repo}/git/refs", {"ref": f"refs/heads/{branch}", "sha": base_sha})
        else:  # reset the bot branch so the PR always holds exactly one fresh change on top of base
            self._call("PATCH", f"/repos/{repo}/git/refs/heads/{urllib.parse.quote(branch)}",
                       {"sha": base_sha, "force": True})
        _, file_sha = self.get_file(repo, path, branch)
        self._call("PUT", f"/repos/{repo}/contents/{urllib.parse.quote(path)}", {
            "message": title, "content": base64.b64encode(content.encode()).decode(),
            "sha": file_sha, "branch": branch})
        owner = repo.split("/")[0]
        q = urllib.parse.urlencode({"head": f"{owner}:{branch}", "state": "open"})
        prs = self._call("GET", f"/repos/{repo}/pulls?{q}") or []
        if prs:
            pr = prs[0]
            self._call("PATCH", f"/repos/{repo}/pulls/{pr['number']}", {"title": title, "body": body})
        else:
            try:
                pr = self._call("POST", f"/repos/{repo}/pulls",
                                {"title": title, "head": branch, "base": base, "body": body, "draft": draft})
            except GitHubError as e:
                if not draft or "draft" not in str(e).lower():
                    raise
                pr = self._call("POST", f"/repos/{repo}/pulls",
                                {"title": title, "head": branch, "base": base, "body": body})
        if labels:
            try:
                self._call("POST", f"/repos/{repo}/issues/{pr['number']}/labels", {"labels": labels})
            except GitHubError as e:  # labels are informational; the CI guard is the real control
                print(json.dumps({"severity": "WARNING", "component": "reservation-sizer",
                                  "message": f"could not add labels: {e}"}), file=sys.stderr)
        return pr.get("html_url", "")
