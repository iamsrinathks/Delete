"""Offline tests for reservation_sizer.py. Run:  python3 -m unittest discover -s sizer/tests -v"""

import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import reservation_sizer as rs  # noqa: E402

NOW = "2026-11-04T06:00:00Z"
REGION = "test-region1"
ZA, ZB = f"{REGION}-a", f"{REGION}-b"
MT = "m-std-8"
MIGS = {("system", ZA): "gke-c1-system-aaaa1111-grp", ("system", ZB): "gke-c1-system-bbbb2222-grp",
        ("user", ZA): "gke-c1-user-cccc3333-grp", ("user", ZB): "gke-c1-user-dddd4444-grp",
        ("tenant", ZA): "gke-c1-tenant-eeee5555-grp"}


def series_points(value_fn, days=7, drop_every=None):
    end = rs.bucket(rs.parse_ts(NOW))
    start = end - days * 86400
    pts, t, i = [], start, 0
    while t <= end:
        if not (drop_every and i % drop_every == 0):
            pts.append({"interval": {"endTime": rs.iso(t)}, "value": {"int64Value": str(value_fn(t))}})
        t += rs.ALIGN
        i += 1
    return pts


class Fix:
    def __init__(self):
        self.dir = tempfile.mkdtemp()
        self.values = {("system", ZA): 3, ("system", ZB): 3, ("user", ZA): 10, ("user", ZB): 9, ("tenant", ZA): 2}
        self.value_fns = {}
        self.drop = {}
        self.surge = {"system": 1, "user": 1}
        self.ops, self.logs = [], []
        self.res = {ZA: [{"name": "res-a", "status": "READY", "specificReservation": {"count": "14", "inUseCount": "13",
                                                                   "instanceProperties": {"machineType": MT}}}],
                    ZB: [{"name": "res-b", "status": "READY", "specificReservation": {"count": "13", "inUseCount": "12",
                                                                   "instanceProperties": {"machineType": MT}}}]}
        self.tfvars = {"node_pool_reservations": {
            "k-a": {"enabled": True, "name": "res-a", "zone": ZA, "machine_type": MT, "instance_count": 14},
            "k-b": {"enabled": True, "name": "res-b", "zone": ZB, "machine_type": MT, "instance_count": 13}}}
        self.policy = {"mode": "report", "pools": ["system", "user"]}
        self.node_metric = False

    def write(self):
        self.policy.setdefault("historySource", "node-metric" if self.node_metric else "mig")
        pools = []
        for pn in ("system", "user", "tenant"):
            urls = [f"https://www.googleapis.com/compute/v1/projects/p/zones/{z}/instanceGroupManagers/{m}"
                    for (p, z), m in MIGS.items() if p == pn]
            pools.append({"name": pn, "config": {"machineType": MT}, "instanceGroupUrls": urls,
                          "upgradeSettings": {"maxSurge": self.surge.get(pn, 1), "strategy": "SURGE"}})
        ts = []
        for key, mig in MIGS.items():
            fn = self.value_fns.get(key, (lambda v: (lambda t: v))(self.values[key]))
            if self.node_metric:
                peak_n = max(int(p["value"]["int64Value"]) for p in series_points(fn))
                for n in range(peak_n):
                    node = mig[:-4] + f"-n{n:03d}"
                    pts = [p for p in series_points(fn) if int(p["value"]["int64Value"]) > n]
                    for p in pts:
                        p["value"] = {"doubleValue": 8.0}
                    ts.append({"metric": {"type": rs.NODE_METRIC}, "resource": {"type": "k8s_node", "labels": {
                        "node_name": node, "cluster_name": "c1", "location": key[1]}}, "points": pts})
            else:
                ts.append({"metric": {"type": rs.MIG_METRIC}, "resource": {"type": "instance_group", "labels": {
                    "instance_group_name": mig, "location": key[1]}},
                    "points": series_points(fn, drop_every=self.drop.get(key))})
        files = {"cluster.json": {"name": "c1", "location": REGION, "nodePools": pools},
                 "operations.json": self.ops, "reservations.json": self.res, "timeseries.json": ts,
                 "logs.json": self.logs, "tfvars.json": self.tfvars, "policy.json": self.policy}
        for name, doc in files.items():
            with open(os.path.join(self.dir, name), "w") as f:
                json.dump(doc, f)
        return self

    def run(self, extra=()):
        self.write()
        out = os.path.join(self.dir, "out")
        code, report = rs.run(["--fixtures", self.dir, "--project", "p", "--location", REGION, "--cluster", "c1",
                               "--policy", os.path.join(self.dir, "policy.json"),
                               "--tfvars-file", os.path.join(self.dir, "tfvars.json"),
                               "--out-dir", out, "--now", NOW, "--env-name", "test", *extra])
        proposed = None
        if os.path.exists(os.path.join(out, "proposed.tfvars.json")):
            with open(os.path.join(out, "proposed.tfvars.json")) as f:
                proposed = json.load(f)["node_pool_reservations"]
        return code, report, proposed

    def cleanup(self):
        shutil.rmtree(self.dir, ignore_errors=True)


def row(report, key):
    return next(r for r in report["rows"] if r["key"] == key)


class SizerTests(unittest.TestCase):
    def setUp(self):
        self.f = Fix()

    def tearDown(self):
        self.f.cleanup()

    def test_basic_increase_and_rounding(self):
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        # zone a: system 3 -> ceil(3.3)=4, user 10 -> 11 (not 12: float rounding guard), +1 surge = 16
        self.assertEqual(row(rep, "k-a")["target"], 16)
        self.assertEqual(prop["k-a"]["instance_count"], 16)
        # zone b: 4 + ceil(9.9)=10 + 1 = 15
        self.assertEqual(prop["k-b"]["instance_count"], 15)
        self.assertTrue(rep["changed"])

    def test_surge_is_max_not_sum(self):
        self.f.surge = {"system": 1, "user": 2}
        _, rep, _ = self.f.run()
        self.assertEqual(row(rep, "k-a")["surge"], 2)

    def test_upgrade_window_excluded(self):
        end = rs.bucket(rs.parse_ts(NOW))
        s, e = end - 3 * 86400, end - 3 * 86400 + 7200
        self.f.value_fns[("user", ZA)] = lambda t: 13 if s <= t <= e else 10
        self.f.ops = [{"name": "op-1", "operationType": "UPGRADE_NODES",
                       "targetLink": f"https://container.googleapis.com/v1/projects/p/locations/{REGION}/clusters/c1/nodePools/user",
                       "startTime": rs.iso(s), "endTime": rs.iso(e)}]
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 16)        # spike of 13 ignored
        self.f.ops = []                                       # same spike without an upgrade op
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["target"], 20)        # 4 + ceil(14.3)=15 + 1
        self.assertEqual(prop["k-a"]["instance_count"], 17)    # clamped: 14 + maxStep 3

    def test_stockout_add_is_capped_and_resolved_by_event_id(self):
        def ev(ts, eid, param):
            return {"timestamp": ts, "jsonPayload": {"resultInfo": {"results": [
                {"eventId": eid, "errorMsg": {"messageId": rs.STOCKOUT_MSG, "parameters": [param]}}]}}}
        self.f.logs = [ev("2026-11-01T10:00:00Z", "e1", MIGS[("user", ZB)]),
                       ev("2026-11-02T10:00:00Z", "e2", MIGS[("user", ZB)]),
                       ev("2026-11-03T10:00:00Z", "e3", "opaque-id-123"),
                       {"timestamp": "2026-11-03T09:59:00Z", "jsonPayload": {"decision": {"eventId": "e3", "scaleUp": {
                           "increasedMigs": [{"mig": {"name": MIGS[("user", ZB)], "nodepool": "user", "zone": ZB},
                                              "requestedNodes": 2}]}}}}]
        _, rep, prop = self.f.run()
        r = row(rep, "k-b")
        self.assertEqual(r["stockout_days"], ["2026-11-01", "2026-11-02", "2026-11-03"])
        self.assertEqual(r["stockout_add"], 2)                 # capped
        self.assertEqual(r["target"], 17)                      # 15 + 2
        self.assertEqual(row(rep, "k-a")["stockout_add"], 0)

    def test_low_coverage_is_fail_safe(self):
        self.f.drop[("user", ZA)] = 2                          # ~50% of points missing
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)
        self.assertTrue(rep["problems"])

    def test_missing_series_is_fail_safe(self):
        self.f.value_fns[("user", ZB)] = lambda t: 0
        self.f.drop[("user", ZB)] = 1                          # every point dropped
        code, _, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)

    def test_no_stacking_hold(self):
        self.f.res[ZA][0]["specificReservation"]["count"] = "12"   # branch says 14, live 12
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertIsNone(prop)

    def test_reduction_is_advisory_only(self):
        self.f.values[("user", ZA)] = 5
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(row(rep, "k-a")["status"], "COULD_REDUCE")
        self.assertEqual(prop["k-a"]["instance_count"], 14)

    def test_commitment_attached_is_skipped(self):
        self.f.res[ZA][0]["commitment"] = "https://www.googleapis.com/compute/v1/projects/p/regions/r/commitments/cud-1"
        _, rep, prop = self.f.run()
        self.assertEqual(row(rep, "k-a")["status"], "COMMITMENT_ATTACHED")
        self.assertEqual(prop["k-a"]["instance_count"], 14)

    def test_kill_switch(self):
        self.f.policy["enabled"] = False
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertIsNone(rep)

    def test_node_metric_fallback(self):
        self.f.node_metric = True
        self.f.policy["historySource"] = "node-metric"
        code, rep, prop = self.f.run()
        self.assertEqual(code, 0)
        self.assertEqual(prop["k-a"]["instance_count"], 16)

    def test_uncovered_pool_zone_reported(self):
        del self.f.tfvars["node_pool_reservations"]["k-b"]
        _, rep, _ = self.f.run()
        self.assertIn(["system", ZB, MT], [list(u) for u in rep["uncovered"]])

    def test_out_of_scope_pool_ignored(self):
        _, rep, _ = self.f.run()
        pools = [d["pool"] for d in row(rep, "k-a")["pools"]]
        self.assertEqual(sorted(pools), ["system", "user"])

    def test_unknown_pool_is_config_error(self):
        self.f.policy["pools"] = ["system", "does-not-exist"]
        with self.assertRaises(rs.SizerError) as cm:
            self.f.run()
        self.assertEqual(cm.exception.code, rs.EXIT_CONFIG)

    def test_live_above_branch_is_hold_never_shrinks(self):
        # someone raised the reservation outside Terraform: 16 live, 14 in the file, target 16.
        # Writing anything < 16 would SHRINK it on apply -> must hold.
        self.f.res[ZA][0]["specificReservation"]["count"] = "16"
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["status"], "DRIFT")
        self.assertIsNone(prop)

    def test_reservation_missing_is_hold(self):
        self.f.res[ZB] = []
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-b")["status"], "NOT_FOUND")
        self.assertIsNone(prop)

    def test_reservation_updating_is_hold(self):
        self.f.res[ZA][0]["status"] = "UPDATING"
        code, rep, _ = self.f.run()
        self.assertEqual(code, rs.EXIT_HOLD)
        self.assertEqual(row(rep, "k-a")["status"], "NOT_READY")

    def test_machine_type_mismatch_is_fail_safe(self):
        self.f.res[ZA][0]["specificReservation"]["instanceProperties"]["machineType"] = "other-type"
        code, rep, prop = self.f.run()
        self.assertEqual(code, rs.EXIT_FAILSAFE)
        self.assertIsNone(prop)

    def test_other_consumers_noted(self):
        self.f.res[ZA][0]["specificReservation"]["inUseCount"] = "14"   # > 13 in-scope nodes (3 + 10)
        _, rep, _ = self.f.run()
        self.assertTrue(any("other pools/VMs" in n for n in row(rep, "k-a")["notes"]))

    def test_dry_run_without_github_is_config_error(self):
        self.f.policy["mode"] = "dry-run"
        with self.assertRaises(rs.SizerError) as cm:
            self.f.run()
        self.assertEqual(cm.exception.code, rs.EXIT_CONFIG)

    def test_default_history_source_is_node_metric(self):
        self.assertEqual(rs.DEFAULT_POLICY["historySource"], "node-metric")

    def test_stockout_filter_is_scoped(self):
        f = rs.stockout_filter("c1", REGION, 0)
        self.assertIn('resource.labels.cluster_name="c1"', f)
        self.assertIn(f'resource.labels.location="{REGION}"', f)
        self.assertIn('log_id("container.googleapis.com/cluster-autoscaler-visibility")', f)

    def test_pr_body_and_snapshot(self):
        _, rep, _ = self.f.run()
        with open(os.path.join(self.f.dir, "out", "pr_body.md")) as fh:
            body = fh.read()
        self.assertIn(rep["snapshot"], body)
        self.assertIn("`k-a`", body)

    def test_only_count_field_changes(self):
        _, _, prop = self.f.run()
        for k, v in prop.items():
            orig = self.f.tfvars["node_pool_reservations"][k]
            self.assertEqual({x: y for x, y in v.items() if x != "instance_count"},
                             {x: y for x, y in orig.items() if x != "instance_count"})


if __name__ == "__main__":
    unittest.main()
